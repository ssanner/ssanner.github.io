   % do inference for the p(f|c,D) using EP
    for j = unique(c)			
        users_idx = find(c == j);
        if ~isempty(users_idx),      
            sub_pref = pref(ismember(pref(:,1), users_idx),:);
            if optimize_kernel,
                try
                    [params_u, params_it] = test_optimize_kernel(suffix, num2str(j), x, u, sub_pref, pref_test)
                catch ex, end;
                K_u = sparse( feval (covfunc_u, params_u{1,2}, params_u{2,2}, params_u{3,2}, u) );  
                K_it = sparse( feval (covfunc_x, params_it{1,2}, params_it{2,2}, params_it{3,2}, x) ); 
                K_star = kron(K_u, K_it);
                k_inv = sparse( kron(inv(correct_singular(K_u)), inv(correct_singular(K_it))) );
            end                
            [S_, nu_, mu_] = ep_efficient_inverse_sparse( k_inv, sub_pref, gam, size(x,1) );
            idx = find_global_idx(users_idx, 1:size(x,1), item_count);                
            Sigma{j} = S_(idx,idx);
            nu{j} = nu_(idx);
            mu{j} = mu_(idx);
        end
    end

        [t_test, c_mean, c_std, test_count, pref_loss, ...
            pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std] ...
                = test_preference(1:size(u,1), 1:size(x,1), Sigma, nu, mu, x, u, pref, ...
               		 pref_test, covfunc_u, covfunc_x, params_u, params_it, 'ep', unique(c), c, '', item_count*user_count);
