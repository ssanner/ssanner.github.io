
function [mu prec v] = get_phi(kappa0, mu0, sig0, v0, x)

if nargin < 5
   x = [];
end

%% Bayesian approach
nt = length(x); 
kt = kappa0+nt;
vt = v0 + nt;
v = vt;               
if nt == 0
   mu = mu0;
   prec = 1/sig0;     
elseif nt == 1   
   vtsigt = v0*sig0^2 + (x-mu0)^2*(kappa0*nt)/kt;
   mu = (kappa0*mu0 + nt*x)/kt;      
   prec = 1/sqrt(vtsigt * (kt+1)/(kt*(vt-2)));     
else   
   xbar = mean(x);
   vtsigt = v0*sig0^2 + (nt-1)*var(x) + (xbar-mu0)^2*(kappa0*nt)/kt;
   mu = (kappa0*mu0 + nt*xbar)/kt;      
   prec = 1/sqrt(vtsigt * (kt+1)/(kt*(vt-2)));  %phi(t,3) = 1/std(x(indi));     
end

%% Some type of frequentist approach
% v = length(x);
% if v == 0
%    mu = sig0*randn + mu0;
%    prec = 2;   
%    v = 1;
% elseif v == 1
%    mu = x;
%    prec = 2;
% else
%    mu = mean(x);
%    prec = 1/std(x);
% end
