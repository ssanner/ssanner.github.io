function [f filename suffix dt] = get_results_file(suffix)
    dt = datestr(now, '_dd.mm.yyyy.hh.MM');
    filename = strcat('accuracy_time_', suffix);
    if strfind(kernel_path(suffix), '_identity')>0
        filename = [filename '_identity'];
        suffix = [suffix '_identity'];
    end
       
    filename = strcat(filename, dt, '.csv');
    f = fopen(['results/' filename], 'w');
end