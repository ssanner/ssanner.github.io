function [Sigma, nu, mu, S_tilde sig] = ...
                ep_efficient_inverse_sparse(k_inv, pref, gamma, item_count)
% conv

m = size(pref,1);
n = size(k_inv, 1); % size(K_u, 1) * size(K_it, 1);
%conv = [];

mu = zeros(n,1);
nu = zeros(n,1);
one_coef = 1;
one_1 = [one_coef; -one_coef];
one_2 = [one_coef, -one_coef;
         -one_coef, one_coef];
%K = k_inv;
%k_inv = sparse( correct_singular( K ) );
Sigma = k_inv;
%Sigma = zeros(n,n);

converged = false;
changed = false;
iteration = 0;

sig_tilde_all = zeros(n, n);
mu_tilde = zeros(2, 1);

sparse_items = zeros(n,1);
sparse_users = zeros(n,1);

%fprintf('pref_length: %d\n' , length(pref));
%fprintf('users: %d\n', size(K_u, 1));
    
while (~converged && iteration < 20) % 30
    iteration = iteration + 1;
    nu_prev = nu;
    
    entropy = zeros(n, 1);
	kl = zeros(n, 1);
    entropy_ivm = -Inf(n, 2);
    
    changed = false;
    for i = randperm(m)
    	user_id = pref(i, 1);
       % [item1, item2] = itemOffsets(user_id, pref(i, 2), pref(i, 3),item_count);
       
        item1 = pref(i,2);
        item2 = pref(i,3);
       
        sparse_items(item1) = pref(i, 2);
        sparse_items(item2) = pref(i, 3);
        
        sparse_users(item1) = user_id;
        sparse_users(item2) = user_id;
        
        sig_t = [Sigma(item1, item1), Sigma(item1,item2);
                 Sigma(item2,item1),Sigma(item2,item2)];
        mu_t =  [mu(item1); mu(item2)];

        if(det(sig_t) <= 0)
            continue;
        end

        sig_tilde = [sig_tilde_all(item1, item1), sig_tilde_all(item1,item2);
                 sig_tilde_all(item2,item1),sig_tilde_all(item2,item2)];

        sig_sub = (sig_t - sig_tilde); 
        mu_sub =  (sig_t * mu_t - [nu(item1); nu(item2)] ); 

        %% calcumating \hat(mu) and \hat(sigma): since it is inverted, we invert it first
        sig_sub_inv = inv (correct_singular (sig_sub)); % sig_sub is the precision, hence the inversion
        sig_star = (gamma^2  + one_coef * (sig_sub_inv(1,1) + sig_sub_inv(2,2) - sig_sub_inv(1,2) - sig_sub_inv(2,1)));
     %   if(abs(sig_star) < .01)
     %       sig_star = .01 * sign(sig_star);
     %   end
        
        s = (mu(item1) - mu(item2)) / sig_star;
        if(isnan(s))
            s = 1000;
        end
        
        if(abs(s) > 1000)
            s = 1000 * sign(s);
        end
        
        coef = (normpdf(s) / normcdf(s));
        if(normcdf(s) == 0 || isnan(coef))
            coef =abs(s);
        end
        
        temp =  (coef / sig_star) * one_1;  
        if(norm(temp) < .1)
            changed = false || changed;
            continue;
        end
        changed = true;
        w = (temp * temp' + s/sig_star * temp * one_1' ) ; 
        sig_hat = sig_sub_inv - (sig_sub_inv * w * sig_sub_inv); 
        mu_hat = mu_t + sig_sub_inv * temp; % mu_sub here is the \sigma^{-1}mu so we multiply it by \sgima
        sig_hat = inv ( correct_singular(sig_hat) );         
        delta_sig_tilde =  sig_hat - (sig_sub) -  sig_tilde;
        temp = sig_tilde ;
        sig_tilde = sig_tilde + delta_sig_tilde;
        mu_tilde = (sig_hat * mu_hat - mu_sub); 
     
        mu_bar = zeros(n,1); 
        mu_bar(item1) = mu_tilde(1);
        mu_bar(item2) = mu_tilde(2);
        
        s_ij = Sigma(:,[item1,item2]);    
        delta_inv = (inv(correct_singular(delta_sig_tilde)) );
        token = ((delta_inv + s_ij([item1,item2],:))) ;
        if(det(delta_inv + s_ij([item1,item2],:)) <= 0)
            token = eye(size(token));
        end    
    
        dif = sig_tilde; 
        temp1 = Sigma(item1, item1);
        temp2 = Sigma(item2, item2);
        temp  = Sigma([item1,item2],[item1, item2]);
        Sigma(item1, item1) = k_inv(item1, item1) + dif(1,1);
        Sigma(item1, item2) = k_inv(item1, item2) + dif(1,2);
        Sigma(item2, item1) = k_inv(item2, item1) + dif(2,1);        
        Sigma(item2, item2) = k_inv(item2, item2) + dif(2, 2);        
        %entropy(item1) = log(1 + Sigma(item1, item1) / temp) + entropy(item1);%0.5 * log(1 + k_inv(item1, item1)/temp1);                     
        %entropy(item2) = log(1 + Sigma(item2, item2) / temp) + entropy(item2);% 0.5 * log(1 + k_inv(item2, item2)/temp2); 
        
        entropy(item1) = getdifentropy1(temp1, Sigma(item1, item1)) + entropy(item1);
        entropy(item2) = getdifentropy1(temp2, Sigma(item2, item2)) + entropy(item2);
        
      %  Sigma(item1, item1) = temp1;
      %  Sigma(item1, item1) = temp2;
        entropy_ivm(i, 1) = i;
       % entropy_ivm(i, 2) = log(det(Sigma([item1,item2],[item1,item2]))) - log(det(temp));
        entropy_ivm(i, 2) = log( 1 + k_inv(item1, item1)/temp(1,1) + k_inv(item1, item2)/temp(1,2) + ...
        k_inv(item2, item1)/temp(2,1) + k_inv(item2, item2)/temp(2,2) );
        
        nu(item1) =  mu_tilde(1); 
        nu(item2) =  mu_tilde(2); 
        mu_old1 = mu(item1);
        mu_old2 = mu(item2);
        mu = Sigma * nu;
        mu(isnan(mu)) = 1000;
       
        kl(item1) = getKL1(mu_old1, mu(item1), temp1, Sigma(item1,item1)) + kl(item1);
        kl(item2) = getKL1(mu_old2, mu(item2), temp2, Sigma(item2,item2)) + kl(item2);
        
        %% INCLUDE ABOVE TOO
        sig_tilde_all(item1, item1) =  sig_tilde(1,1);
        sig_tilde_all(item2, item1) =  sig_tilde(2,1);
        sig_tilde_all(item1, item2) =  sig_tilde(1,2);
        sig_tilde_all(item2, item2) =  sig_tilde(2,2);        
    end
       
    n_norm = norm(nu - nu_prev);
    if (n_norm < .1 && iteration > 2)
        converged = true;
    end
    
%    fprintf('%d, %f > ', iteration, n_norm);
    
    % fprintf('iteration: %d, %f\n', iteration, n_norm);

    converged = ( ~changed || converged ) && iteration > 2;

    if iteration < 2
       % S_tilde_cpy = sig_tilde_all;    
       S_tilde_cpy = Sigma;
    elseif iteration == 2
       % sig = inv( correct_singular( sig_tilde_all )) ; % inv( correct_singular (k_inv + inv( correct_singular( sig_tilde_all )) )) ; % 
       % sig_cpy = inv( correct_singular( S_tilde_cpy )); %inv( correct_singular (k_inv + inv( correct_singular( S_tilde_cpy )) )) ;% 
      
    end
 %   conv = [conv;n_norm];  
end
S_tilde = sig_tilde_all;
sig = inv(Sigma);
%sig = inv( correct_singular( S_tilde) ); % inv( correct_singular (k_inv + inv( correct_singular( S_tilde)) )) ; % 
%sig_cpy = inv( correct_singular (k_inv + inv( correct_singular( S_tilde_cpy)) )) ;
%nu = inv(K +  Sigma) * mu; %inv(K +  ); %sig

%fprintf('\n');
return ;

function [a] = correct_val(b)
    if isinf(b) || isnan(b)
        a = 1000;
    else
        a = b;
    end
   
return ;

function [e] = getdifentropy1(sig_old, sig_new)
    if sig_old == 0; sig_old = .001; end;
   % e = .5 * log( 1 + sig_new / sig_old);
 %   e = -.5 * log( 1 + sig_new / sig_old);
    e = .5 * log( 1 - sig_new * sig_old);
return ;

function [kl] = getKL1(mu_old, mu_new, sig_old, sig_new)
    if sig_old == 0; sig_old = .001; end;
    kl = ((mu_new - mu_old)^2)/2 * sig_old^2 + .5 * ( sig_new^2 / sig_old^2 - 1 - log(sig_new^2 / sig_old^2));
return ;
