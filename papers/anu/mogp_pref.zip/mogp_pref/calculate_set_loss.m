function [loss_sh loss_meu] = calculate_set_loss(pref_test, mu, Sigma, c)
    global x u FID_SET_SELECTION FID_SET_SELECTION_USER
    users    = 1:size(u,1); % unique(pref_test(:,1))';
    loss_meu = zeros(length(users), size(x,1));
    loss_sh  = zeros(length(users), size(x,1));

    best = pref_test(:,2);
    items = unique(best)';

    for itr = 1 : size(pref_test,1)
        group_idx = c(pref_test(itr, 1));

        % count = zeros(1,length(items));

        %for j = items
        %    count(j) = sum( best == j );
        %end
        %[dumy idx] = sort(count, 'descend');

        
        user_group_idx = find(find(c == group_idx) == pref_test(itr, 1));
        i = find_global_idx(user_group_idx, items, size(x,1));
        mm = mu{group_idx}(i);
        ss = Sigma{group_idx}(i,i);
        best_items = get_best_item(pref_test, pref_test(itr, 1));
            
        for k = 1 : length(best_items)
            selection = set_selection('meu', k, mm, ss, items);            
            loss_meu(pref_test(itr, 1),k) = loss_meu(pref_test(itr, 1),k) + calc_loss(selection, best_items); % count(idx(1:k))
        
            selection = set_selection('sh', k, mm, ss, items);            
            loss_sh(pref_test(itr, 1),k)  = loss_sh(pref_test(itr, 1),k) + calc_loss(selection, best_items); % count(idx(1:k))
        end
    end

    
	for k = 1 : length(items)
        fprintf('%d, %f, %f\n', k, mean(loss_meu(:,k)), mean(loss_sh(:,k)));
        fprintf(FID_SET_SELECTION, '%d, %f, %f\n', k, mean(loss_meu(:,k)), mean(loss_sh(:,k)));
    end

    for uu = users
    %    fprintf('%f, %f, %f\n', uu, mean(loss_meu(uu,:)), mean(loss_sh(uu,:)));
        fprintf(FID_SET_SELECTION_USER, '%f, %f, %f\n', uu, mean(loss_meu(uu,:)), mean(loss_sh(uu,:)));
    end
    loss_meu = mean(loss_meu(uu,:));
    loss_sh = mean(loss_sh(uu,:));
return ;

function [loss] = calc_loss(selection, best_items)
% sum(~ismember(selection, best_items))
    l = length(selection);
    loss = 0;
    for i = 1 : l
        if ismember( selection(i), best_items)
            loss = loss + 1;
        end
	end
    
    loss = (l - loss);
return ;