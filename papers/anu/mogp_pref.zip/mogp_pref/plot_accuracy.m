function plot_accuracy(suffix, accu_filename, item_comunity_filename, user_community_filename, pc_filename, ...
                                set_selection_filename, user_filename)
 data = dlmread(['results/' accu_filename]);

attributes = { {'SUV', 'Automatic', '3.5L', 'Normal'};
                {'SUV','Automatic','3.5L', 'Hybrid'};
                {'SUV', 'Manual', '4.5L', 'Normal'};
                {'SUV', 'Automatic', '5.5L', 'Hybrid'};
                {'SUV', 'Manual', '6.2L', 'Normal'};
                {'Sedan', 'Automatic', '2.5L', 'Hybrid'} ;
                {'Sedan', 'Manual', '2.5L', 'Normal'} ;
                {'Sedan', 'Manual', '3.5L', 'Normal'} ;
                {'Sedan', 'Automatic', '3.5L', 'Hybrid'};
                {'Sedan', 'Automatic', '4.5L', 'Normal'}};

vis = 'off';

mean_idx = 4;
all_idx = 1:length(data(:,2));

figure('visible', vis);
plot(data(:,2), data(:,8), 'k.', 'LineWidth', 3);
set(gca, 'FontSize', 24);
plot_settings(gca, 'No. communities', 'iteration', [suffix '_iterations'])

build_tabular(data, suffix);

if false,
    figure('visible', vis);
    hold on
    idx = find(data(:,2) == max(data(:,2)));
    plot(1:100, zeros(1,100)+data(idx,mean_idx), 'k--', 'LineWidth', 3);
    all_idx(idx == all_idx) = [];

    idx = find(data(:,2) == min(data(:,2)));
    plot(1:100, zeros(1,100)+data(idx,mean_idx), 'g--', 'LineWidth', 3);
    all_idx(idx == all_idx) = [];

    errorbar(data(all_idx,2), data(all_idx,mean_idx), data(all_idx,mean_idx+1), 'b.', 'LineWidth', 3);
    errorbar(data(all_idx,2), data(all_idx,mean_idx), data(all_idx,mean_idx+1), 'g.', 'LineWidth', 3);

    idx = max(all_idx);
    errorbar(data(idx,2), data(idx,mean_idx), data(idx,mean_idx+1), 'rs', 'LineWidth', 3);
    hold off
end

%% ---------------------------------------------------------
data = dlmread(['results/' item_comunity_filename]);
idx_all = find(sum(data,2)>0);
[m,n] = get_subplot_size(length(idx_all));

figure('visible', vis);
for i = 1 : length(idx_all)
    h=subplot(m,n, i); bar(data(idx_all(i),:) ./ sum(data(idx_all(i),:)));
    title(['Community' num2str(i)]);
    set(gca, 'XTick', []);
    axis tight
	a = get(h, 'Position');
    w = min(1/n, 1/m);
  %  a(3:4) = [w w];
    set(h,'Position', a);
end
plot_settings(gca, 'items', 'communities', [suffix '_item_community']);     

try
figure('visible', vis);
tbl_tex = '\begin{tabular}{|c|c|c|c|} \hline';
for i = 1 : length(idx_all)
  	[att cap att_str] = extract_att( data(idx_all(i),:) , attributes , 4, idx_all(i));
    tbl_tex = [tbl_tex, num2str(idx_all(i)) att_str];
    h=subplot(m,n, i); bar(att); %mat
    axis tight 
    xlabel(get_str(cap), 'FontSize', 12);
    title(['Community Attributes' num2str(i)]);
	a = get(h, 'Position');
    w = min(1/n, 1/m);
  %  a(3:4) = [w w];
    set(h,'Position', a);
end
tbl_tex = [tbl_tex '\hline\end{tabular}'];
f = fopen(['tex/tbl_att_' suffix '.tex'], 'w+');
fwrite(f, tbl_tex);
fclose(f);
plot_settings(gca, 'items', 'communities', [suffix '_att_community']);     
catch ex,
end
%% ---------------------------------------------------------
data = dlmread(['results/' user_community_filename]);
% data = data(2:end,:);
[m,n] = get_subplot_size(size(data,1));

figure('visible', vis);
community_count = zeros(6,50);
community_iter_idx = zeros(size(community_count,1),1);
idx = 1;
max_sum = 0;
last_c = 0;
for i = 1 : size(data,1)
    a = data(i,2:end);
    c = zeros(1,length(a));
    for j = 1 : length(a)
        c(j) = sum(a == j);
    end
    
    if sum(c~=0) > max_sum,
        max_sum = sum(c~=0);
    end
    community_count(idx,sum(c~=0)) = community_count(idx,sum(c~=0)) + 1;
    if mod(i,floor(size(data,1)/size(community_count,1))) ==0 && idx < size(community_count,1), 
        community_iter_idx(idx)=i;
        idx = idx + 1; 
        community_count(idx,:) = community_count(idx-1,:);
    end;
    h=subplot(m,n,i); bar(c);
    last_c = c;
    axis tight 
    a = get(h, 'Position');
    a(4) = [.3];
    set(h,'Position', a);
    title(['Iteration ' num2str(i)], 'FontSize', 24)
   % xlabel('Community Index', 'FontSize', 24); 
   % ylabel('No. Users', 'FontSize', 24); 
end
community_iter_idx(size(community_count,1)) =  size(data,1);

plot_settings(gca, 'users', 'communities', [suffix '_user_community'])

figure('visible', vis);
bar(last_c);
plot_settings(gca, 'users', 'communities', [suffix '_user_community_last_iteration'])

community_count = community_count(:,1:max_sum);
figure('visible', vis);
for i = 1 : size(community_count,1)
subplot(2,3,i); 
if sum(community_count(i,:)) > 0
    last_c = community_count(i,:)./sum(community_count(i,:));
    bar(last_c);
    title(['Iteration ' num2str(community_iter_idx(i))]);
    axis tight
end
end
% xlabel('Iteration', 'FontSize', 24); 
% ylabel('No. Communities','Interpreter','LaTex', 'FontSize', 24);
plot_settings(gca, 'Iteration', 'No. communities', [suffix '_iteration_community'])

figure('visible', vis);
bar(last_c);
plot_settings(gca, 'Iteration', 'No. communities', [suffix '_iteration_community_last_iteration'])


data = dlmread(['results/' pc_filename]);
% data = data(2:end,:);
[m,n] = get_subplot_size(size(data,1));

figure('visible', vis);
for i = 1 : size(data,1)
    a = data(i,2:end);    
    h=subplot(m,n,i); bar(a);
    
    axis tight 
    a = get(h, 'Position');
    a(4) = [.3];
    set(h,'Position', a);
    title(['Iteration ' num2str(i)], 'FontSize', 24)
   % xlabel('Community Index', 'FontSize', 24); 
   % ylabel('No. Users', 'FontSize', 24); 
end
plot_settings(gca, 'users', 'communities', [suffix '_pc_community'])


% a = unique(data(:,2));
% m3 = zeros(size(a));
% m4 = zeros(size(a));
% s3 = zeros(size(a));
% s4 = zeros(size(a));
% 
% for i = 1 : length(a)
%      m3(i) = mean(data(data(:,1) == a(i),mean_idx));
%      s3(i) = mean(data(data(:,1) == a(i),mean_idx+1));
%      m4(i) = mean(data(data(:,1) == a(i),mean_idx));
%      s4(i) = mean(data(data(:,1) == a(i),mean_idx+1));
% end
% 
% hold on
% errorbar(a, m3, s3, 'b--', 'LineWidth', 3);
% errorbar(a, m4,s4, 'r--', 'LineWidth', 3);
% hold off
return; 


function [m,n] = get_subplot_size(l)
NUM_PLOT_IN_ROW = 4;
if l < NUM_PLOT_IN_ROW,
    n = l;
    m = 1;
elseif mod(l,2) == 0, % if number is even
    n = min(NUM_PLOT_IN_ROW, l/2);
    m = (ceil(l/n)); 
else
	n = NUM_PLOT_IN_ROW;
    m = (ceil(l/NUM_PLOT_IN_ROW)); % size(data,1) - (floor(size(data,1)/5))*5;
end
return ;

function build_tabular(data, suffix)
    s = '';
    a = '|'; 
    for i = 1 : 3
        a = [a 'c|'];
    end
    s = [s '\begin{tabular}{' a '} ' ...
        '\hline \textbf{No. Communities} & \textbf{Accuracy \%} & \textbf{Time (s)} \\ \hline '];
    for i = 1 : size(data, 1)
        s = [s '$' num2str(data(i,2)) '$ & $' num2str(data(i,4)) '\pm' num2str(data(i,5)) '$ & $' ...
            num2str(data(i,8)) '$ \\' ];
    end
    s = [s ' \hline \end{tabular}'];
    
    f = fopen(['tex/tbl_' suffix '.tex'], 'w+');
    fwrite(f, s);
    fclose(f);
return ;

function plot_settings(gca, xlbl, ylbl,filename_term)
 %   leg = legend ('', 'Location', 'Best');  
 %   legend boxoff
 %   xlabel([xlbl], 'FontSize', 24); 
 %   ylabel(ylbl,'Interpreter','LaTex', 'FontSize', 24);            
    axis tight 
    label = ['tex/images/'  filename_term]; 
    print('-depsc', [label '.eps']);
    system(['epstopdf ' label '.eps']);
    
return ;

function [att cap pop_att_str] = extract_att( d , attributes, t ,com_idx )
    att = cell(4*length(d),1);    
    cap = cell(4*length(d),1);    
    count = 1;
    
    for i = 1 : length(d)        
       a = attributes{i};
       for j = 1 : length(a)
           idx = -1;
           for k = 1 : count
              if strcmp(cap{k}, a{j}),
                 idx = k;
                 break;
              end
           end
           if idx == -1,
               idx = count;
               att{idx} = 0;
               count = count + 1;
           end
           cap{idx} = a{j};    
           att{idx} = att{idx} + d(i);
       end
    end
    
    strs = cell(1,count-1);
    at = zeros(1, count-1);
    for i = 1 : count -1
        strs{i} = cap{i};
        at(i) = att{i};
    end

  [a idx] = sort(at, 'descend');
  pop_att_str = '';
  used_idx = [];
  
  for tt = 1 : t
	for i = 1 : 4
        for j = idx        
            for k = 1 : size(attributes,1)         
              temp = '';
              if strcmp(strs{j}, attributes{k}{i}) && ~ismember(j,used_idx)
                 used_idx = [used_idx,j];
                 if length(temp) == 0 && i == 1,
                     temp = [num2str(com_idx) ' & '];
                 end
                if i > 1
                  temp = ' & ';
                end
                temp = [temp strs{j}];
                pop_att_str = [pop_att_str temp];
                break;
              end
              % if length(temp) > 0, 
               %  pop_att_str = [pop_att_str '\\'];
               % end;
            end
            if length(temp) > 0, 
                break; 
            end;
          end
      end
      pop_att_str = [pop_att_str '\\'];
  end
    
    t = min(t, count-1);
    cap = cell(1,t);
    att = zeros(1,t);
    for i = 1 : t
       cap{i} = strs{idx(i)};
       att(i) = at(idx(i)); 
    end 
    att = att ./ sum(att);
return ;


function s = get_str( a )
s = '';
for i = 1 : length(a)
    s = [s a{i} ' '];
end
return ;