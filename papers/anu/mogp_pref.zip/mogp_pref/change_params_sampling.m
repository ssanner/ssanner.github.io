function [mu,nu,Sigma, m,n, S, mj,nj,Sj, orig_user_group_idx] = change_params_sampling(i,j,c, mu, nu, Sigma)
% i : user
% j : class index

global pref k_inv gam x

item_count = size(x,1);

user_group_idx = c(i);  
group_idx = find(c == user_group_idx);
m=mu{user_group_idx};
n=nu{user_group_idx};
S=Sigma{user_group_idx};
orig_user_group_idx = user_group_idx;

idx = find(group_idx ~= i);
idx_rest = [];
for idxer = 1 : length(idx)
    idx_rest = [idx_rest, (item_count*(idx(idxer)-1))+[1:item_count]];
end

% disp([i j idx]);
% disp([length(mu{user_group_idx}), idx_rest]);
mu{user_group_idx} = mu{user_group_idx}(idx_rest);
nu{user_group_idx} = nu{user_group_idx}(idx_rest);
Sigma{user_group_idx} = Sigma{user_group_idx}(idx_rest,idx_rest);

c(i) = j;
% user_group_idx = j;  
group_idx = find(c == j);

mj=mu{j};
nj=nu{j};
Sj=Sigma{j};

sub_pref = pref(ismember(pref(:,1), group_idx),:);
[S_, nu_, mu_] = ep_efficient_inverse_sparse( k_inv, sub_pref, gam, size(x,1) );
idx = find_global_idx(group_idx, 1:size(x,1), item_count);                
Sigma{j} = S_(idx,idx);
nu{j} = nu_(idx);
mu{j} = mu_(idx);

return ;