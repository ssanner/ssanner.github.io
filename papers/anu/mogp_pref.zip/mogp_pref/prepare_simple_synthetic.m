function [util prefs pref_test item_count] = prepare_simple_synthetic(user_count, opt, no_folds)
item_count = 25;

s = ['simple_synthetic_c' opt num2str(user_count)];

if exist(s, 'file')
  fprintf('%s\n', [s ' exists.']);
  x = dlmread(strcat('data/x_', s, '.csv'));
  item_count = size(x,1);

  return ;
end

u = eye(user_count);
x = eye(item_count);

no_communities = 4;
community = randint(1,user_count, [1,no_communities]);
like_x = cell(1,no_communities);
for i = 1 : no_communities
    like_x{i} = randperm(item_count, round (item_count / 2));
end

% like_x = round (item_count / 2);
util = zeros(user_count * item_count, 1);
idx = 1;
for i = 1 : user_count
   for j = 1 :  item_count
       c = community(i);
       if ismember(j,like_x{c})
            util(idx) = 10;
       else
           util(idx) = 5;
       end
       if strcmp(opt, '-uniform')
           util(idx) = util(idx) + round(2 * rand);
       elseif strcmp(opt, '-gaussian')
           util(idx) = util(idx) + round(2 * randn);
       end
       idx = idx + 1;
   end
end

%bar(util);

[prefs pref_test] = extract_preferences(x, u, util);

dlmwrite(strcat('../gp_ep/data/x_', s, '.csv'), x);
dlmwrite(strcat('../gp_ep/data/u_', s, '.csv'), u);
dlmwrite(strcat('../gp_ep/data/pref_', s, '.csv'), prefs);
dlmwrite(strcat('../gp_ep/data/pref_', s, '_test.csv'), pref_test);
dlmwrite(strcat('../gp_ep/data/utils_', s, '.csv'), util);    

partition_csv(strcat('../gp_ep/data/pref_', s, '_test.csv'), no_folds);
return ;