
function [d] = alg_id(alg)
if isstr(alg)
    if strcmp(alg, 'ep')
        d = 1;
    else
       if strcmp(alg, 'sparse_ep')
           d = 2;
       elseif strcmp(alg, 'mel') || strcmp(alg, 'mel1')
            d = 3;
       elseif strcmp(alg, 'laplace')
            d = 4;
       elseif strcmp(alg, 'ivm_ep1')
           d = 5;
       elseif strcmp(alg, 'ivm_ep2')           
           d = 6;
       elseif ~isempty(strfind(alg , 'heu'))
           alg = strrep(alg, 'heu', '');
          d = 100 + str2num(alg);
           d = 7;           
       elseif strcmp(alg, 'mel2')
           d = 8;
       elseif strcmp(alg, 'mel3')
           d = 9;
       elseif strcmp(alg, 'mel4')
           d = 10;
       elseif strcmp(alg, 'mel5')
           d = 11;
       elseif strcmp(alg, 'kl')
           d = 12;
       elseif strcmp(alg, 'svmrank')
           d = 20;
       else 
           d = -1;
       end
    end
else
    d = alg;
end