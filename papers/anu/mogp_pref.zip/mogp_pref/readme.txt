Learning Community-based Preferences via Dirichlet Process Mixtures of Gaussian Processes
Author: M. Ehsan Abbasnejad

This is the code of the paper published in IJCAI-13. Please let me know if you found any bugs or you had questions.

Running the code:
You can start with "mogp_simple" function that performs the experiments similar to what is reported in the papers. In this case you need to make sure the csv input files for the dataset is provided as instructed below. 

The "do_inference" function performs the inference for communities.

The prediction model is specified in "test_preferences".

Dataset structure: 
The preference dataset is split into three parts: users, items and preference data. The user/item data containts the user/item features and preference data contains the id (index of the row) of the user and the item she prefers (id of user + 2 id for items). These data is saved in three csv files in the data folder.

Any other dataset has to be converted to the specified format as done in "prepare" funciton. 