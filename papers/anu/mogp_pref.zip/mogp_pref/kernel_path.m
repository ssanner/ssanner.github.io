function [path, s] = kernel_path(suffix)
    opt = '';
    % opt = '_identity';
    % opt=get_option('identity_opt');
    s = regexprep(suffix, '\d*', '');
    s = regexprep(s, '-[\w]*', '');
    path = ['cache/kernels_', s, opt '.mat'] ;
return ;