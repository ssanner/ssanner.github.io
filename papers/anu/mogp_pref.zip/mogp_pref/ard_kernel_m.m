function [ K, D ] = ard_kernel_m(sigma1, sigma2, M, X)
K = zeros(size(X,1), size(X,1));
D = zeros(size(X,1), size(X,1));

if(size(M,1) == 1)
   M = M * eye( max(size(X(1,:))) );
end

for i = 1 : size(X,1)
    for j = 1 : i
       [kk d] = ard_kernel(X(i,:), X(j,:), M, sigma1, sigma2);
       K(i,j) = kk;
       K(j,i) = K(i,j);
       D(i,j) = d;
       D(j,i) = D(i,j);
    end
end 

K(isinf(K)) = -Inf;
K(isinf(K)) = max(K(:))+1;
end

