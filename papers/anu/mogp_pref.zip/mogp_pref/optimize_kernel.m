function [ K_u K_it params_u params_it] = optimize_kernel(u,x, kernel_u, kernel_it, K_u, K_it, D_u, D_it, params_u, params_it, nu, lambda )
    conv_limit = .2;
    converged = false;    
    sl =real( sqrtm(lambda) );
    TRESHOLD = 1e4;
    
    alpha = 1e-1; % 1e-6;
    iter = 0;
    while(~converged && iter < 20)               
        iter = iter + 1;
        diff = 0;
        p = {};
            
        K = kron(K_u, K_it);
        L = chol( correct_singular( eye(size(lambda)) + sl * K * sl) );
        b = nu - sl * L \ (L'\sl * K * nu);
        Z = b * b' - sl * L' \ (L \ sl);
        
        for i = 1 : (size(params_u, 1) )
            C = kron(deriv_K(kernel_u, i, params_u, K_u, D_u), K_it); % + kron(deriv_K(kernel_it, i, params, K_it, D_it), K_u);
            old_param = params_u{i, 2};
            p{i} = params_u{i,2} - alpha * .5 * trace(Z*C);
            if p{i} > TRESHOLD ; p{i} = p{i} / (.1*TRESHOLD) ; end;
            if p{i} < -TRESHOLD ; p{i} = -p{i} / (.1*TRESHOLD) ; end;
            c = norm(params_u{i,2} - old_param);
            diff = diff + c;
            if(c > conv_limit)
                [K_u D_u] = feval (kernel_u, p{1,2}, p{2,2}, p{3,2}, u);
            end
        end
        
        params_u = set_params(params_u, p);
        p = {};
        for i = 1 : (size(params_it, 1))
            C = kron(deriv_K(kernel_it, i, params_it, K_it, D_it), K_u);
            old_param = params_it{i,2};
            p{i} = params_it{i,2} - alpha * .5 * trace(Z*C);
            if p{i} > TRESHOLD ; p{i} = p{i} / (.1*TRESHOLD) ; end;
            if p{i} < -TRESHOLD ; p{i} = -p{i} / (.1*TRESHOLD) ; end;
            c = norm(params_it{i,2} - old_param);
            diff = diff + c; 
            if(c > conv_limit)
                [K_it D_it] = feval (kernel_it, p{1,2}, p{2,2}, p{3,2}, x);  
            end
        end
        params_it = set_params(params_it, p);
        p = {};
        
        check(params_u);
        check(params_it);
        
        
        if(diff < conv_limit)
            converged = true;
        end
    end
    
return;

function check(params)
    if isnan(params{1,2}),
        params{1,2} = 1;
    end
    
    if isnan(params{2,2}),
        params{2,2} = 1;
    end
    
    if isnan(params{3,2}),
        params{3,2} = eye(size(params{3,2}));
    end
return ;

function [params] = set_params(params, p)
for i = 1 : (size(params, 1))
    params{i,2} = p{i};
end
return ;

function [C] = deriv_K(krnl, param_idx, params, K, D)
    sig1 = 0;
    sig2 = 0;
    for i = 1 : size(params, 1)
        if(strcmp(params(i,1), 'sigma1'))
            sig1 = i;
        else
            if(strcmp(params(i,1), 'sigma2'))
                sig2 = i;
            end
        end                
    end

    if(strcmp(krnl, 'ard_kernel')|| strcmp(krnl, 'ard_kernel_m'))
        if(strcmp(params(param_idx, 1), 'sigma1'))
            C = 2 .* params{sig1, 2} .* (K - (params{sig2, 2}^2 * eye(size(K))));
        else
            if (strcmp(params(param_idx, 1), 'sigma2'))
                %C = -1 * params{param_idx, 2} * params{param_idx,2} .* R .* K + eye(size(K));
                C = 2 .* params{sig2, 2} .* eye(size(K));
            else
                R = K - params{sig2, 2} .* eye(size(K)) ./ (params{sig1,2}).^ 2;
                R = -2 .* log(R) ./ (params{sig2, 2} .^ 2);
                R(R == Inf) = 1e10;

                if (strcmp(params(param_idx, 1), 'M'))
                    C = -.5 .* D .* K; %-.5 * params{sig2, 2}^2 .* D .* K;
                end
            end
        end
    end
return ;
