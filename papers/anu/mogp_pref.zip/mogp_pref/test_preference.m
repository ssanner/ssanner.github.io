function [t, c_mean, c_std, test_count, loss, loss_std, sh_loss, sh_loss_std, wrongs, wrongs_std prob] = ...
                test_preference(sparse_users, sparse_items, Sigma, nu, mu, x, u, ...
                    pref, p_test, covfunc_u, covfunc_x, params_u, params_it, alg, unique_c, c, p_c, opt, orig_number, item_comunity_filename)

global K_star k_inv gam FID_RESULTS

if ~exist('util', 'var')
    util = [];
end

if ~exist('opt' ,'var')
    opt = '';
end

t = tic;
item_count = size(x, 1);
prob = Inf(item_count, item_count);

if strcmpi(alg, 'ep') || strcmpi(alg, 'optimize_kernel') || strcmpi(alg, 'p_c')
    %nu = cell(size(mu));
    SS = cell(size(nu));
    for j =  unique_c
        if length(unique_c) ==1, 
            SS{j} = inv( correct_singular( K_star + Sigma{j} )) ; 
        else
            users_idx = find(c == j);
            idx = find_global_idx(users_idx, sparse_items, item_count);
            SS{j} = inv( correct_singular( K_star(idx,idx) + Sigma{j} )) ;  %k_inv
        end
        % nu{j} = SS{j} * mu{j};  
    end
    item_dim = length(sparse_items);
else
    fprintf(['REMOVE reference to ' alg ' algorithms!\n']);
%    return ;
end

correct = 0;
test_count = 0;
c_list = [];
pref_orders = [];
loss  = [];
sh_loss = [];
meu_loss = [];
wrongs = [];
% item_community = zeros(length(c),item_count);
avg_user_time = 0;

%-----------
if(~iscell(p_test))
    test_no = 10;
else
    test_no = 1;
end
%-----------
test_count = [];

if(isstr(p_test))
   file_path = p_test;
   p_test = {}; 
   for i = 1 : test_no
       p_test{i} = dlmread(strrep(file_path, '.csv', strcat('.', int2str(i), '.csv')) );
   end
end

if (iscell (p_test) )
   test_no = length(p_test);    
end

for test = 1 : test_no
    if(iscell(p_test))
        pref_test = p_test{test};
    else
    %    rr = randint(int32(length(p_test)/10),1, [1,length(p_test)]); %(rr,:);
        pref_test = p_test; 
    end 
    
    user_time = 0;
    test_c = 0;
    for itr = 1 : size(pref_test,1)
        u_timer = tic;
        % user_idx = c(pref_test(itr, 1));  
        p = 0;
      %  if strcmp('alg', 'p_c')
            user_idx_count = 1:length(unique_c);
     %   else
      %      user_idx_count = find(unique_c == c(pref_test(itr, 1)));
      %  end
      
                  group_idx = 1; 
      k_star = computeKStar(u, group_idx, x, 1:item_count, u(pref_test(itr,1),:), ...
                                   [x(pref_test(itr, 2),:); x(pref_test(itr, 3),:)], ...
                                        covfunc_u, covfunc_x, params_u, params_it);

      
        for user_idx_indexer = user_idx_count 
            user_idx = unique_c(user_idx_indexer);
            %find(c == user_idx);
         %   idx = find_global_idx(group_idx, sparse_items, item_count);
            
%             if ~isempty(K_star)
%                 items_idx = find_global_idx(pref_test(itr, 1), sparse_items, item_count);
%                 k_star = full( K_star([items_idx(pref_test(itr, 2)), items_idx(pref_test(itr, 3)) ],idx) );
%                 clear item_idx;            
%             else       

%         k_star = computeKStar(u, group_idx, x, 1:item_count, u(pref_test(itr,1),:), ...
%                                                    [x(pref_test(itr, 2),:); x(pref_test(itr, 3),:)], ...
%                                                         covfunc_u, covfunc_x, params_u, params_it);
            
            mean = k_star * nu{user_idx}; 
            % group_idx
            C_star = computeKStar(u, pref_test(itr,1), x, [pref_test(itr, 2),pref_test(itr, 3)], ...
                                          u(pref_test(itr,1),:), [x(pref_test(itr, 2),:); x(pref_test(itr, 3),:)], ...
                                                        covfunc_u, covfunc_x, params_u, params_it);
            C_star = correct_singular ( C_star - k_star * SS{user_idx} * k_star' );
            denom = (gam^2 + C_star(1,1) + C_star(2,2) - 2*C_star(1,2) );
            %if strcmp('alg', 'p_c')
            p = p + (p_c(pref_test(itr, 1), user_idx) * normcdf( (mean(1)-mean(2)) ./ denom ) );
            %else
            %    p = p + ( normcdf( (mean(1)-mean(2)) ./ denom ) );
            %end
             
            % (normcdf( (mean(1)-mean(2)) ./ ...
                 %   (gam^2 + C_star(1,1) + C_star(2,2) - 2*C_star(1,2) ) ));
        end
        %if prob(pref_test(itr, 2),pref_test(itr, 3)) == 0
        %    prob(pref_test(itr, 2),pref_test(itr, 3)) = p;
        %else
        if p == 0, p = 1e-10; end;
        if isinf( prob(pref_test(itr, 2),pref_test(itr, 3)) ),
            prob(pref_test(itr, 2),pref_test(itr, 3)) = 0;
        end
        prob(pref_test(itr, 2),pref_test(itr, 3)) = prob(pref_test(itr, 2),pref_test(itr, 3)) + log(p);
        %end
        
        if( (p == .5 && rand >= .5) || (p > .5) ) 
        %if( (mean(1) == mean(2) && rand >= .5) || (mean(1) > mean(2)) )
            correct = correct + 1;
            pref_orders = [pref_orders; pref_test(itr,1), pref_test(itr,2), pref_test(itr,3)];
        else
            pref_orders = [pref_orders; pref_test(itr,1), pref_test(itr,3), pref_test(itr,2)];
        end
        
        % item_community(user_idx, pref_test(itr,2)) = item_community(user_idx, pref_test(itr,2)) + 1;
        
        test_c = test_c + 1;
        user_time = toc(u_timer) + user_time;
    end
    if test_c == 0, continue; end;
    test_count = [test_count; test_c];
%    [user_loss util_losses wrongs_loss] = test_pref_orders(sparse_users, pref_test, pref_orders, size(x, 1), util);
    user_loss=0;
    util_losses=0;
    wrongs_loss=0;
    loss = [loss; sum(user_loss)];
   % [l_sh l_meu] = calculate_set_loss(pref_test, mu, Sigma, c);
    [l_sh] = [0];
    [l_meu] = [0];
    sh_loss = [sh_loss; l_sh];
    meu_loss = [meu_loss; l_meu];
    wrongs = [wrongs; sum(wrongs_loss) /  length(pref_test)  * 100];
  %  if strcmpi(alg, 'p_c')
   %     c_list = [c_list; correct];
  %  else
        c_list = [c_list; correct / size(pref_test,1) * 100];
  %  end
    pref_orders = [];
    correct = 0;
    avg_user_time = avg_user_time + user_time/length(pref_test);
end
if(length(c_list) > 0)
    c_mean = sum(c_list)/length(c_list);
    c_std  = std(c_list);
else
    c_mean = 0;
    c_std  = NaN;
end

loss_std = std(loss);
loss = sum(loss )/length(loss );
sh_loss_std = std(sh_loss);
sh_loss = sum(sh_loss)/length(sh_loss);
meu_loss_std = std(meu_loss);
meu_loss = sum(meu_loss)/length(meu_loss);
wrongs_std = std(wrongs);
wrongs = sum(wrongs)/length(wrongs);
test_count = sum(test_count) / length(test_count);
avg_user_time = avg_user_time / length(test_count);

t = toc(t);

try  
%    if exist('item_comunity_filename', 'var')    
%        dlmwrite([item_comunity_filename '_' num2str(length(unique_c)) '.csv'], item_community);        
%    end
    
	fprintf('%d, %d, %s, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.1f, %2.2f, %2.10f, %2.2f\n', ...
        item_dim, length(unique_c), alg, c_mean, c_std, loss, loss_std, avg_user_time, meu_loss, ...
                meu_loss_std, sh_loss, sh_loss_std, wrongs, wrongs_std, test_count, t, sum(prob(prob~=inf))/test_no, orig_number);

    if exist('FID_RESULTS', 'var') && ~isempty(FID_RESULTS) && ~strcmpi(alg, 'optimize_kernel') && ~strcmpi(alg, 'p_c'), 
        % && ( ~strcmpi(opt, 'users_items') || ...
                   % strcmpi(alg, 'ep') || strcmpi(alg, 'optimize_kernel') || ...
                   %     strcmpi(alg, 'laplace') )
       fprintf(FID_RESULTS, '%d, %d, %d, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.1f, %2.2f, %2.10f, %2.2f\n', ...
            item_dim, length(unique_c), alg_id(alg), c_mean, c_std, loss, loss_std, avg_user_time, meu_loss, ...
                meu_loss_std, sh_loss, sh_loss_std, wrongs, wrongs_std, test_count, t, sum(prob(prob~=inf))/test_no,orig_number);
    end
    
catch ex
     fprintf('%s', ['test_preferences: ' ex.message]);
end
return;
