function [] = partition_csv(file_path, nobatch)

a = dlmread(file_path);
samples_count = int32( 3 * size(a,1) / nobatch );

    for i = 1 : nobatch
        rr = randperm(size(a,1),samples_count); % randint(int32(length(a)/10),1, [1,length(a)]);
        subset = a(rr,:);
        s = strrep(file_path, '.csv', strcat('.', int2str(i), '.csv'));
        dlmwrite(s , subset);
    end

end