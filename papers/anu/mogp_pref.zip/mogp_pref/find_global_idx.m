function idx = find_global_idx(users_idx, items, item_count)
%idx = reshape( repmat((users_idx-1) .* item_count, item_count,1), 1, length(users_idx)*item_count) ...
%                    + repmat(1:item_count,1,length(users_idx));

    uc = length(users_idx);
    ic = length(items);
    idx = zeros(1,uc * ic);
    i = 1;
    for uj = 1 : uc
       idx(i:i+ic-1) = items + item_count * (users_idx(uj)-1) ;
       i = i + ic;
    end

return ;