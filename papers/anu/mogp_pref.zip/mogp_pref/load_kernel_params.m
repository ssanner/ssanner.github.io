function  [params_u, params_it] = load_kernel_params(suffix)
global x u

[path, s] = kernel_path(suffix);
    try 
            % load (path);
    
                params_u{1,1} = 'sigma1';
                params_u{2,1} = 'sigma2';
                params_u{3,1} = 'M';
                params_u{1,2} = 1;
                params_u{2,2} = 1;
                params_u{3,2} = eye(size(u,2) ) + ones(size(u,2));
                
                params_it{1,1} = 'sigma1';
                params_it{2,1} = 'sigma2';
                params_it{3,1} = 'M';
                params_it{1,2} = 1;
                params_it{2,2} = 1;
                if strcmp(suffix, 'sushi')
                    coef = 1000;
                else
                    coef = 1e5;
                end
                params_it{3,2} = eye(size(x,2) ) + coef*ones(size(x,2) );        
    
    fprintf('Using kernel in [%s].\nRemove and run again if you feel this is not useful for this dataset\n', path);
    catch ex
        if strcmp( ex.identifier,  ['MATLAB:load:couldNotReadFile'])
            if isempty( strfind(path, '_identity') )
                if ~isempty( strfind(suffix, 'car2') )
                    s = [s '2'];
                end
                a = suffix; % [s '50'];
                fprintf('The kernel is not in the cache. Trying to optimize it with %s ....\n', a);
                test_optimize_kernel(a);
                load (path);                         
            else
                fprintf('Using identity kernel\n');
                params_u{1,1} = 'sigma1';
                params_u{2,1} = 'sigma2';
                params_u{3,1} = 'M';
                params_u{1,2} = 0;
                params_u{2,2} = 1;
                params_u{3,2} = 0;
                
                params_it{1,1} = 'sigma1';
                params_it{2,1} = 'sigma2';
                params_it{3,1} = 'M';
                params_it{1,2} = 0;
                params_it{2,2} = 1;
                params_it{3,2} = 0;                
            end
        else
            fprintf('%s', ['run_ep: ' ex.message]);
        end
    end
end
