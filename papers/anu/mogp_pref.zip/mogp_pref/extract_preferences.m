function [prefs pref_test] = extract_preferences(x, u, utils)
    prefs = [];
    pref_test = [];
    for ui = 1 : size(u, 1)
        p = [];
        idx = (size(x,1) * (ui - 1));
        for xi = 1 : size(x, 1)
            for xj = 1 : xi
                if utils(idx + xi) > utils(idx + xj)              
                    p = [p; [ui, xi, xj]];
                else 
                    if utils(idx + xi) < utils(idx +  xj) 
                        p = [p; [ui, xj, xi]];
                    end
                end
            end
        end
        a = size(p, 1);
        l = round(3*a/4); 
        perm = randperm(a,l);
        prefs = [prefs; p(perm,:)];
        p(perm,:) = [];
        pref_test = [pref_test; p];
    end    
return ;
