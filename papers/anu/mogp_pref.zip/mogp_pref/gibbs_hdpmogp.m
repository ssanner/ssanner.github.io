function [theta, phi, t, hamming_dist] = inf_gibbs_hdpmogp(x, y, varargin )
%
%  Gibbs sampler for HDP-MoGP 
%    NB: currently suppor 1-dimensional input only, but easily extendable
%    to support D-dimensional x inputs
%
%  x - input vector (Nx1)
%  y - target vector (Nx1)
%

%current_time = fix(clock);
%RandStream.setDefaultStream(RandStream('mt19937ar','seed',current_time(end)));
RandStream.setDefaultStream(RandStream('mt19937ar','seed',1));
bDisplay = 1;

N = length(x);
s = [];
fn = '';
NUM_ITER = 100;

%% ************** Hyperparameters *************************************

%---- hyperhyperparameters
lambda = 3;
alpha = 1;

kappa0 = 1;
mu0 = mean(x);
sig0 = std(x)/50;
v0 = 20;

theta0 = [0 2 1 0.1];

%---- Override defaults
for i = 1:2:size(varargin,2)
   switch lower(varargin{i})
      case 'true_state', s = varargin{i+1};
      case 'savefn', fn = varargin{i+1};
      case 'lambda', lambda = varargin{i+1};
      case 'alpha', alpha = varargin{i+1};
      case 'xprior', kappa0 = varargin{i+1}(1);
                   mu0 = varargin{i+1}(2);
                   sig0 = varargin{i+1}(3);
                   v0 = varargin{i+1}(4);
      case 'theta0', theta0 = varargin{i+1};
      case 'iter', NUM_ITER = varargin{i+1};
      case 'seed', RandStream.setDefaultStream(RandStream('mt19937ar','seed',varargin{i+1}));
      case 'display', bDisplay = varargin{i+1};         
      otherwise, error('Unrecognized parameter %s\n', varargin{i});
   end
end

%---- Set up table/dishes data structures
T = 1;   %number of tables (input Gaussians)
phi(1,1) = 1;              %dish assignment
phi(1,2:4) = get_phi(kappa0, mu0, sig0, v0);

K = 1;   %number of dishes (GPs)
theta(1,:) = get_theta([],[],theta0);

%---- Table assignments (initially none)
t = zeros(size(x));


%% ************** Setup Display ***************************************
if bDisplay
   %figure(1);
   if isempty(s)
      subplot(2,1,2);
      set(gca, 'Position', [0.1 0.05 0.8 0.15]);      
      set(gca, 'XTick', []);       
      ylabel('Estimated');
      
      subplot(2,1,1);      
      plot(x,y,'.')
      set(gca, 'XTick', []); 
      set(gca, 'Position', [0.1 0.25 0.8 0.7]); 
   else     
      subplot(3,1,3);
      set(gca, 'Position', [0.1 0.05 0.8 0.15]);      
      set(gca, 'XTick', []); 
      ylabel('Estimated');

      subplot(3,1,1);
      plot(x,s,'*')
      set(gca, 'XTick', []); 
      set(gca, 'Position', [0.1 0.80 0.8 0.15]);      
      ylabel('True');  

      subplot(3,1,2);
      plot(x,y,'.')
      set(gca, 'XTick', []); 
      set(gca, 'Position', [0.1 0.25 0.8 0.5]); 
   end
   pause(1);
end

%% ************** Gibbs Sampler ***************************************
hamming_dist = zeros(NUM_ITER,1);

for iter = 1:NUM_ITER
    
   %----  1. Reseample table assignments for each observation
   %----
   for i=1:N      
      
      % Remove observation     
      ti = t(i); t(i) = 0;     
      if iter > 1
         indi = (t==ti);
         [mu_t prec_t v_t] = get_phi(kappa0, mu0, sig0, v0, x(indi));
         phi(ti,2:4) = [mu_t prec_t v_t];
      end
      
      f = zeros(K,1);
      m = zeros(K+1,1);
      m(K+1) = lambda;      
      parfor k=1:K  %for each GP compute likelihood  **************(parfor)
         indt = find(phi(:,1) == k);
         z_k = ismember(t, indt);
         m(k) = sum(z_k);
         if m(k) == 0
            f(k) = 0; %doesn't matter really
         else
            x_k = x(z_k);
            y_k = y(z_k);
            f(k) = loglikelihood(x(i), y(i), x_k, y_k, theta(k,:));            
         end
      end

      % Choose dish (GP parmeter) for potential new table (input Gaussian)
      [dontcare,k] = histc(rand,[0;cumsum(m(:))/sum(m)]);
           
      if k > K          % if new dish, sample GP parameter
         theta_new = get_theta(x(i), y(i), theta0);           
         fnew = loglikelihood(x(i), y(i), x(i), y(i), theta_new);      
      else              % if existing dish
         fnew = f(k);
      end
      
      % Compute posterior component of each table (input Gaussian)
      tsta = zeros(T,1);
      g = zeros(T+1,1);      
      for j = 1:T
         tsta(j) = phi(j,3)*pdf('T', phi(j,3)*(x(i)-phi(j,2)), phi(j,4));
         g(j) = log(sum(t==j)*tsta(j)) + f(phi(j,1));
      end
      
      [mu_t prec_t vt] = get_phi(kappa0, mu0, sig0, v0, x(i));
      tsta_t = prec_t*pdf('T', prec_t*(x(i)-mu_t), vt);      
      g(T+1) = log(alpha*tsta_t) + fnew; 
      
      % Choose table (input Gaussian)
      g = g - max(g); g = exp(g);
      [dontcare,ti] = histc(rand,[0;cumsum(g(:))/sum(g)]);
      
      if ti > T          % if new table, then add table to structures
         if k > K
            theta(K+1,:) = theta_new;
            K = K + 1;
         end
         t(i) = T+1;         
         T = T+1;
         phi(ti,1) = k;
      else              % if existing dish
         t(i) = ti;
      end
      
      % Update input stats
      indi = (t==ti);
      [mu_t prec_t v_t] = get_phi(kappa0, mu0, sig0, v0,x(indi));
      phi(ti,2:4) = [mu_t prec_t v_t] ;     
      
   end   %end each observation (i=1:N )

   %---- 2. Sample theta (Gaussian process hyperparameters)
   %----
   parfor k=1:K  %                             **************(parfor)
      indt = find(phi(:,1) == k);
      z_k = ismember(t, indt);
      if any(z_k)
         x_k = x(z_k);
         y_k = y(z_k);
         theta(k,:) = get_theta(x_k, y_k, theta0); 
      end           
   end   
   
   %----  3. Sample k (dishes for each table)
   %----
   for j = 1:T     
      indj = t==j;
      if sum(indj)==0, continue; end;
      f = zeros(K+1,1);

      theta_new = get_theta([], [], theta0);
      f(K+1) = log(lambda) + loglikelihood(x(indj), y(indj), [], [], theta_new);

      parfor k = 1:K %                             **************(parfor)         
         indt = find(phi(:,1) == k);
         indk = ismember(t, indt);         
         f(k) = log(sum(indk)) + loglikelihood(x(indj), y(indj), [], [], theta(k,:));
      end

      % Choose k for table 
      f = f - max(f); f = exp(f);
      [dontcare,k] = histc(rand,[0;cumsum(f(:))/sum(f)]);

      if k > K          % if new dish, use new sample GP parameter
         theta(K+1,:) = theta_new;
         phi(j,1) = K + 1;
         t(indj) = j;
         K = K + 1;             
      else              % if existing dish
         phi(j,1) = k;
         t(indj) = j;
      end   
   end
   
   %----  Remove dead states (TODO, not absolutely necessary)
        
  

   %----  Update display
   da = phi(t,1);   
   if isempty(s)
      if bDisplay==1
         fprintf('iter: %d\n', iter);        
         subplot(2,1,2);
         set(gca, 'Position', [0.1 0.05 0.8 0.15]); 
         plot(x, da, 'o');
         ylim([min(da)-1 max(da)+1]);
         set(gca, 'XTick', []);       
         ylabel('Estimated');
         subplot(2,1,1);      
         plot(x,y,'.')
         set(gca, 'XTick', []); 
         set(gca, 'Position', [0.1 0.25 0.8 0.7]); 
         pause(1);
      end
   else
      [relabeled_est_labels hd] = mapSequence2Truth(s',da');
      hamming_dist(iter) = hd;    
      if bDisplay==1
         %figure(2);  
         fprintf('iter: %d,  hamming distance: %0.2f\n', iter, hd);
         subplot(3,1,3);         
         set(gca, 'Position', [0.1 0.05 0.8 0.15]);      
         plot(x,relabeled_est_labels,'o');
         ylim([min(relabeled_est_labels)-1 max(relabeled_est_labels)+1]);
         set(gca, 'XTick', []); 
         ylabel('Estimated');
         subplot(3,1,1);
         plot(x,s,'*')
         ylim([min(s)-1 max(s)+1]);
         set(gca, 'XTick', []); 
         set(gca, 'Position', [0.1 0.80 0.8 0.15]);      
         ylabel('True');  
         subplot(3,1,2);
         plot(x,y,'.')
         set(gca, 'XTick', []); 
         set(gca, 'Position', [0.1 0.25 0.8 0.5]); 
         pause(1);
      end
   end
   
   if bDisplay==1
      unique_t = unique(t);
      tables_used = [phi(unique_t,[1 2 4]) 1./phi(unique_t,3)]
      unique_dishes_used = unique(tables_used(:,1));
      dishes_used = [unique_dishes_used  theta(unique_dishes_used,:)]
   end

   %----  Save to file
   if ~isempty(fn)
      res(iter).theta = theta;
      res(iter).phi = phi;
      res(iter).t = t;
      if ~isempty(s)
         res(iter).hamming_dist = hd;
      end
      save(fn, 'res'); 
   end
   

end  %main Gibbs iter



