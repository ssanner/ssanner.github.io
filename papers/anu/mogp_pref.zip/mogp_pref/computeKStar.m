function [k_star, k_u, k_x] = computeKStar(u, users_idx, x, items_idx, user, ...
                item_pair, covfunc_u, covfunc_x, params_u, params_it)

    k_x = zeros(2, length(items_idx) ); 
    for i = 1 : length(items_idx)
        if items_idx(i) < 1
            continue;
        end
        tx = [x(items_idx(i),:); item_pair];
        kk = feval (covfunc_x, params_it{1,2}, params_it{2,2}, params_it{3,2}, tx); 
        k_x(1, i) = kk(1,2);
        k_x(2, i) = kk(1,3);
    end

    k_u = zeros(1,length(users_idx));
    for i = 1 : length(users_idx) 
        if users_idx(i) < 1
            continue;
        end
        tu = [u(users_idx(i),:); user];
        kk = feval (covfunc_u, params_u{1,2}, params_u{2,2}, params_u{3,2}, tu);  
        k_u(i) = kk(1,2);
    end

    k_star = kron(k_u, k_x);
end