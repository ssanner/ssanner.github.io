function [item_ids] = get_best_item(pref, ui)

if isempty(pref) || size(pref,1) == 0, 
        item_ids = []; 
        return; 
end;

p = pref(pref(:,1) == ui,:);
item_ids = unique(p(~ismember(p(:,2), p(:,3)),2));
count = 1;
idx = [];
while exist('k', 'var') && k > length(item_ids)
    if isempty(idx),
        idx = find_items_count(p);
    end
    item_ids = unique( [item_ids, idx{count}] );
    count = count + 1;
end

return ;

function [idx] = find_items_count(p)
   ids = find(ismember(p(:,2),p(:,3)));
   l = unique([p(:,2);p(:,3)]);
   idx = cell(1,l);
   for i = ids
       temp = find(ismember(p(i,2), p(:,3)));
       l = length(temp);
       if isempty(l) || l < 1, continue, end;
       if isempty(idx{l})
           idx{length(temp)} = p(i,2);
       else
           idx{length(temp)} = [idx{length(temp)}, p(i,2)];
       end
   end
return ;