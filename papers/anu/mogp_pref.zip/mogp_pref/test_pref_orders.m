
function [user_loss util_loss wrongs] = test_pref_orders(users, pref_test, pref_orders, item_count, util)
global FID_RESULTS FID_TEST

user_loss = zeros(length(users), 1);
util_loss = zeros(length(users), 1);
wrongs = zeros(length(users), 1);
for u_i = 1 : length(users)
    ui = users(u_i);
    test = get_partial_prefs(pref_test, ui, item_count);
    
    best_test = get_best_item(pref_test, ui);
    best_predict = get_best_item(pref_orders, ui);

    if ~isempty(util)
        idx = [1:item_count] + item_count * (ui-1);
        temp = util(idx);
        util_loss(u_i) = sum(max(temp) - max((temp(best_predict))));        
    end
   
   wrongs(ui) = sum(ismember(best_predict, best_test) == 0);
   %length(~ismember(best_predict, best_test)); % + length(~ismember(best_test, best_predict));
   user_loss(ui) = 0;
    for j = 1 : length(best_predict)
       user_loss(ui) = user_loss(ui) + length(test{best_predict(j)}) ;
    end

    if(FID_TEST> 0)
        fprintf(FID_TEST, 'user (%2.0f) loss: %d\n', ui, user_loss(ui));
    end     
  %  fprintf('user (%2.0f) loss: %d\n', ui, user_loss(ui));

end
