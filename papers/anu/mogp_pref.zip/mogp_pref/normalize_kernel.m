function normalize_kernel(K)
    for i = 1 : size(K,1)
        for j = i+1 : size(K,1)
            K(i,j) = K(i,j) / sqrt( K(i,i) * K(j,j) );
        end    
    end
return 