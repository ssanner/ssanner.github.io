% k: number of items to be selected
% mu, Sigma: parameters of the probability of the utility
function [selection] = set_selection(alg, k, mu, Sigma, items)
    global x
    if strcmp(alg, 'meu') % max expected utility
        [dumy, idx] = sort(mu, 'descend');

    else 
        no_samples = int32( log(2/.01)/(2*.8^2) + 1 ); %.8 > .1
        results = zeros(length(items),1);
        for i = 1 : length(items)
            s = 0;
            for iter = 1 : no_samples
                idx = [];
                while ismember(i, idx) || length(idx) < k-1,
                    idx = randint(1, k-1, [1,length(items)]);
                end            
                s = s + (v([idx,i], mu, Sigma) - v(idx,mu, Sigma));
            end
            results(i) = s;
        end
        
        [dumy, idx] = sort(results);
    end
	selection = items( idx(1:k) );
return ;

% This is the anticipated utility 
% \sum_{i=1}^n\left[ w(\sum_{j=1}^i p_j) - w(\sum_{j=1}^{i-1} p_j) \right] u_i 
% with w(p) = p.
% for the moment: sum(EU)
function [ans] = v(idx, mu, Sigma)
    % ans = sum(mu(idx));
    % temp = 1.5 * mu(idx) -.5 * diag(Sigma(idx,idx));
	% temp = -.5 * diag(Sigma(idx,idx));
	temp = max(mu(idx)) -  mu(idx);
    ans = sum(temp(:));
return ;

function [ans] = w(p,idx)
    ans = sum(p(idx));
return ;