function  mogp_simple( suffix ,test_all )
global x u pref K_star k_inv gam FID_SET_SELECTION FID_RESULTS FID_SET_SELECTION_USER

	x = dlmread(strcat('../gp_ep/data/x_', suffix , '.csv'));
	u = dlmread(strcat('../gp_ep/data/u_', suffix , '.csv'));
	pref = dlmread(strcat('../gp_ep/data/pref_', suffix , '.csv'));
	pref_test = strcat('../gp_ep/data/pref_', suffix , '_test.csv');
  
    covfunc_u = 'ard_kernel_m'; 
    covfunc_x = 'ard_kernel_m'; 

    [params_u, params_it] = load_kernel_params(suffix);
        
	K_u = 1; % sparse( feval (covfunc_u, params_u{1,2}, params_u{2,2}, params_u{3,2}, u) );  
	K_it = sparse( feval (covfunc_x, params_it{1,2}, params_it{2,2}, params_it{3,2}, x) ); 
	K_star = kron(K_u, K_it);
	k_inv = sparse( kron(inv(correct_singular(K_u)), inv(correct_singular(K_it))) );

	gam = .3;
    
    NUM_ITER = 50;

    item_count = size(x,1);
    user_count = size(u,1);

    if strcmp(suffix, 'car60') || strcmp(suffix, 'car20')
        alpha = 1e2;  %.05
        CLASSES_COUNT=ceil(user_count/2);
    else
         alpha = .5; % .2
         CLASSES_COUNT=user_count / 1;
    end
    % each kernel has to be specific for a group of users.
	
    [FID_SET_SELECTION set_selection_filename] = get_results_file([suffix '_set']); 
    % set_selection_filename = ['results/' set_selection_filename];
     
    [FID_SET_SELECTION_USER user_filename] = get_results_file([suffix '_user']); 
    % user_filename = ['results/' user_filename];

    [FID_RESULTS filename dumy dt] = get_results_file([suffix]); 
    clear dumy;
    
    item_comunity_filename = ['results/item_community' suffix dt];
    user_community_filename = ['results/community_users' suffix dt '.csv'];   
    pc_filename = ['results/community_pc_' suffix dt '.csv'];   
   
    %% all users together
    if test_all
        Sigma = cell(1,1);
        nu = cell(1,1);
        mu = cell(1,1);
        c = ones(user_count,1);
        p_c = ones(user_count,length(unique(c)));

        [Sigma{1}, nu{1}, mu{1}] = ep_efficient_inverse_sparse( k_inv, pref, gam, size(x,1) );    
        [t_test, c_mean, c_std, test_count, pref_loss, ...
                pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std] ...
                    = test_preference(1:size(u,1), 1:size(x,1), Sigma, nu, mu, x, u, pref, ...
                         pref, covfunc_u, covfunc_x, params_u, params_it, 'ep', unique(c), c, p_c, '', item_count*user_count, item_comunity_filename);

        return ;
    end
    %% end of all users together

 	c = randint(1, user_count, [1,CLASSES_COUNT]); % 1:user_count; % zeros(size(u,1),1);
	p_c = ones(user_count,user_count) ./ user_count;
    Sigma = cell(user_count,1);
    mu = cell(user_count,1);   
    nu = cell(user_count,1);   
    optimize_kernel = false;    
    c_length_prev = 1;
    
    do_inference;
    
    user_community_mat = [];
    p_c_mat = [];
    
    try    
	for iteration = 1 : NUM_ITER
        c_length = length(unique(c));
        fprintf('# Unique c: %d @iter: %d\n', c_length, iteration);     
               
        user_community_mat = [user_community_mat; [iteration, c]];       
        p_c_mat = [p_c_mat; [iteration, prod(p_c)]];
        
        % item community
        if iteration > 2
            item_community = zeros(length(c),item_count);
            for i = 1 : size(pref,1)
                user_group_idx = c(pref(i, 1));
                item_community(user_group_idx, pref(i, 2)) = item_community(user_group_idx, pref(i, 2)) + 1;
            end
            dlmwrite([item_comunity_filename '_' num2str(length(unique(c))) '.csv'], item_community);                        
        end
        
        if c_length == c_length_prev && iteration > 35 ,
            break ;
        end               

        c_length_prev = c_length;
        
        no_pref = size(pref,1);
		% sample p(c|D)
		method_used = 2;
        n_all = length(unique(c));
        for i = 1 : user_count
            for j = unique(c)
                s = 0;
                normalizer = 0;
                if method_used == 1,
                    for ip = 1 : user_count
                        temp = count_similar_prefs(i,ip);
                        if c(ip) == j, 
                            s = s + temp;
                        end
                        normalizer = normalizer + temp;
                    end
                    n_ij = s * (no_pref-1) / normalizer;
                    n_all = no_pref;
                   
                if s > 0,      
                    p_c(i,j) = n_ij;
                else
                    p_c(i,j) = alpha/(n_all);
                end
                p_c(i,j) = p_c(i,j) / (n_all - 1 + alpha);
                
                elseif method_used == 2,
                    ism=find( ismember(pref(:,1), i) == true );
                    if length(ism) > 10,
                        ism = ism(randperm(length(ism), 5));                    
                    end
                    sub_pref = pref(ism,:);                    
                    p_c(i,j) = sum(c == j);
                    if p_c(i,j) == 0, p_c(i,j) = alpha; end;
                    p_c(i,j) = p_c(i,j) ./ (length(unique(c)) + alpha);
%                   if c(i) ~= j,
%                       cc = c(i);
%                       [mu,nu,Sigma,orig_mu,orig_nu,orig_S,orig_mu_j,orig_nu_j,orig_S_j,user_group_idx]=...
%                           change_params_sampling(i,j,c, mu, nu, Sigma);
%                       c(i)=j;
%                   end
                    [t, c_mean, c_std, test_count, loss, loss_std, sh_loss, sh_loss_std, wrongs, wrongs_std prob] = ...
                             test_preference(1:size(u,1), 1:size(x,1), Sigma, ...
                                    nu, mu, x, u, sub_pref, ...
                                    sub_pref, covfunc_u, covfunc_x, params_u, params_it, ...
                                    'p_c', unique(c), c, p_c, '', item_count*user_count, '');
                    s = sum(prob(prob~=inf));
                    if s < -7e+2,
                        if c_mean > 0,
                            s = -2e+2;
                        else
                            s = -7e+2;
                        end
                    elseif s > 5e+2
                        if c_mean > 0
                            s = 7e+2;
                        else                            
                            s = 5e+2;
                        end
                    end
                    p_c(i,j) = exp(s) * p_c(i,j);
                    n_ij = s; %1/s;
%                     if c(i) ~= j,
%                         c(i) = cc;
%                         mu{user_group_idx} = orig_mu;
%                         nu{user_group_idx} = orig_nu;
%                         Sigma{user_group_idx} = orig_S;                    
%                         mu{j} = orig_mu_j;
%                         nu{j} = orig_nu_j;
%                         Sigma{j} = orig_S_j;
%                     end
                end
            end
             p_c(i,:) =  p_c(i,:) ./ sum( p_c(i,:) );
             if sum(p_c(i,:)) == 0,
                 p_c(i,:) = 1 / c_length;
            end
        end            
        
        for i = 1 : user_count
            idx = find( p_c(i,:) == max(p_c(i,:)) );
            c(i) = idx( randperm(length(idx),1) );
        end
        
        % clear parameters from the last iteration
        % here we can learn the parameters for each group
        for j = 1 : size(mu, 1)
            Sigma{j} = [];
            mu{j} = [];
            nu{j} = [];
        end
        
%         % do inference for the p(f|c,D) using EP
        do_inference;
% 		for j = unique(c)			
%             users_idx = find(c == j);
% 			if ~isempty(users_idx),          
% 	    		[S_, nu_, mu_] = ep_efficient_inverse_sparse( k_inv, pref(ismember(pref(:,1), users_idx),:), gam, size(x,1) );
%                 idx = find_global_idx(users_idx, 1:size(x,1), item_count);                
%                 Sigma{j} = S_(idx,idx);
%                 nu{j} = nu_(idx);
%                 mu{j} = mu_(idx);
% 	    	end
% 		end
%         
%         [t_test, c_mean, c_std, test_count, pref_loss, ...
%             pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std] ...
%                 = test_preference(1:size(u,1), 1:size(x,1), Sigma, nu, mu, x, u, pref, ...
%                		 pref_test, covfunc_u, covfunc_x, params_u, params_it, 'ep', unique(c), c, '', item_count*user_count);

    end

 %   optimize_kernel = false;
 %   do_inference;
    
    [t_test, c_mean, c_std, test_count, pref_loss, ...
            pref_loss_std, util_loss, util_loss_std, wrongs, wrongs_std] ...
                = test_preference(1:size(u,1), 1:size(x,1), Sigma, nu, mu, x, u, pref, ...
               		 pref_test, covfunc_u, covfunc_x, params_u, params_it, 'ep', unique(c), c, p_c, '', item_count*user_count);
	
	fclose('all');
    
    catch ex
        
    end
    
    dlmwrite([user_community_filename], user_community_mat, '-append');
        
    dlmwrite([pc_filename], p_c_mat, '-append');
    
    
    
    item_comunity_filename= [strrep(item_comunity_filename, 'results/', ''), '.csv'];
    user_community_filename=[strrep(user_community_filename, 'results/', '') '.csv'];
%    plot_accuracy(suffix, filename, item_comunity_filename, user_community_filename, ...
%                                set_selection_filename, user_filename);
return ;

function [count] = count_similar_prefs(i, j)
global pref
	
    count = 0;    
	
    if i == j,
		return ;
	end;
   
    pref_i_idx = find(pref(:,1) == i);
    pref_j_idx = find(pref(:,1) == j);
    for ii = 1 : length(pref_i_idx)
        for jj = 1 : length(pref_j_idx)
            if pref(pref_i_idx(ii),2) == pref(pref_j_idx(jj),2) && ...
                pref(pref_i_idx(ii),3) == pref(pref_j_idx(jj),3)
                count = count + 1;
                break;
            end
        end
    end

return ;
