////////////////////////////////////////////////////////
// Class:  BaseRepPlayer
// Author: Scott P. Sanner
//
// Description:
//
// This class defines the base feature representation that
// will be used for the implementation of the {ACT-R/TD}/
// {Symbolic-PM/Neural} Backgammon players.
//
////////////////////////////////////////////////////////

#ifndef _BASEREPPLAYER_H_
#define _BASEREPPLAYER_H_

#include <stdlib.h>
#include <math.h>
#include "Backgammon.h"
#include "BackgammonDisplay.h"
#include "Player.h"
#include "Feature.h"
#include "Random.h"

// Uncomment the following line to see a printout of the features
#define BASEREP_PRINT_FEATURES

class BaseRepPlayer: public Player
{
	public:
		BaseRepPlayer();
		virtual ~BaseRepPlayer();
		virtual void DeriveFeatures(Backgammon *p, int mv);
		virtual bool PlayTurn(Backgammon* p);
		virtual int  CalcRaceCondHeuristic(int mv);

		void  SetConflictResTemp(float val) { CONFLICT_RES_TEMP = val;        }
		float GetConflictResTemp()          { return CONFLICT_RES_TEMP;       }        
		void  SetMinBlotPenalty (float val) { EXPOSE_BLOT_MIN_PENALTY = val;  }
		float GetMinBlotPenalty ()          { return EXPOSE_BLOT_MIN_PENALTY; }        
		void  SetMaxBlotPenalty (float val) { EXPOSE_BLOT_MAX_PENALTY = val;  }
		float GetMaxBlotPenalty ()          { return EXPOSE_BLOT_MAX_PENALTY; }        

		////////////////////////////////////////////////////////////////////////////
		// Knowledge Representation and Learning Update implementation 
		// dependent class methods...
		virtual void Reset();                // Indicates beginning of game
		virtual void Update(bool win, int blot_pt); // Indicates win/loss
		virtual void SetMoveUtilities() = 0; // Sets m_aMoveValue array for each move
		virtual void SelectMove(int mv) = 0; // Indicates which move was selected
		////////////////////////////////////////////////////////////////////////////

	protected:
		static int m_nATTACK; // These will be added to feature
		static int m_nBLOCK;  // and then used as the feature
		static int m_nEXPOSE; // type ID

		RandomGen m_rv;      // For stochastic move selection

		int m_nMoves;     // Number of potential moves for this turn
		int m_nGameMoves; // Number of moves overall for the entire game

		int m_nTotalWins;   // Number of total wins 
		int m_nTotalLosses; // Number of total losses 

		bool  m_aInitialOpp[POINT_ELE];    // Is an opponent on this point in the
		                                   // initial board configuration?
		int   m_nOpponentsAhead[POINT_ELE];// Counts the number of opponents
		                                   // ahead of the point
		int   m_nOpponentsAheadNear[POINT_ELE];// Counts the number of opponents
		                                       // ahead of the point
		float m_aMoveValue[MAX_POSSIBLE_MOVES]; // Value for move from a given turn

		FeatureArray m_aMoveFeatureSet[MAX_POSSIBLE_MOVES]; // FeatureArray for each 
			 		    									// potential move on a turn
		Feature      m_fTemp;  // Temporary Feature
		int          m_aBoreOff[MAX_POSSIBLE_MOVES];           // Next two are for heuristic
		int          m_aMinRemainingMoves[MAX_POSSIBLE_MOVES]; // calculation in the race cond

		bool         m_bRace;  // Is this player in the race state yet?  (i.e. all 
							   // players on home board?)

		float  CONFLICT_RES_TEMP;      /* Divide by this value, the smaller it       *
					                    * is, the greater the differentiation        *
									    * in selection.  (0.1) yields a 3:1 odds     *
									    * for moves differing by .1 on a [0,1] scale */
		
		float EXPOSE_BLOT_MIN_PENALTY; /* Determines what fraction of a loss should  */
		float EXPOSE_BLOT_MAX_PENALTY; /* be the min/max penalty for an expose that  *
									    * led to a blot                              */
		                               
		#ifdef BASEREP_PRINT_FEATURES
		TextDisplay *m_disp;
		ofstream     m_outfile;
		#endif

		////////////////////////////////////////////////////////////////////////////
		// Knowledge Representation and Learning Update implementation 
		// dependent data members to be added in derived subclass
		////////////////////////////////////////////////////////////////////////////
};

#endif // _BASEREPPLAYER_H_
