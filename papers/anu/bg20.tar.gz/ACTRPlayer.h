////////////////////////////////////////////////////////
// Class:  ACTRPlayer
// Author: Scott P. Sanner
//
// Description:
//
// A Backgammon player that uses the ACT-R cognitive
// architecture for its representation and decision
// making.
//
// Interesting ideas to check out as time permits:
//
// 1) Allow a weighted match during the match phase
//    to allow interpolation between points. (Perhaps
//    try metrics other than the city block metric.)
//
// 2) Allow a weighted update based on the partial
//    match score, update all features that partial matched.
//
// 3) Check out different functions for the partial
//    match... average, odds, any others?
//
// The key knowledge representation and learning
// methods and data members are indicated below.  The
// various player versions will inherit from this
// class to implement these functions.  The rest of the
// feature representation, move selection code should
// be common to all players developed under the research
// framework.
//
////////////////////////////////////////////////////////

#ifndef _ACTRPLAYER_H_
#define _ACTRPLAYER_H_

#undef NDEBUG

#include <stdlib.h>
#include <fstream.h>
#include "Backgammon.h"
#include "BaseRepPlayer.h"
#include "Feature.h"

// Uncomment the following line to see a printout of debug info for the player
//#define ACTR_PRINT_DEBUG

class ACTRPlayer: public BaseRepPlayer
{
	public:
		ACTRPlayer(int filenum);
		virtual ~ACTRPlayer();

		virtual void Reset();            // Indicates beginning of game
		virtual void Update(bool win, int blot_pt); // Indicates end of game and win/loss
										            // or blot_pt if not (-1)
		virtual void SetMoveUtilities(); // Sets m_aMoveValue array for each move
		virtual void SelectMove(int mv); // Indicates which move was selected

		void  SetPMThreshold(float val) { PM_THRESHOLD = val;  }
		float GetPMThreshold()          { return PM_THRESHOLD; }

		void  SetLambda(float val) { LAMBDA = val;  }
		float GetLambda()          { return LAMBDA; }

	protected:
		FeatureArray  m_faPrevMoves; // FeatureArray of previous chunked moves
		MatchSetArray m_msaTurn[MAX_POSSIBLE_MOVES]; // Array [move] of MatchSetArray
		                                             // which has a MatchSet for each
		                                             // feature
		MatchSetArray m_msaMoves; // MatchSetArray of move features from 0 to end of game

		MatchSet     m_msTemp; // Temporary MatchSet

		int  m_nFeatures;   // Number of chunked (compiled) features
		bool m_bLearningOn; // Is learning on?
		bool m_bNearestNeighborOn; // Use nearest neighbor weighting?

		float PM_THRESHOLD; /* The match penalty threshold */
		float LAMBDA;       /* The TD(lambda) like discount rate */

		int m_nFilenum; // For running multiple ACT-R instantiations at one time

		#ifdef ACTR_PRINT_DEBUG
		TextDisplay *m_adisp;
		ofstream     m_aoutfile;
		#endif

	private:
		ACTRPlayer() {} // Prevent from being called
};

#endif // _ACTRPLAYER_H_