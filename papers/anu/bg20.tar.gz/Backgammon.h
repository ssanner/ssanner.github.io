////////////////////////////////////////////////////////
// Class:  Backgammon
// Author: Scott P. Sanner
//
// Description:
//
// This is the main Backgammon board game class which
// takes two instances of class player and plays them
// head to head.
//
////////////////////////////////////////////////////////

#ifndef _BACKGAMMON_H_
#define _BACKGAMMON_H_

#include <fstream.h>
#include "Random.h"
#include "Trace.h"

// Debug - Comment out the following line to turn off debug checking
//#undef NDEBUG

#define TRACE_PRIORITY -1
#define POINT_ELE 26 /* Two extra for bar and bore-off */
#define POINTS    24
#define NUM_DICE  2
#define PLAYERS   2
#define BAR       0
#define BORE_OFF  (POINTS+1)
#define OPLAYER   (WHITE)
#define XPLAYER   (BLACK)
#define ABS(X)   (((X)<0)?(-(X)):(X))
#define MAX(X,Y) (((X)<(Y))?(Y):(X))
#define MIN(X,Y) (((X)<(Y))?(X):(Y))
#define MAX_MOVES_TURN       4
#define MAX_POSSIBLE_MOVES 1536 /* A pretty large overestimate */
#define DIE_ONE 0
#define DIE_TWO 1

// Type definitions
enum bgplayer {WHITE = 0, BLACK = 1, NEITHER = 2, BOTH = 3};
enum diceroll {INVALID_ROLL = 0, ROLL1 = 1, ROLL2 = 2, ROLL3 = 3, 
               ROLL4 = 4, ROLL5 = 5, ROLL6 = 6};
typedef int point;

// The representation for a single pt-pt move
struct SMoveElement
{	
	int m_nSrc;
	int m_nDest;
};

// The representation for a complete turn move
struct SMoveChunk
{
	SMoveElement m_elem[MAX_MOVES_TURN];
	int m_nMoveElems;

	// Features
	bool Match(SMoveChunk &e);
};

// The basic point represenation
struct SPoint
{
	int m_nMen[PLAYERS];
};

class Player;
class BackgammonDisplay;

//   The backgammon game representation class:
// =============================================
//
//      X Outer Table          X Home Table
// +-------------------+---+-------------------+
// | 13 14 15 16 17 18 |   | 19 20 21 22 23 24 |
// |  O  |  |  |  X  | |   |  X  |  |  |  |  O |
// |  O  |  |  |  X  | |   |  X  |  |  |  |  O |
// |  O  |  |  |  X  | |   |  X  |  |  |  |  | |
// |  O  |  |  |  |  | |   |  X  |  |  |  |  | |
// |  O  |  |  |  |  | |   |  X  |  |  |  |  | |
// |                   | B |                   |
// +-------------------+ A +-------------------+
// |                   | R |                   |
// |  X  |  |  |  |  | |   |  O  |  |  |  |  | |
// |  X  |  |  |  |  | |   |  O  |  |  |  |  | |
// |  X  |  |  |  O  | |   |  O  |  |  |  |  | |
// |  X  |  |  |  O  | |   |  O  |  |  |  |  X |
// |  X  |  |  |  O  | |   |  O  |  |  |  |  X |
// | 12 11 10 09 08 07 |   | 06 05 04 03 02 01 |
// +-------------------+---+-------------------+
//      O Outer Table          O Home Table
//
//        Turn: *White(O)*  Dice: *5* *6*

class Backgammon
{
	public:
		// Public Methods
		Backgammon(Player* white, Player* black, BackgammonDisplay* disp);
		virtual ~Backgammon();

		// Translations
		inline point    AbsolutePos(bgplayer p, point rel_pos); 
		inline point    RelativePos(bgplayer p, point abs_pos);
		inline bgplayer GetOtherPlayer(bgplayer p);
		inline char*    GetPlayerName (bgplayer p);  

		// Game state retrieval
		inline bgplayer WhoHasWon();     // Returns who has won game
		inline bgplayer WhoIsBearing();  // Returns who is bearing men
		inline diceroll GetDiceRoll(int die_num); // Returns given die roll
		inline bgplayer GetCurPlayer();  // Returns current player
		inline bool     IsDoubles();     // Returns true if dice are the same
		
		bool GenerateMoves    (bgplayer p);
		int  PopulateMovesetND(bgplayer p, SMoveChunk mv[], int moves,
			                   int die1, int die2);
		int  PopulateMovesetD (bgplayer p, SMoveChunk mv[], int moves, 
			                   int die, int rolls_left, int indiv_moves,
							   int rel_curpt);
		int  PopulateMovesetBest(bgplayer p, SMoveChunk mv[], int moves, 
			                   int die1, int die2);
		void DeriveFeatures   (bgplayer p, Player* player);
		void DeriveFeatures   (bgplayer p, Player* player, int mv, int moves);

		// Game state commands
		void     ResetGame();            // Returns first player
		bgplayer StartGame();            // Returns first player
		void     MakeMove(bgplayer p, int move_num);
		bool     MakeMove(bgplayer p, point abs_source, point abs_dest, bool place);
		bool     UndoMove(bgplayer p, point abs_source, point abs_dest, bool opp_bumped, bool place);
		bool     IsLegalMove(bgplayer p, point abs_source, point abs_dest, int die);

		friend class BackgammonDisplay;

	public: // Since friend status does not extend to Inherited classes
		SPoint     m_aPoint[POINT_ELE];  // Allow BAR to be m_aPoint[0],
									     // BORE_OFF to be m_aPoint[POINTS+1]
		SMoveChunk m_aMoves[MAX_POSSIBLE_MOVES];
		diceroll   m_aDice [NUM_DICE];
		int        m_nHomeBoard[PLAYERS];// Who is bearing their players
		bool       m_bDoubles;
		bool       m_bMoveMade;
		bgplayer   m_nTurn;
		int        m_nTurnsPlayed;
		int        m_nValidMoves;

		static char m_sPlayerName[2][9];
		BackgammonDisplay *m_display;

	private:
		// Private Methods
		Backgammon() {} // Prevent from calling
		
		// Internal methods
		void RollDice();

		// Private Data
		Player* m_aPlayer   [PLAYERS];  // Player pointers

		RandomGen          m_rg;

		#ifndef NDEBUG
		BackgammonDisplay *m_tdisplay;
		Trace             *m_tm;
		ofstream           trace_file;
		#endif
};


// Inline Methods:
diceroll Backgammon::GetDiceRoll(int die_num)
{
	if ((die_num < 1) || (die_num > 2))
		return INVALID_ROLL;

	return m_aDice[die_num-1];
}

bgplayer Backgammon::GetCurPlayer()
{
	return m_nTurn;
}

bool Backgammon::IsDoubles()
{
	return m_bDoubles;
}

// Black goes from 1-24, White from 24-1, Relative position
// assumes that 1 is the starting position and 24 is 
// destination... BAR and BORE_OFF are also relatively
// indexed
point Backgammon::AbsolutePos(bgplayer p, point rel_pos) 
{ 
    if (rel_pos < BAR)      rel_pos = BAR;
	if (rel_pos > BORE_OFF) rel_pos = BORE_OFF;
	return ((p == BLACK) ? rel_pos : POINTS + 1 - rel_pos); 
}

point Backgammon::RelativePos(bgplayer p, point abs_pos) 
{ 
    if (abs_pos < BAR)      abs_pos = BAR;
	if (abs_pos > BORE_OFF) abs_pos = BORE_OFF;  
	return ((p == BLACK) ? abs_pos : POINTS + 1 - abs_pos);	
}

bgplayer Backgammon::GetOtherPlayer(bgplayer p)                        
{
	return ((p == BLACK) ? WHITE : BLACK); 
}

bgplayer Backgammon::WhoHasWon()
{
	if (m_aPoint[AbsolutePos(BLACK,BORE_OFF)].m_nMen[BLACK] == 15)
		return BLACK;
	else if (m_aPoint[AbsolutePos(WHITE,BORE_OFF)].m_nMen[WHITE] == 15)
		return WHITE;
	else
		return NEITHER;
}

bgplayer Backgammon::WhoIsBearing()
{
	if ((m_nHomeBoard[WHITE] == 15) && (m_nHomeBoard[BLACK] == 15))
		return BOTH;
	else if (m_nHomeBoard[WHITE] == 15)
		return WHITE;
	else if (m_nHomeBoard[BLACK] == 15)
		return BLACK;
	else
		return NEITHER;
}

char* Backgammon::GetPlayerName(bgplayer p)
{
	return m_sPlayerName[p];
}

#endif // _BACKGAMMON_H_
