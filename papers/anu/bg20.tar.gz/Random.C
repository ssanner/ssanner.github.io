#include "Random.h"

//int RandomGen::INC = 57786696;
