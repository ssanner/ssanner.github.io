#include <string>
#include <ctype.h>
#include "Player.h"
#include "BackgammonDisplay.h"

// The virtual base class player
void Player::SetPlayer(bgplayer p)
{
	me = p;
}

void Player::DeriveFeatures(Backgammon *p, int mv)
{

}  

// A dumb player (picks random move)
RandomPlayer::RandomPlayer()
{
	rg.InitRVSeed();
}

bool RandomPlayer::PlayTurn(Backgammon* p)
{
	if (p->m_nValidMoves > 0)
	{
		p->MakeMove(me, rg.UniformIntRV(0,p->m_nValidMoves-1));
	}
	return true;
}

// A bad player (always picks first move)
StaticPlayer::StaticPlayer()
{

}

bool StaticPlayer::PlayTurn(Backgammon* p)
{
	bool any_moves = (p->m_nValidMoves > 0);
	if (any_moves)
		p->MakeMove(me, 0);
	return true;
}

// The set of structures used for the move representation
TextPlayer::TextPlayer()
{

}

TextPlayer::~TextPlayer()
{

}

bool TextPlayer::PlayTurn(Backgammon* p)
{
	int src, dest, n, m;
	bool cont = false, match = false, any_moves = (p->m_nValidMoves > 0);
	char str1[80], str2[80];
	SMoveChunk move;

	cout << endl;
	cout << p->GetPlayerName(me) << "'s turn (<src dest>*|m #|h|d|e): ";
	while(!cont && any_moves)
	{
		move.m_nMoveElems = 0;
		for (m=0; m<5; m++)
		{
			// Convert first input
			cin >> str1;
			if ((toupper(str1[0]) == 'E') || ((toupper(str1[0]) != 'E') && (m == 4))) break;
			else if (toupper(str1[0]) == 'H') 
				{ p->m_display->DisplayMoveSet(p, me); break; }
			else if (toupper(str1[0]) == 'B')
				src = p->AbsolutePos(me,BAR);
			else if (toupper(str1[0]) == 'D')
			    { p->m_display->DisplayGameInfo(p); cout << endl; break; }
			else if (toupper(str1[0]) == 'M')
				{ cin >> n; match = (--n<=p->m_nValidMoves); break; }
			else 
				if (!isdigit(str1[0])) break;
			else
				src = atoi(str1);

			// Convert second input
			cin >> str2;
			if (toupper(str2[0]) == 'O')
				dest = p->AbsolutePos(me,BORE_OFF);
			else 
				if (!isdigit(str2[0])) break;
			else
				dest = atoi(str2);

			move.m_nMoveElems++;
			move.m_elem[m].m_nSrc = src;
			move.m_elem[m].m_nDest = dest;
		}

		if (match) break;

		for (n=0; n<p->m_nValidMoves; n++)
			if (cont = move.Match(p->m_aMoves[n])) break;

		if (!cont)
			cout << "Enter a move... (<src dest>*|m #|h|d|e): ";
	}

	if (any_moves)
		p->MakeMove(me, n);

	return true;
}
