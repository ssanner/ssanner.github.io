#include "Feature.h"

//////////////////////////////////////////////////////////////////////////
// Feature methods
//////////////////////////////////////////////////////////////////////////

// Max size for PT, OP, SZ... zero assumed as base
int   Feature::m_nDefined                    = 0; // Number of defined types
int   Feature::m_aMaxValues[NUM_SFEATS]      = {MAX_PTS, MAX_OPP, MAX_ADJ, MAX_OPP, MAX_BAR};
char  Feature::m_sFName[NUM_TYPES][NAME_LEN] = {"PT","OP","SZ","ON","OB"};
int   Feature::m_nTotalWins;
int   Feature::m_nTotalLosses;

// Is the PT,OP,SZ field used for partial matching
bool  Feature::m_aUsed [NUM_TYPES][NUM_SFEATS]; 
char *Feature::m_sName [NUM_TYPES]; // Store type names for printing

Feature::Feature()
{
	m_nType   = (-1);
	m_fWins   = INIT_WINS;   // Start this feature out with a neutral utility
	m_fLosses = INIT_LOSSES; // so that it will be used until learned otherwise
}

void Feature::SetFeature(int type, int pt)
{
	// The following code checks arguments for correctness, it should
	// not be compiled into the runtime version
	#ifndef NDEBUG
	int i;
	if ((type < 0) || (type >= m_nDefined)) { cerr << "SetFeature: Illegal 1\n"; exit(-1); }
	for (i=PT; i<=PT; i++)
		if (!m_aUsed[type][i]) { cerr << "SetFeature: Illegal 2\n"; exit(-1); }
	for (i=OP; i<NUM_SFEATS; i++)
		if (m_aUsed[type][i]) { cerr << "SetFeature: Illegal 3\n"; exit(-1); }
	#endif
	m_nType = type;
	m_aSFeats[PT] = pt;
	m_fWins   = INIT_WINS;   // Start this feature out with a neutral utility
	m_fLosses = INIT_LOSSES; // so that it will be used until learned otherwise
}

void Feature::SetFeature(int type, int pt, int op)
{
	#ifndef NDEBUG
	int i;
	if ((type < 0) || (type >= m_nDefined)) { cerr << "SetFeature: Illegal 4\n"; exit(-1); }
	for (i=PT; i<=OP; i++)
		if (!m_aUsed[type][i]) { cerr << "SetFeature: Illegal 5\n"; exit(-1); }
	for (i=SZ; i<NUM_SFEATS; i++)
		if (m_aUsed[type][i]) { cerr << "SetFeature: Illegal 6\n"; exit(-1); }
	#endif
	m_nType = type;
	m_aSFeats[PT] = pt;
	m_aSFeats[OP] = op;
	m_fWins   = INIT_WINS;   // Start this feature out with a neutral utility
	m_fLosses = INIT_LOSSES; // so that it will be used until learned otherwise
}

void Feature::SetFeature(int type, int pt, int op, int sz)
{
	#ifndef NDEBUG
	int i;
	if ((type < 0) || (type >= m_nDefined)) { cerr << "SetFeature: Illegal 7\n"; exit(-1); }
	for (i=PT; i<=SZ; i++)
		if (!m_aUsed[type][i]) { cerr << "SetFeature: Illegal 8\n"; exit(-1); }
	for (i=SZ+1; i<NUM_SFEATS; i++)
		if (m_aUsed[type][i]) { cerr << "SetFeature: Illegal 9\n"; exit(-1); }
	#endif
	m_nType = type;
	m_aSFeats[PT] = pt;
	m_aSFeats[OP] = op;
	m_aSFeats[SZ] = sz;
	m_fWins   = INIT_WINS;   // Start this feature out with a neutral utility
	m_fLosses = INIT_LOSSES; // so that it will be used until learned otherwise
}

void Feature::SetFeature(int type, int pt, int op, int sz, int on)
{
	#ifndef NDEBUG
	int i;
	if ((type < 0) || (type >= m_nDefined)) { cerr << "SetFeature: Illegal 10\n"; exit(-1); }
	for (i=PT; i<=ON; i++)
		if (!m_aUsed[type][i]) { cerr << "SetFeature: Illegal 11\n"; exit(-1); }
	for (i=ON+1; i<NUM_SFEATS; i++)
		if (m_aUsed[type][i]) { cerr << "SetFeature: Illegal 12\n"; exit(-1); }
	#endif
	m_nType = type;
	m_aSFeats[PT] = pt;
	m_aSFeats[OP] = op;
	m_aSFeats[SZ] = sz;
	m_aSFeats[ON] = on;
	m_fWins   = INIT_WINS;   // Start this feature out with a neutral utility
	m_fLosses = INIT_LOSSES; // so that it will be used until learned otherwise
}

void Feature::SetFeature(int type, int pt, int op, int sz, int on, int ob)
{
	m_nType = type;
	m_aSFeats[PT] = pt;
	m_aSFeats[OP] = op;
	m_aSFeats[SZ] = sz;
	m_aSFeats[ON] = on;
	m_aSFeats[OB] = ob;
	m_fWins   = INIT_WINS;   // Start this feature out with a neutral utility
	m_fLosses = INIT_LOSSES; // so that it will be used until learned otherwise

	// Just check to ensure that if a var is not used, it is set to 0
	#ifndef NDEBUG
	int i;
	if ((type < 0) || (type >= m_nDefined)) { cerr << "SetFeature: Illegal 13\n"; exit(-1); }
	for (i=PT; i<NUM_SFEATS; i++)
		if (!m_aUsed[type][i] && m_aSFeats[i] != 0) { cerr << "SetFeature: Illegal 14:" << type 
			                            << ":" << i << ":" << m_aSFeats[i] << "\n"; exit(-1); }
	#endif
}

void Feature::Clone(Feature &dest)
{
	dest.m_nType = m_nType;
	for (int i=0; i<NUM_SFEATS; i++)
		dest.m_aSFeats[i] = m_aSFeats[i];
	dest.m_fWins   = m_fWins;
	dest.m_fLosses = m_fLosses;
}

// Add feature, returns feature number
int Feature::AddFeature(char *name)
{
	m_sName[m_nDefined] = strdup(name);
	for (int i=0; i<NUM_SFEATS; i++)
		m_aUsed[m_nDefined][i] = false;
	return m_nDefined++;
}

void Feature::SetSubfeature(int type, int sf_index, bool b_used)
{
	#ifndef NDEBUG
	if (type >= m_nDefined)
	{ cerr << "Type ID out of valid range" << endl; exit(-1); }
	#endif

	m_aUsed[type][sf_index] = b_used;
}

// An exact match should yield a PM Penalty of 0, a complete mismatch
// (i.e. opposite end of scale) should yield a PM Penalty of 1
float Feature::PartialMatch(Feature &f)
{
	if (m_nType != f.m_nType)
		return 1.0; //{ cout << "PartialMatch: Cannot compare different types\n"; exit(-1); }

	float penalty = 0.0;    // Add to penalty, normalize by num_features
	int   num_features = 0;
	int   diff;

	for (int i=0; i<NUM_SFEATS; i++)
		if (m_aUsed[m_nType][i])
		{
			num_features++;

			// New code to separate 0 from the rest of the features... will only
			// affect 'opponents ahead', 'opponents near', and 'opponents on bar'.
			// 'point' and 'size' will not be affected because they can never have
			// value 0.  Somehow, a marker or parameter should go into this so 
			// that this scaling property is marked for a feature type.
			if (((m_aSFeats[i] == (int)0) && (f.m_aSFeats[i] != (int)0)) ||
				((m_aSFeats[i] != (int)0) && (f.m_aSFeats[i] == (int)0)))
				penalty = 1.0;
			else
			{
				diff = ABS(m_aSFeats[i]-f.m_aSFeats[i]);
				if (diff > m_aMaxValues[i]) 
					penalty += 1.0;
				else
					penalty += ((float)diff)/((float)m_aMaxValues[i]);
			}
		}

	/* Remove!!! */
	//cout << "PM:\n---" << endl;
	//f.PrintFeature(cout);
	//cout << endl;
	//PrintFeature(cout);
	//cout << endl;
	//cout << "Penalty = " << (((float)penalty)/((float)num_features)) << endl;

	return (((float)penalty)/((float)num_features));
}

void Feature::IncWins(float amount)
{
	m_fWins += amount;
}

void Feature::IncLosses(float amount)
{
	m_fLosses += amount;
}

void Feature::SetTotalWinLoss(int wins, int losses)
{
	m_nTotalWins   = wins;
	m_nTotalLosses = losses;
}

// This should probably be normalized by the number of wins/losses if ever used
float Feature::GetWinProbability()
{
	return (m_fWins/(m_fWins+m_fLosses));
}

float Feature::GetWinOdds()
{
	//cout << "Odds: " << m_fWins << " " << m_fLosses << " " << (m_fWins/m_fLosses) << " | "
	//	 << wins << " " << losses << " " << (float)losses/(float)wins << " | " 
	//	 << (m_fWins/m_fLosses)*((float)losses/(float)wins) << endl;
	return (m_fWins/m_fLosses)*((float)m_nTotalLosses/(float)m_nTotalWins); // Normalize for Bayesian calc
}

void Feature::PrintFeature(ostream &os)
{
	os << m_sName[m_nType] << ": Wins: " << m_fWins << " Losses: " << m_fLosses << " ";
	for (int i=0; i<NUM_SFEATS; i++)
		if (m_aUsed[m_nType][i])
			os << m_sFName[i] << " " << m_aSFeats[i] << " ";
}

void Feature::WriteFeature(ostream &os)
{
	os << "Feature: " << m_sName[m_nType] << " " << m_nType << " " 
	   << (m_fWins)   << " " << (m_fLosses) << " "
	   << "Exp: " << ((float)m_fWins + (float)m_fLosses) << " ";
	for (int i=0; i<NUM_SFEATS; i++)
		if (m_aUsed[m_nType][i])
			os << m_sFName[i] << " " << m_aSFeats[i] << " ";
	os << "Odds: " << (m_fWins/m_fLosses)*((float)m_nTotalLosses/(float)m_nTotalWins);
}

bool Feature::ReadFeature(istream &is)
{
	char text[80];
	is >> text;
	if (strcmp(text, "Feature:") != 0)
		return false;

	is >> text >> m_nType >> m_fWins >> m_fLosses >> text >> text;
	for (int i=0; i<NUM_SFEATS; i++)
		if (m_aUsed[m_nType][i])
			is >> text >> m_aSFeats[i];
	is >> text >> text; // Dump the Odds

	return true;
}


//////////////////////////////////////////////////////////////////////////
// FeatureArray methods
//////////////////////////////////////////////////////////////////////////

FeatureArray::FeatureArray()
{
	m_nFeats = 0;
	m_nSize  = DEF_ARRAY_SZ;
	m_aFeature = new Feature[DEF_ARRAY_SZ];
}

FeatureArray::FeatureArray(int init_size)
{
	m_nFeats = 0;
	m_nSize  = init_size;
	m_aFeature = new Feature[init_size];
}

void FeatureArray::Reset()
{
	m_nFeats = 0;
}

int FeatureArray::GetNumFeats()
{
	return m_nFeats;
}

// Passes a reference to the Feature... note: the
// data is copied into the array so the referenced
// feature should be reused or deallocated by the
// calling procedure
int FeatureArray::AddFeature(Feature *ref)
{
	if (m_nFeats == m_nSize)
		Double();

	ref->Clone(m_aFeature[m_nFeats]);

	return m_nFeats++;
}

Feature* FeatureArray::GetFeatRef(int index)
{
	if (index >= m_nFeats)
		return NULL;

	return &m_aFeature[index];
}

void FeatureArray::PrintFeatArray(ostream &os)
{
	os << "\nFeature Array:\n--------------" << endl;
	for (int i=0; i<m_nFeats; i++)
	{ 
		os << i << ": ";
		m_aFeature[i].PrintFeature(os);
		os << endl; 
	}
}

void FeatureArray::Clone(FeatureArray &dest)
{
	dest.Reset();

	for (int i=0; i<m_nFeats; i++)
		dest.AddFeature(&m_aFeature[i]);
}

// MatchSet must be preallocated, this returns a MatchSet
// of all matching feature indexes/penalties that are
// under the specified threshold
void FeatureArray::GetMatchUnderThreshold(/*[out]*/MatchSet *ms, Feature *f, float threshold)
{
	/* Remove!!! */
	//cout << "\n\nBeginning Match:\n==================" << endl;

	ms->Reset();

	// Go through the feature array, for every match
	// under threshold, insert it into ms
	float penalty;
	for (int i=0; i<m_nFeats; i++)
		if ((penalty = f->PartialMatch(m_aFeature[i])) <= threshold)
			ms->AddItem(i,f->m_aSFeats[PT],penalty);

	ms->Sort();

	/* Remove!!! */
	//cout << "\n\n-----------------" << endl;
	//ms->PrintMatchSet(cout);
	//cout << endl;
	//cout << endl << endl;
}

void FeatureArray::Double()
{
	Feature* temp = new Feature[m_nSize*2];

	// Copy the features over to the new array, amortized
	// cost is constant per element
	for (int n=0; n<m_nSize; n++)
		m_aFeature[n].Clone(temp[n]);

	delete[] m_aFeature;
	m_aFeature = temp;
	m_nSize *= 2;
}

void FeatureArray::WriteFeatureArray(ostream &os)
{
	os << "FeatureArray: " << endl;
	for (int i=0; i<m_nFeats; i++)
	{ 
		m_aFeature[i].WriteFeature(os); 
		os << endl; 
	}
}

bool FeatureArray::ReadFeatureArray(istream &is)
{
	char text[80];
	is >> text;
	if (strcmp(text, "FeatureArray:") != 0)
		return false;

	m_nFeats=-1;
	while(m_aFeature[++m_nFeats].ReadFeature(is)) { if (m_nFeats >= (m_nSize-1)) Double(); }

	return true;
}


//////////////////////////////////////////////////////////////////////////
// FeatureSetArray methods
//////////////////////////////////////////////////////////////////////////

FeatureSetArray::FeatureSetArray()
{
	m_nFeatureSets = 0;
	m_nSize        = DEF_ARRAY_SZ;
	m_aFeatureSet  = new FeatureSet[DEF_ARRAY_SZ];
}

FeatureSetArray::FeatureSetArray(int init_size)
{
	m_nFeatureSets = 0;
	m_nSize        = init_size;
	m_aFeatureSet  = new FeatureSet[init_size];
}

void FeatureSetArray::Reset()
{
	m_nFeatureSets = 0;
}

int FeatureSetArray::GetNumFeatureSets()
{
	return m_nFeatureSets;
}

// Passes a reference to the Feature... note: the
// data is copied into the array so the referenced
// feature should be reused or deallocated by the
// calling procedure
int FeatureSetArray::AddFeatureSet(FeatureSet *ref)
{
	if (m_nFeatureSets == m_nSize)
		Double();

	ref->Clone(m_aFeatureSet[m_nFeatureSets]);

	return m_nFeatureSets++;
}

FeatureSet* FeatureSetArray::GetFeatureSet(int index)
{
	if (index >= m_nFeatureSets)
		return NULL;

	return &m_aFeatureSet[index];
}


void FeatureSetArray::Double()
{
	FeatureSet* temp = new FeatureSet[m_nSize*2];

	// Copy the features over to the new array, amortized
	// cost is constant per element
	for (int n=0; n<m_nSize; n++)
		m_aFeatureSet[n].Clone(temp[n]);

	delete[] m_aFeatureSet;
	m_aFeatureSet = temp;
	m_nSize *= 2;
}

void FeatureSetArray::PrintFeatureSetArray(ostream &os)
{
	os << "\nFeatureSet Array:\n=================" << endl;
	for (int i=0; i<m_nFeatureSets; i++)
	{ 
		os << "FS " << i << ": " << endl;
		m_aFeatureSet[i].PrintFeatArray(os);
		os << endl; 
	}
}

//////////////////////////////////////////////////////////////////////////
// MatchSet methods
//////////////////////////////////////////////////////////////////////////

MatchSet::MatchSet()
{
	m_aMS   = new Match[DEF_ARRAY_SZ];
	m_nSize = DEF_ARRAY_SZ;
	m_nUsed = 0;
	m_nPtr  = 0;
}

MatchSet::MatchSet(int init_size)
{
	m_aMS   = new Match[init_size];
	m_nSize = init_size;
	m_nUsed = 0;
	m_nPtr  = 0;
}

// Clone method... full copy
void MatchSet::Clone(MatchSet &dest)
{
	while(dest.m_nSize < m_nUsed)
		dest.Double();
	dest.m_nUsed = m_nUsed;
	for (int i=0; i<m_nUsed; i++)
		dest.m_aMS[i] = m_aMS[i];
}

void MatchSet::Reset()
{
	m_nUsed = 0;
}

void MatchSet::ResetIterator()
{
	m_nPtr = 0;
}

int MatchSet::GetNumMatches()
{
	return m_nUsed;
}

Match* MatchSet::GetNext()
{
	if (m_nPtr >= m_nUsed)
		return NULL;
	return &m_aMS[m_nPtr++];
}

void MatchSet::AddItem(int index, int pt, float pm_penalty)
{
	if (m_nUsed == m_nSize)
		Double();

	m_aMS[m_nUsed].index        = index; 
	m_aMS[m_nUsed].pt           = pt; 
	m_aMS[m_nUsed++].pm_penalty = pm_penalty;
}

void MatchSet::PrintMatchSet(ostream &os)
{
	os << "{ ";
	for (int ptr = 0; ptr<m_nUsed; ptr++)
		os << "([" << m_aMS[ptr].index << "]," 
		   << m_aMS[ptr].pm_penalty << ") ";
	os << "}";
}

// Sort the matchset
void MatchSet::Sort()
{
	QuickSort(0, m_nUsed-1);
}

// Sort the matchset so that the lowest penalty comes first
void MatchSet::QuickSort(int l, int r)
{
	if (l < r)
	{
		int lhs_partition = Partition(l,r);
		QuickSort(l,lhs_partition);
		QuickSort(lhs_partition+1,r);
	}
}

// Standard partition algorithm for Quicksort
int MatchSet::Partition(int l, int r)
{
	Match pivot = m_aMS[l];
	int i = l-1;
	int j = r+1;

	while (true)
	{
		do { j--; } while (m_aMS[j].pm_penalty > pivot.pm_penalty);
		do { i++; } while (m_aMS[i].pm_penalty < pivot.pm_penalty);
		if (i<j) 
			Exchange(i,j);
		else
			return j;
	}
}

// Exchange for sorting
void MatchSet::Exchange(int i, int j)
{
	Match temp = m_aMS[i];
	m_aMS[i]   = m_aMS[j];
	m_aMS[j]   = temp;
}

void MatchSet::Double()
{
	Match *temp = new Match[m_nSize*2];

	#ifndef NDEBUG
	if (temp == NULL)  { cerr << "'new' failed on alloc of " << m_nSize*2 << endl; exit(-1); }
	if (m_aMS == NULL) { cerr << "NULL MatchSet" << endl; exit(-1); }
	#endif

	for (int i=0; i<m_nSize; i++)
		temp[i] = m_aMS[i]; // Shallow copy

	delete[] m_aMS;
	m_aMS = temp;
	m_nSize *= 2;
}

//////////////////////////////////////////////////////////////////////////
// MatchSetArray methods
//////////////////////////////////////////////////////////////////////////

MatchSetArray::MatchSetArray()
{
	m_nMatchSets = 0;
	m_nSize  = DEF_ARRAY_SZ;
	m_aMatchSet = new MatchSet[DEF_ARRAY_SZ];
}

MatchSetArray::MatchSetArray(int init_size)
{
	m_nMatchSets = 0;
	m_nSize  = init_size;
	m_aMatchSet = new MatchSet[init_size];
}

void MatchSetArray::Reset()
{
	m_nMatchSets = 0;
}

int MatchSetArray::GetNumMatchSets()
{
	return m_nMatchSets;
}

// Passes a reference to the Feature... note: the
// data is copied into the array so the referenced
// feature should be reused or deallocated by the
// calling procedure
int MatchSetArray::AddMatchSet(MatchSet *ref)
{
	if (m_nMatchSets == m_nSize)
		Double();

	// Copy contents of ref into MatchSetArray
	ref->Clone(m_aMatchSet[m_nMatchSets]);

	return m_nMatchSets++;
}

MatchSet* MatchSetArray::GetMatchSetRef(int index)
{
	if (index >= m_nMatchSets)
		return NULL;

	return &m_aMatchSet[index];
}

void MatchSetArray::PrintMatchSetArray(ostream &os)
{
	os << "\nMatchset Array:\n---------------" << endl;
	for (int i=0; i<m_nMatchSets; i++)
	{ 
		os << i << ": ";
		m_aMatchSet[i].PrintMatchSet(os);
		os << endl; 
	}
}

void MatchSetArray::Double()
{
	MatchSet* temp = new MatchSet[m_nSize*2];

	// Copy the features over to the new array, amortized
	// cost is constant per element
	for (int n=0; n<m_nSize; n++)
		temp[n] = m_aMatchSet[n];

	delete[] m_aMatchSet;
	m_aMatchSet = temp;
	m_nSize *= 2;
}

