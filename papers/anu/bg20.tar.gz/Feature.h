////////////////////////////////////////////////////////
// Class:  Feature, FeatureArray, MatchSet, MatchSetArray
// Author: Scott P. Sanner
//
// Description:
//
// This class has ADT's for backgammon board representations.
// It is intended primarily for use by the ACT-R player
// which will generalize over these chunks.
//
// Notes: This code really cries for templates but to insure 
// cross-platform support I have decided not to use templates 
// in this code.  This code also cries for exceptions for
// error checking but I am making two perhaps ill-fated
// assumptions: (1) The only exceptions to normal code execution
// are memory exceptions which are highly unlikely with 2GB
// of address space and (2) Exceptions are not standardized
// across compilers and I am attempting to build compiler
// independent code... -SPS
////////////////////////////////////////////////////////

#ifndef _FEATURE_H_
#define _FEATURE_H_

#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include "Backgammon.h"

// The following constants are used in feature indexing
#define PT            0
#define OP            1
#define SZ            2
#define ON            3
#define OB            4
#define NUM_TYPES    10
#define NUM_SFEATS    5
#define NAME_LEN     40
#define DEF_ARRAY_SZ  8
#define INIT_WINS    (1.0)
#define INIT_LOSSES  (1.0)

// The following values define the subfeature thresholds... any
// difference in two subfeatures greater than this amount will
// be reduced to this amount for calculation of the partial 
// match score
#define MAX_PTS    24 /*24*/
#define MAX_OPP    15
#define MAX_ADJ     6
#define MAX_BAR     2

// Forward declarations
class  Feature;
class  FeatureArray;
struct Match;
class  MatchSet;
class  MatchSetArray;

//////////////////////////////////////////////////////////////////////////
// This is simply a utility class that will be useful for
// abstractions of the board state for the ACT-R Player
//////////////////////////////////////////////////////////////////////////
class Feature
{
	public: // Methods
		Feature();

		void  Clone        (Feature &dest);
		static int   AddFeature   (char *name);
		static void  SetSubfeature(int type, int sf_index, bool b_used);

		static void  SetTotalWinLoss(int wins, int losses);

		void  SetFeature   (int type, int pt);
		void  SetFeature   (int type, int pt, int op);
		void  SetFeature   (int type, int pt, int op, int sz);
		void  SetFeature   (int type, int pt, int op, int sz, int on);
		void  SetFeature   (int type, int pt, int op, int sz, int on, int ob);

		float PartialMatch (Feature &f);
		void  IncWins      (float amount);
		void  IncLosses    (float amount);
		float GetWinProbability();
		float GetWinOdds();

		void  PrintFeature(ostream &os);
		void  WriteFeature(ostream &os);
		bool  ReadFeature (istream &is);

	public: // Data members
		static int   m_nDefined;              // Number of defined types
		static bool  m_aUsed[NUM_TYPES][NUM_SFEATS]; 
											  // Is the PT,OP,SZ field used for partial matching
		static int   m_aMaxValues[NUM_SFEATS];// Max size for PT, OP, SZ... zero assumed as base
		static char *m_sName [NUM_TYPES]; // Store type names for printing
		static char  m_sFName[NUM_TYPES][NAME_LEN];

		static int   m_nTotalWins;   // For odds calc and writing
		static int   m_nTotalLosses; // feature odds to disk

		int m_nType;			   // Type of feature (e.g. EXPOSE, BLOCK, UNBLOCK)
		int m_aSFeats[NUM_SFEATS]; // Feature slot values (e.g. PT, OP, SZ)

		float m_fWins, m_fLosses;  // Win/Loss update value...
};

//////////////////////////////////////////////////////////////////////////
// A doubling array of features
//////////////////////////////////////////////////////////////////////////
class FeatureArray
{
	public:
		FeatureArray();
		FeatureArray(int init_size);

		void Reset();
		int  GetNumFeats();

		// Passes a reference to the Feature... note: the
		// data is copied into the array so the referenced
		// feature should be reused or deallocated by the
		// calling procedure
		int      AddFeature(Feature *ref);
		Feature* GetFeatRef(int index);
		void     Clone(FeatureArray &dest);

		// MatchSet must be preallocated, this returns a MatchSet
		// of all matching feature indexes/penalties that are
		// under the specified threshold
		void GetMatchUnderThreshold(/*[out]*/MatchSet *ms, Feature *f, float threshold);

		void PrintFeatArray   (ostream &os);
		void WriteFeatureArray(ostream &os);
		bool ReadFeatureArray (istream &is);

	private:
		void Double();

		int m_nFeats;
		int m_nSize;
		Feature *m_aFeature;
};

typedef FeatureArray FeatureSet;

//////////////////////////////////////////////////////////////////////////
// Doubling array of FeatureArrays (more appropriately dubbed FeatureSets)
//////////////////////////////////////////////////////////////////////////
class FeatureSetArray
{
	public:
		FeatureSetArray();
		FeatureSetArray(int init_size);

		void Reset();
		int  GetNumFeatureSets();

		// Passes a reference to the FeatureSet... note: the
		// data is copied into the array so the referenced
		// featureset should be reused or deallocated by the
		// calling procedure
		int AddFeatureSet(FeatureSet *ref);
		FeatureSet* GetFeatureSet(int index);
		void PrintFeatureSetArray(ostream &os);

	private:
		void Double();

		int m_nFeatureSets;
		int m_nSize;
		FeatureSet *m_aFeatureSet;
};

//////////////////////////////////////////////////////////////////////////
// Structure used in MatchSet
//////////////////////////////////////////////////////////////////////////
struct Match 
{
	int index; // Index of feature
	int pt;    // Point that this match actually corresponds to
	float pm_penalty; 
};

//////////////////////////////////////////////////////////////////////////
// A doubling array based set for match indexes and penalties
//////////////////////////////////////////////////////////////////////////
class MatchSet
{
	public:
		MatchSet();
		MatchSet(int init_size);

		// Clone method... full copy
		void      Clone(MatchSet &dest);

		// Set size, iteration, and addition
		void   Reset  ();
		void   ResetIterator();
		Match *GetNext();
		void   AddItem(int index, int pt, float pm_penalty);
		int    GetNumMatches();

		// Sort the matchset
		void Sort();

		void PrintMatchSet(ostream &os);

	private:
		// Sort the matchset so that the lowest penalty comes first
		void QuickSort(int l, int r);

		// Standard partition algorithm for Quicksort
		int Partition(int l, int r);

		// Exchange for sorting
		void Exchange(int i, int j);

		// Double the MatchSet size
		void Double();
		
		int m_nPtr;
		int m_nSize;
		int m_nUsed;
		Match *m_aMS;
};

//////////////////////////////////////////////////////////////////////////
// A doubling array of MatchSets
//////////////////////////////////////////////////////////////////////////
class MatchSetArray
{
	public:
		MatchSetArray();
		MatchSetArray(int init_size);

		void Reset();
		int  GetNumMatchSets();

		// Passes a reference to the Feature... note: the
		// data is copied into the array so the referenced
		// feature should be reused or deallocated by the
		// calling procedure
		int       AddMatchSet(MatchSet *ref);
		MatchSet* GetMatchSetRef(int index);
		void      PrintMatchSetArray(ostream &os);

	private:
		void Double();

		int       m_nMatchSets;
		int       m_nSize;
		MatchSet *m_aMatchSet;
};

#endif // _FEATURE_H_