#include "BaseRepPlayer.h"

int BaseRepPlayer::m_nATTACK = (-1); // These will be added to feature
int BaseRepPlayer::m_nBLOCK  = (-1); // and then used as the feature
int BaseRepPlayer::m_nEXPOSE = (-1); // type ID

// Note: To obtain player detailed in paper, remove weighting of near opponents...

// Constructor - build feature set
BaseRepPlayer::BaseRepPlayer()
{
	if (m_nATTACK == (-1))
	{
		// Initialize features and get ID's
		m_nATTACK = (Feature::AddFeature("Attack"));
		m_nBLOCK  = (Feature::AddFeature("Block "));
		m_nEXPOSE = (Feature::AddFeature("Expose"));
	}

	// Set the relevant feature attributes
	Feature::SetSubfeature(m_nATTACK, PT, true);
	Feature::SetSubfeature(m_nATTACK, OB, true); // This is new!!!

	Feature::SetSubfeature(m_nEXPOSE, PT, true);
	Feature::SetSubfeature(m_nEXPOSE, OP, true);
	Feature::SetSubfeature(m_nEXPOSE, ON, true);
	Feature::SetSubfeature(m_nEXPOSE, OB, true);

	Feature::SetSubfeature(m_nBLOCK , PT, true);
	Feature::SetSubfeature(m_nBLOCK , OP, true);
	Feature::SetSubfeature(m_nBLOCK , SZ, true);
	Feature::SetSubfeature(m_nBLOCK , ON, true);
	Feature::SetSubfeature(m_nBLOCK , OB, true);

	// Set the default stochastic move selection value
	SetConflictResTemp(0.2);
	SetMinBlotPenalty (0.0);
	SetMaxBlotPenalty (0.5);

	// Set initial wins/losses - avoid divide by zero
	m_nTotalWins   = 1;  
	m_nTotalLosses = 1; 

	#ifdef BASEREP_PRINT_FEATURES
	m_outfile.open("baserep.txt", ios::out|ios::trunc);
	m_disp = new TextDisplay(m_outfile);
	#endif 

}

// Destructor
BaseRepPlayer::~BaseRepPlayer()
{

}

// Reset player
void BaseRepPlayer::Reset()
{
	m_nGameMoves = 0;
}

// Indicates win/loss
void BaseRepPlayer::Update(bool win, int blot_pt)
{
	if (blot_pt == (-1))
	{
		if (win)
			m_nTotalWins++;
		else
			m_nTotalLosses++;
	}
}

// Derive features for all of the potential moves
void BaseRepPlayer::DeriveFeatures(Backgammon *p, int mv)
{
	// mv indicates the move that was made, p contains the game board,
	// store value of mv in m_nMoveValue, mv is zero-indexed
	#ifndef NDEBUG
	if (m_nMoves != mv) { cerr << "DeriveFeatures: Move mismatch\n"; exit(-1); }
	#endif

	m_aMoveFeatureSet[mv].Reset();

	if (m_bRace) // Race condition
	{
		// Store the number of players bore off in race condition
		m_aBoreOff[mv] = p->m_aPoint[p->AbsolutePos(me, BORE_OFF)].m_nMen[me];

		// Store the sum of all moves required to remove the rest of the players
		m_aMinRemainingMoves[mv] = 0;
		for (int rel_pt = 19; rel_pt <= 24; rel_pt++)
			m_aMinRemainingMoves[mv] += 
				(25-rel_pt)*p->m_aPoint[p->AbsolutePos(me, rel_pt)].m_nMen[me];
	}
	else
	{
		// Derive move features... all feature points should be relative
		bgplayer op = p->GetOtherPlayer(me);
		int rel_pt, tr_pt, size, opp, opp_bar;
		bool point_blocked, point_exposed, point_attacked;

		// Count number of opponents ahead of each point, start at opponent's
		// BAR (i.e. rel 0) and then from 24 and accumulate back to point 1
		opp_bar = opp = p->m_aPoint[p->AbsolutePos(op, BAR)].m_nMen[op]; // BAR is defined rel to op
		for(rel_pt = 24; rel_pt >= 1; rel_pt--)
		{
			opp += p->m_aPoint[p->AbsolutePos(me, rel_pt)].m_nMen[op];
			m_nOpponentsAhead[rel_pt] = opp;
			tr_pt = rel_pt + 7;
			if (tr_pt > 25) 
				m_nOpponentsAheadNear[rel_pt] = m_nOpponentsAhead[rel_pt];
			else if (tr_pt == 25)
				m_nOpponentsAheadNear[rel_pt] = m_nOpponentsAhead[rel_pt] - opp_bar;
			else
				m_nOpponentsAheadNear[rel_pt] = opp - m_nOpponentsAhead[tr_pt];

			// Just a check...
			if ((m_nOpponentsAheadNear[rel_pt] < 0) || (m_nOpponentsAheadNear[rel_pt] > 15))
				cerr << "Opponents near out of bounds - " << m_nOpponentsAhead[tr_pt] << ":"
				     << opp << endl;
		}
			
		for(rel_pt = 1, size = 0; rel_pt <= 24; rel_pt++)
		{
			// Derive number of attacks, pt
			point_attacked = (m_aInitialOpp[rel_pt]) && 
							 (p->m_aPoint[p->AbsolutePos(me, rel_pt)].m_nMen[me] > 0);
			if (point_attacked)
			{
				m_fTemp.SetFeature(m_nATTACK, rel_pt,0,0,0,opp_bar-1 /*before*/); // This is new!
				m_aMoveFeatureSet[mv].AddFeature(&m_fTemp);
			}

			// Derive number of player exposes, pt, op
			point_exposed = (p->m_aPoint[p->AbsolutePos(me, rel_pt)].m_nMen[me] == 1);
			if (point_exposed)
			{
				m_fTemp.SetFeature(m_nEXPOSE, rel_pt, m_nOpponentsAhead[rel_pt], 0,
					                    /*NEAR->*/m_nOpponentsAheadNear[rel_pt], opp_bar);
				m_aMoveFeatureSet[mv].AddFeature(&m_fTemp);
			}

			// Derive number of player blocks, pt, op, sz; 
			// Idea: Detect consecutive sets of blocked points
			//   if ((size > 0 )  AND (not blocked)) OR
			//      ((size == 24) AND (blocked))        { AddFeature(), size = 0 }
			//   elseif (blocked)                       { size++ }
			//
			// *Note: Blocked points should use their end for identification...
			//        this is essentially the threshold which the opponent must
			//        face
			point_blocked = (p->m_aPoint[p->AbsolutePos(me, rel_pt)].m_nMen[me] > 1);
			if ((size > 0) && (!point_blocked))
			{
				// This point is unblocked so last blocked point was rel_pt-1
				m_fTemp.SetFeature(m_nBLOCK, rel_pt-1, m_nOpponentsAhead[rel_pt-1], size,
					               /*NEAR->*/m_nOpponentsAheadNear[rel_pt-1], opp_bar);
				m_aMoveFeatureSet[mv].AddFeature(&m_fTemp);
				size = 0; // Reset the size since this point breaks up any consecutive block
			}
			if ((rel_pt == 24) && (point_blocked)) // Don't get to inc, so use size+1
			{
				// This point is blocked and is the last possible blocked point
				m_fTemp.SetFeature(m_nBLOCK, rel_pt, m_nOpponentsAhead[rel_pt], size+1,
					               /*NEAR->*/m_nOpponentsAheadNear[rel_pt], opp_bar);
				m_aMoveFeatureSet[mv].AddFeature(&m_fTemp);
				// size does not matter :), this is the last point
			}
			else if (point_blocked)
				size++;
		}
	}

	m_nMoves++; // One more possible move for this turn

	// All features have now been derived for this move
	#ifdef BASEREP_PRINT_FEATURES
	m_outfile << "Data for move #" << mv << "\n-----------------" << endl;
	m_disp->DisplayGameInfo(p);
	m_aMoveFeatureSet[mv].PrintFeatArray(m_outfile);
	if (m_bRace) m_outfile << "Move value: " << CalcRaceCondHeuristic(mv) << endl;
	m_outfile << endl << endl;
	#endif
}  

bool BaseRepPlayer::PlayTurn(Backgammon* p)
{
	bool  any_moves = (p->m_nValidMoves > 0);
	int   m, chosen_move, max;
	float rval, total, max_val;

	if (any_moves)
	{	
		// Determine if player is bearing pieces
		bgplayer bearing = p->WhoIsBearing();
		m_bRace = ((bearing == BOTH) || (bearing == me));

		#ifdef BASEREP_PRINT_FEATURES
		m_outfile << "\n\nBase State:\n------------" << endl;
		m_disp->DisplayGameInfo(p);
		m_outfile << "\nMoves and Features:\n-------------------" << endl;
		if (m_bRace) m_outfile << "\n>>> Bearing pieces...\n\n" << endl;
		#endif

		// Derive initial board features to use later for attack feature,
		// i is a relative index
		bgplayer op = p->GetOtherPlayer(me);
		for (int i=0; i<POINT_ELE; i++)
			m_aInitialOpp[i] = (p->m_aPoint[p->AbsolutePos(me, i)].m_nMen[op] > 0);

		// Set move value array for each possible move
		m_nMoves = 0; // Reset move counter
		p->DeriveFeatures(me, this);

		// Derive the value of each move given the feature set
		SetMoveUtilities();

		// Normalize all of the move utilities to [0,1] based on max value,
		// and weight exponentially
		max = 0;
		for (m = 1; m < m_nMoves; m++)
		{
			//cout << "Move " << m << ": " << m_aMoveValue[m] << endl;
			if (m_aMoveValue[max] < m_aMoveValue[m])
				max = m;
		}
		max_val = m_aMoveValue[max];
		//cout << "\nMax value found: " << max_val << endl << endl;
		for (m = 0; m < m_nMoves; m++)
		{
			/* Old: m_aMoveValue[m] = exp(m_aMoveValue[m]/(max_val*CONFLICT_RES_TEMP)); */
			m_aMoveValue[m] = pow(m_aMoveValue[m]/(max_val), CONFLICT_RES_TEMP);
			//cout << "Exp Normalized weight for move #" << m << ": " << m_aMoveValue[m] << endl;
		}

		// Renormalize all moves to sum to one
		total = 0;
		for (m = 0; m < m_nMoves; m++)
			total += m_aMoveValue[m];
		//cout << "\nTotal exponential weight: " << total << endl;
		for (m = 0; m < m_nMoves; m++)
		{
			m_aMoveValue[m] /= total;
			//cout << "Exponential weight proportion for move #" << m << ": " << m_aMoveValue[m] << endl;
		}

		// Stochastically select the move which generated the highest value 
		// and place result in chosen_move
		rval = m_rv.UniformRV();

		//cout << "\nRV: " << rval << endl << endl;

		#ifndef NDEBUG
		if ((rval < 0) || (rval > 1)) { cerr << "Bad rval: " << rval << endl; exit(-1); }
		#endif
		
		for (m=0; m < m_nMoves; m++)
			if (rval < m_aMoveValue[m]) {
				chosen_move = m;
				break;
			} else
				rval -= m_aMoveValue[m];

		//cout << "\n***Chose Move #" << chosen_move << "***\n---------------" << endl;

		#ifdef BASEREP_PRINT_FEATURES
		m_outfile << "\n***Chose Move #" << chosen_move << "***\n---------------" << endl;
		#endif

		// Select that move if any move is possible
		SelectMove(chosen_move);
		p->MakeMove(me, chosen_move);
		m_nGameMoves++;
	}

	return true;
}

int BaseRepPlayer::CalcRaceCondHeuristic(int mv)
{
	#ifndef NDEBUG
	if (!m_bRace) { cerr << "Cannot calc heuristic in non-race mode" << endl; exit(-1); }
	#endif

	return ((100*m_aBoreOff[mv]) + m_aMinRemainingMoves[mv]);
}
