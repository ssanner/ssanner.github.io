#include "ACTRPlayer.h"

// Constructor - read in file parameters
ACTRPlayer::ACTRPlayer(int filenum)
{
	ifstream is;
	float conflict_res_temp;
	float threshold;
	float lambda;
	float min_penalty;
	float max_penalty;
	char  text[80];
	char  filename[80] = "actr-config-v";

	m_nFilenum = filenum;

	strcat(filename, ((m_nFilenum==1)?"1":"2"));
	strcat(filename, ".txt");

	is.open(filename, ios::in|ios::nocreate);
	cout << "ACT-R Player v." << filenum << ": Reading Configuration File" << endl;

	is >> text;
	if (strcmp(text,"CONFLICT_RES_TEMP") != 0)
	{ cerr << "CONFLICT_RES_TEMP unspecified" << endl; exit(-1); }
	is >> conflict_res_temp;
	SetConflictResTemp(conflict_res_temp);
	cout << "CONFLICT_RES_TEMP: " << GetConflictResTemp() << endl;

	is >> text;
	if (strcmp(text,"PM_THRESHOLD") != 0)
	{ cerr << "PM_THRESHOLD unspecified" << endl; exit(-1); }
	is >> threshold;
	SetPMThreshold(threshold);
	cout << "PM_THRESHOLD:      " << GetPMThreshold() << endl;

	is >> text;
	if (strcmp(text,"LAMBDA") != 0)
	{ cerr << "LAMBDA unspecified" << endl; exit(-1); }
	is >> lambda;
	SetLambda(lambda);
	cout << "LAMBDA:            " << GetLambda() << endl;

	is >> text;
	if (strcmp(text,"MIN_BLOT_PENALTY") != 0)
	{ cerr << "MIN_BLOT_PENALTY unspecified" << endl; exit(-1); }
	is >> min_penalty;
	SetMinBlotPenalty(min_penalty);
	cout << "MIN_BLOT_PENALTY:  " << GetMinBlotPenalty() << endl;

	is >> text;
	if (strcmp(text,"MAX_BLOT_PENALTY") != 0)
	{ cerr << "MAX_BLOT_PENALTY unspecified" << endl; exit(-1); }
	is >> max_penalty;
	SetMaxBlotPenalty(max_penalty);
	cout << "MAX_BLOT_PENALTY:  " << GetMaxBlotPenalty() << endl;

	is >> text;
	if (strcmp(text,"MULTIPLE_NEIGHBOR") != 0)
	{ cerr << "MULTIPLE_NEIGHBOR unspecified" << endl; exit(-1); }
	is >> text;
	m_bNearestNeighborOn = (strcmp(text,"ON") == 0);
	cout << "MULTIPLE_NEIGHBOR: " << ((m_bNearestNeighborOn)?"ON ":"OFF") << endl;

	is >> text;
	if (strcmp(text,"TOTAL_WINS") != 0)
	{ cerr << "TOTAL_WINS unspecified" << endl; exit(-1); }
	is >> m_nTotalWins;
	cout << "TOTAL_WINS:        " << m_nTotalWins << endl;

	is >> text;
	if (strcmp(text,"TOTAL_LOSSES") != 0)
	{ cerr << "TOTAL_LOSSES unspecified" << endl; exit(-1); }
	is >> m_nTotalLosses;
	cout << "TOTAL_LOSSES:      " << m_nTotalLosses << endl;

	is >> text;
	if (strcmp(text,"LEARNING") != 0)
	{ cerr << "LEARNING unspecified" << endl; exit(-1); }
	is >> text;
	m_bLearningOn = (strcmp(text,"ON") == 0);
	cout << "LEARNING:          " << ((m_bLearningOn)?"ON ":"OFF") << endl;

	m_faPrevMoves.ReadFeatureArray(is);
	cout << "READ " << m_faPrevMoves.GetNumFeats() << " FEATURES" << endl << endl;

	is.close();

	#ifdef ACTR_PRINT_DEBUG
	m_aoutfile.open("actr-debug.txt", ios::out|ios::trunc);
	m_adisp = new TextDisplay(m_aoutfile);
	#endif
}

// Destructor
ACTRPlayer::~ACTRPlayer()
{
	ofstream os;
	char  filename[80] = "actr-output-v";

	if (m_bLearningOn)
	{
		strcat(filename, ((m_nFilenum==1)?"1":"2"));
		strcat(filename, ".txt");

		os.open(filename, ios::out|ios::trunc);
		
		os << "CONFLICT_RES_TEMP " << GetConflictResTemp() << endl;
		os << "PM_THRESHOLD      " << GetPMThreshold() << endl;
		os << "LAMBDA            " << GetLambda() << endl;
		os << "MIN_BLOT_PENALTY  " << GetMinBlotPenalty() << endl;
		os << "MAX_BLOT_PENALTY  " << GetMaxBlotPenalty() << endl;
		os << "MULTIPLE_NEIGHBOR " << ((m_bNearestNeighborOn)?"ON ":"OFF") << endl;
		os << "TOTAL_WINS        " << m_nTotalWins << endl;
		os << "TOTAL_LOSSES      " << m_nTotalLosses << endl;
		os << "LEARNING          " << ((m_bLearningOn)?"ON ":"OFF") << endl << endl;

		Feature::SetTotalWinLoss(m_nTotalWins, m_nTotalLosses);
		m_faPrevMoves.WriteFeatureArray(os);

		os.close();
	}
}

// Reset player
void ACTRPlayer::Reset()
{
	BaseRepPlayer::Reset();
	m_msaMoves.Reset();
}

// Update the player at the end of the game, blot_pt is relative
void ACTRPlayer::Update(bool win, int blot_pt)
{
	// If a win, propagate a success, if loss propagate failure
	Feature  *feature;
	MatchSet *ms_moves;
	Match    *match;
	float     discount = LAMBDA;
	float     cur_disc = 1.0;
	bool      blot = (blot_pt != (-1));

	if (m_bLearningOn)
		BaseRepPlayer::Update(win, blot_pt); // Call parent method

	if (blot && m_bLearningOn)
	{
		// A win/loss will have a factor of 1.0, but we only
		// want to make a blot a fraction of this since it
		// is not as important as a win/loss
		float factor = EXPOSE_BLOT_MIN_PENALTY + 
			         ((EXPOSE_BLOT_MAX_PENALTY - EXPOSE_BLOT_MIN_PENALTY)*
					  (((float)blot_pt)/((float)POINTS)));
		bool found = false;

		// For each move, get the features involved in the match
		for (int move = m_msaMoves.GetNumMatchSets()-1; (move >= 0) /*&& !found*/; move--)
		{
			ms_moves = m_msaMoves.GetMatchSetRef(move);
			ms_moves->ResetIterator();

			// Retrieve each match and check to see if it is the 'guilty' expose
			while ((match = ms_moves->GetNext()) /*&& !found*/)
			{
				feature = m_faPrevMoves.GetFeatRef(match->index);

				//cout << "Checking " << feature->m_nType << " == " << m_nEXPOSE<< ", " << match->pt << " == " << blot_pt<< endl;

				// If this is a blot update... only EXPOSE that caused blot should be affected
				found = ((feature->m_nType == m_nEXPOSE) && (match->pt == blot_pt));
				if (found)
					feature->IncLosses(cur_disc*(1.0 - match->pm_penalty)*factor);
				//if (found) 
				//	cout << "Discounting pt " << match->pt << " by " 
				//	     << cur_disc*(1.0 - match->pm_penalty)*factor << endl;
				//if (found) exit(-1);
			}
			cur_disc *= discount; // Discount for every move back...
		}

	}
	else if (m_bLearningOn)
	{
		// For each move, get the features involved in the match
		for (int move = m_msaMoves.GetNumMatchSets()-1; move >= 0; move--)
		{
			ms_moves = m_msaMoves.GetMatchSetRef(move);
			ms_moves->ResetIterator();

			// Retrieve each feature for the move and update it
			while ((match = ms_moves->GetNext()))
			{
				feature = m_faPrevMoves.GetFeatRef(match->index);

				// Full credit if match penalty is zero
				if (win)
					feature->IncWins(cur_disc*(1.0 - match->pm_penalty));
				else // Loss
					feature->IncLosses(cur_disc*(1.0 - match->pm_penalty));
				
				//cout << "Win/Loss update:" << move << endl;
			}

			cur_disc *= discount; // Discount for every move back...
		}
	}

	// If debug turned on, print matchset of moves and player cached moves
	#ifdef ACTR_PRINT_DEBUG
	m_aoutfile << "\nCached Features:\n-----------------" << endl;
	m_faPrevMoves.PrintFeatArray(m_aoutfile);
	m_aoutfile << "\nMatchset for each move\n----------------------" << endl;
	m_msaMoves.PrintMatchSetArray(m_aoutfile);
	m_aoutfile << "========================================================" << endl;
	#endif
}

// Sets m_aMoveValue[] array for each move
void ACTRPlayer::SetMoveUtilities() 
{
	// We have all of the move features for each move, we need to 
	// partial match each feature of each move to the move set and 
	// derive a score for the move
	Match    *match;
	MatchSet *match_set;
	Feature  *move_feature;
	int m, f, num_features;
	float accum;

	if (m_bRace) // Race condition, make optimal move
	{
		int best_move = 0;
		int highest = CalcRaceCondHeuristic(0);

		// Find the move that moves the most pieces off of the board
		// at the highest possible points (minimizing remaining moves)
		for (m=1; m<m_nMoves; m++)
		{
			if (highest < CalcRaceCondHeuristic(m))
			{ 
				best_move = m;
				highest = CalcRaceCondHeuristic(m);
			}
		}
		
		// Set the best move value
		for (m=0; m<m_nMoves; m++)
		{
			m_aMoveValue[m] = ((m==best_move) ? 100.0 : 0.001);
		}
	}
	else // Normal play 
	{
		for (m=0; m<m_nMoves; m++)
		{
			/* Remove!!! */
			//cout << "\nMove: " << m << "\n========" << endl;

			//accum = 0.0; // For prob
			accum = 1.0; // For odds
			num_features = m_aMoveFeatureSet[m].GetNumFeats();
			m_msaTurn[m].Reset();
			for (f=0; f<num_features; f++)
			{
				// Get a match set for this feature
				move_feature = m_aMoveFeatureSet[m].GetFeatRef(f);
				m_faPrevMoves.GetMatchUnderThreshold(&m_msTemp, move_feature, PM_THRESHOLD);
				m_msaTurn[m].AddMatchSet(&m_msTemp);
				match_set    = m_msaTurn[m].GetMatchSetRef(f);
				if (match_set->GetNumMatches() == 0)
				{
					// Compile a new feature and add it to the MatchSet
					m_faPrevMoves.AddFeature(move_feature);
					match_set->AddItem(m_faPrevMoves.GetNumFeats()-1, 
						               move_feature->m_aSFeats[PT], 1.0); // Perfect match
				}

				///////////////////////////////////////////////////////////////////////////
				/* Old - 1 Match
				// For right now, only allowing one match, so retrieve the best
				// match (the array is sorted in ascending order), and accumulate
				// the match penalty
				match_set->ResetIterator();
				match = match_set->GetNext();

				// We will use the average of the win probability, so add for now, avg later
				//accum += m_faPrevMoves.GetFeatRef(match->index)->GetWinProbability(); // Prob
				Feature::SetTotalWinLoss(m_nTotalWins, m_nTotalLosses);
				accum *= m_faPrevMoves.GetFeatRef(match->index)->GetWinOdds(); // Odds
				*/
				///////////////////////////////////////////////////////////////////////////
				/* > 1 Match */
				// For right now, only allowing one match, so retrieve the best
				// match (the array is sorted in ascending order), and accumulate
				// the match penalty
				float move_value = 0.0;
				float pm_total   = 0.0;
				int   num_matches = 0;
				match_set->ResetIterator();
				Feature::SetTotalWinLoss(m_nTotalWins, m_nTotalLosses);
				while ((match = match_set->GetNext()) && (m_bNearestNeighborOn || num_matches < 1))
				{
					pm_total += 1.0 - match->pm_penalty;
					move_value += (m_faPrevMoves.GetFeatRef(match->index)->GetWinOdds())*(1.0 - match->pm_penalty);
					num_matches++;
				}
				move_value /= pm_total;

				// We will use the average of the win probability, so add for now, avg later
				//accum += m_faPrevMoves.GetFeatRef(match->index)->GetWinProbability(); // Prob
				accum *= move_value;//
				///////////////////////////////////////////////////////////////////////////


				//cout << "Best match:  Index-" << match->index << "  Pen-" << match->pm_penalty
				//	   << "  Win Prob-" << m_faPrevMoves.GetFeatRef(match->index)->GetWinProbability() << endl;

				#ifndef NDEBUG
				if (match_set->GetNumMatches() == 0) { cerr << "Empty MatchSet\n"; exit(-1); }
				#endif		
			}

			// Find the average penalty score for this move (lower is better)
			//accum /= ((float)num_features); // Prob
			;;; // Odds - no normalization needed
			
			// Since the BaseRep move evaluation uses higher values to indicate better
			// moves, win prob can be directly assigned to move value
			m_aMoveValue[m] = accum;
			//cout << "\nAccum: " << accum << "  Move Value: " << m_aMoveValue[m] << endl;
		}
	}
}

// Indicates which move was selected, used for tracking moves
void ACTRPlayer::SelectMove(int mv)
{
	// Copy the selected move's MatchSet to the class's move array
	#ifndef NDEBUG
	if ((mv < 0) || (mv >= m_nMoves)) { cerr << "Illegal move\n"; exit(-1); }
	#endif

	m_msTemp.Reset();
	m_msaMoves.AddMatchSet(&m_msTemp);

	Match         *match;
	MatchSet      *feature_ms;
	MatchSet      *ms_dest = m_msaMoves.GetMatchSetRef(m_nGameMoves);
	MatchSetArray *msa_src = &m_msaTurn[mv];

	///////////////////////////////////////////////////////////////////////////
	/* One Match
	// For each MatchSet in the MatchSetArray, extract the first MatchSet
	// and add it to the move MatchSet
	int match_sets = msa_src->GetNumMatchSets();
	ms_dest->Reset();
	for (int ms=0; ms<match_sets; ms++)
	{
		feature_ms = msa_src->GetMatchSetRef(ms);
		feature_ms->ResetIterator();
		match = feature_ms->GetNext();
		ms_dest->AddItem(match->index, match->pt, match->pm_penalty);
	}
	*/
	///////////////////////////////////////////////////////////////////////////
	/* > 1 Match */
	// For each MatchSet in the MatchSetArray, extract the first MatchSet
	// and add it to the move MatchSet
	int match_sets = msa_src->GetNumMatchSets();
	ms_dest->Reset();
	for (int ms=0; ms<match_sets; ms++)
	{
		feature_ms = msa_src->GetMatchSetRef(ms);
		feature_ms->ResetIterator();
		int num_matches = 0;

		while ((match = feature_ms->GetNext()) && (m_bNearestNeighborOn || num_matches < 1))
		{
			ms_dest->AddItem(match->index, match->pt, match->pm_penalty);
			num_matches++;
		}
	}//
	///////////////////////////////////////////////////////////////////////////
}

