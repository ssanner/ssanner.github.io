#include <stdlib.h>
#include <assert.h>
#include <iostream.h>
#include <fstream.h>
#include "Backgammon.h"
#include "BackgammonDisplay.h"
#include "Player.h"

/////////////////////////////////////////////////////////////////////
// SMoveChunk Methods
/////////////////////////////////////////////////////////////////////

// This is kind of obscure code but it essentially takes an arbitrary
// move chunk and attempts to match it to a legal move... if it finds
// a legal move, it returns true otherwise false
bool SMoveChunk::Match(SMoveChunk &e)
{
	int m, m2;

	if (e.m_nMoveElems != m_nMoveElems)
		return false;

	bool match[MAX_MOVES_TURN], m2match[MAX_MOVES_TURN], full_match;
	
	for (m2=0; m2<m_nMoveElems; m2++)
		m2match[m2] = false;

	for (m=0; m<m_nMoveElems; m++)
	{
		match[m] = false;
		for (m2=0; m2<m_nMoveElems; m2++)
		{
			if (m2match[m2]) continue; // Don't match a move twice
			match[m] = m2match[m2] =
				       ((m_elem[m].m_nDest == e.m_elem[m2].m_nDest) &&
						(m_elem[m].m_nSrc  == e.m_elem[m2].m_nSrc));
			if (match[m]) break;
		}
	}

	full_match = true;
	for (m=0; (m<m_nMoveElems && full_match); m++)
		full_match &= match[m];

	return full_match;
}

/////////////////////////////////////////////////////////////////////
// Backgammon Methods and Static Var Definitions
/////////////////////////////////////////////////////////////////////

char Backgammon::m_sPlayerName[2][9] = {"White(O)","Black(X)"};

// Constructor
Backgammon::Backgammon(Player *white, Player *black, BackgammonDisplay* disp)
{
	m_aPlayer[BLACK] = black; m_aPlayer[BLACK]->SetPlayer(BLACK);
	m_aPlayer[WHITE] = white; m_aPlayer[WHITE]->SetPlayer(WHITE);
	m_display = disp;

	// Trace stuff... disable using -DNDEBUG during compilation
	trace_file.open("trace.txt", ios::out|ios::trunc);
	m_tm = new Trace(trace_file,TRACE_PRIORITY);
	m_tdisplay = new TextDisplay(trace_file);
}

// Destructor
Backgammon::~Backgammon()
{
	delete m_tm;
	delete m_tdisplay;
	trace_file.close();
}

// Reset the game board and each player
void Backgammon::ResetGame()
{
	// Initialize points to empty
	for (int i=0; i<POINT_ELE; i++)	
		m_aPoint[i].m_nMen[BLACK] = m_aPoint[i].m_nMen[WHITE] = 0;

	// Setup initial board config
	m_aPoint[AbsolutePos(BLACK,01)].m_nMen[BLACK] = 2;
	m_aPoint[AbsolutePos(WHITE,01)].m_nMen[WHITE] = 2;
	m_aPoint[AbsolutePos(BLACK,12)].m_nMen[BLACK] = 5;
	m_aPoint[AbsolutePos(WHITE,12)].m_nMen[WHITE] = 5;
	m_aPoint[AbsolutePos(BLACK,17)].m_nMen[BLACK] = 3;
	m_aPoint[AbsolutePos(WHITE,17)].m_nMen[WHITE] = 3;
	m_aPoint[AbsolutePos(BLACK,19)].m_nMen[BLACK] = 5;
	m_aPoint[AbsolutePos(WHITE,19)].m_nMen[WHITE] = 5;

	m_aPoint[AbsolutePos(BLACK,BAR)].m_nMen[BLACK] = 0;
	m_aPoint[AbsolutePos(WHITE,BAR)].m_nMen[WHITE] = 0;
	m_aPoint[AbsolutePos(BLACK,BORE_OFF)].m_nMen[BLACK] = 0;
	m_aPoint[AbsolutePos(WHITE,BORE_OFF)].m_nMen[WHITE] = 0;

	m_nHomeBoard[WHITE] = m_nHomeBoard[BLACK] = 5;
	m_nTurnsPlayed = 1; // Perhaps this is somewhat of a misnomer

	// Just temporary values
	m_aDice[0] = m_aDice[1] = INVALID_ROLL;
	m_bDoubles = m_bMoveMade = false;
	m_nTurn = BLACK;  
	
	// Reset each of the players
	m_aPlayer[WHITE]->Reset();
	m_aPlayer[BLACK]->Reset();
}

// Play backgammon alternating between each player after the initial
// roll determines who goes first
bgplayer Backgammon::StartGame()
{
	bgplayer winner;

	// Reset the game board
	ResetGame();

	// See who goes first
	do { RollDice(); } while (IsDoubles());
	m_nTurn = ((m_aDice[BLACK] > m_aDice[WHITE]) ? BLACK : WHITE);
	
	m_display->DisplayStartInfo(this);

	// Now play the game
	while ((winner = WhoHasWon()) == NEITHER)
	{
		//m_tdisplay->DisplayGameInfo(this); // Trace file

		// Generate all possible moves for this turn
		GenerateMoves(m_nTurn);

		// Trace display
		m_display->DisplayGameInfo(this);            // Normal display
		//m_tdisplay->DisplayGameInfo(this);         // Trace file
		//m_tdisplay->DisplayMoveSet(this, m_nTurn); // Trace file

		// Play the run
		m_bMoveMade = false;
		if ((m_nTurn != WHITE) && (m_nTurn != BLACK))
		{ 
			cerr << "Invalid turn: " << m_nTurn; 
			exit(-1); 
		}

		if (!m_aPlayer[m_nTurn]->PlayTurn(this))
		{
			m_display->DisplayError(this, 0);
			cerr << "Wrong turn: " << m_nTurn << endl;
			exit(-1);
		}

		m_nTurn = GetOtherPlayer(m_nTurn);
		m_nTurnsPlayed++;

		RollDice();
	}

	// Display final game status
	m_display->DisplayWinInfo(this);

	// Update both of the players on the results, first argument indicates
	// whether the game was won or lost, the second argument is used
	// elsewhere to notify the player of a blot (i.e. man removed to the bar)
	m_aPlayer[BLACK]->Update(winner == BLACK, (-1)); // No blot (-1)
	m_aPlayer[WHITE]->Update(winner == WHITE, (-1)); // No blot (-1)

	return winner;
}

// Given a matched (legal) move, execute it - only call this method when
// making an irreversible move in the game (not just simply deriving
// features)... it updates the player based on any possible blots
void Backgammon::MakeMove(bgplayer p, int move_num)
{
	bool opp_blot;
	bgplayer op = GetOtherPlayer(p);
	int blot_pt;

	if ((move_num < 0) || (move_num >= m_nValidMoves) || m_bMoveMade)
	{
		m_display->DisplayError(this, 2);
		cerr << "Invalid move: Out of range 0 <= " << move_num 
			 << " < " << m_nValidMoves << endl;
		exit(-1);
	}

	m_bMoveMade = true;

	for (int n=0; n < m_aMoves[move_num].m_nMoveElems; n++)
	{
		opp_blot = MakeMove(p, m_aMoves[move_num].m_elem[n].m_nSrc,
		                       m_aMoves[move_num].m_elem[n].m_nDest, true);

		// opp_blot indicates that an opponent was moved from the
		// absolute destination to the bar --> update the player
		if (opp_blot)
		{
			blot_pt = RelativePos(op, m_aMoves[move_num].m_elem[n].m_nDest);
			m_aPlayer[op]->Update(false, blot_pt);
		}
	}

	m_display->DisplayTurn(this, p, move_num);
}

// Make a move checking for errors and also detecting whether an opponent is bumped
// so that this can be undone if this is just a test move... Returns true if opp 
// moved to BAR (place indicates whether to actually place the moved player - an
// artifact and thus should always be true)
bool Backgammon::MakeMove(bgplayer p, point abs_source, point abs_dest, bool place)
{
	int rel_dest = RelativePos(p, abs_dest);
	int rel_src  = RelativePos(p, abs_source);
	bgplayer  op = GetOtherPlayer(p);
	bool opp_bumped = false;

	// Error checking
    if (rel_dest >  BORE_OFF) 
	  {rel_dest   = BORE_OFF; m_display->DisplayError(this, 3);}
	if (rel_src  >= BORE_OFF) 
	  {rel_src    = BORE_OFF; m_display->DisplayError(this, 4);}
	if (rel_dest <= BAR) 
	  {rel_dest   = BAR; m_display->DisplayError(this, 5);}
	if (rel_src  <  BAR) 
	  {rel_src    = BAR; m_display->DisplayError(this, 6);}

	// More error checking
	if (m_aPoint[AbsolutePos(p,BAR)].m_nMen[p] < 0)
	  {abs_source = BAR; m_display->DisplayError(this, 7);}
	if (m_aPoint[AbsolutePos(op,BAR)].m_nMen[op] < 0)
	  {abs_source = BAR; m_display->DisplayError(this, 8);}

	// Move the pieces
	m_aPoint[abs_source].m_nMen[p]--;

	if (place)
	{
		if (rel_dest >= BORE_OFF)
			m_aPoint[AbsolutePos(p,BORE_OFF)].m_nMen[p]++;
		else
		{
			m_aPoint[abs_dest].m_nMen[p]++;
			// If 1 man on this point, place on bar
			if (opp_bumped = ((m_aPoint[abs_dest].m_nMen[op] == 1) && (rel_dest != BORE_OFF)))
			{
				m_aPoint[abs_dest].m_nMen[op] = 0;
				m_aPoint[AbsolutePos(op,BAR)].m_nMen[op]++;
				
				// If opponent is bumped off of rel positions 19-24, must
				// decrement home board count...
				int op_rel_dest = RelativePos(op,abs_dest);
				if ((op_rel_dest <= 24) && (op_rel_dest >= 19))
					m_nHomeBoard[op]--;
			}
		}
	}

	// And even more error checking
	int pt, men = 0;
	for (pt = BAR; pt <= BORE_OFF; pt++)
		men += m_aPoint[pt].m_nMen[p];
	if (men != 15)
		m_display->DisplayError(this, 100+men);

	if ((rel_dest <= 24) && (rel_dest >= 19) && (rel_src < 19))
		m_nHomeBoard[p]++;

	return opp_bumped;
}

// Undo a move using bumped data
bool Backgammon::UndoMove(bgplayer p, point abs_source, point abs_dest, bool opp_bumped, bool place)
{
	if (abs_dest    >= BORE_OFF) abs_dest   = BORE_OFF;
	if (abs_source  >= BORE_OFF) abs_source = BORE_OFF;
	if (abs_dest    <= BAR) abs_dest   = BAR;
	if (abs_source  <= BAR) abs_source = BAR;

	int rel_dest = RelativePos(p,abs_dest);
	int rel_src  = RelativePos(p, abs_source);
	bgplayer  op = GetOtherPlayer(p);

	// Error checking
    if (rel_dest >  BORE_OFF) 
	  {rel_dest   = BORE_OFF; m_display->DisplayError(this, 9);}
	if (rel_src  >= BORE_OFF) 
	  {rel_src    = BORE_OFF; m_display->DisplayError(this, 10);}
	if (rel_dest <= BAR) 
	  {rel_dest   = BAR; m_display->DisplayError(this, 11);}
	if (rel_src  <  BAR) 
	  {rel_src    = BAR; m_display->DisplayError(this, 12);}

	// Move the pieces
	m_aPoint[abs_source].m_nMen[p]++;

	if (place)
	{
		if (rel_dest >= BORE_OFF)
			m_aPoint[AbsolutePos(p,BORE_OFF)].m_nMen[p]--;
		else
			m_aPoint[abs_dest].m_nMen[p]--;

		if (opp_bumped)
		{
			m_aPoint[abs_dest].m_nMen[op] = 1;
			m_aPoint[AbsolutePos(op,BAR)].m_nMen[op]--;
				
			// If opponent was bumped off of rel positions 19-24, must
			// increment home board count...
			int op_rel_dest = RelativePos(op,abs_dest);
			if ((op_rel_dest <= 24) && (op_rel_dest >= 19))
				m_nHomeBoard[op]++;
		}
	}

	if ((rel_dest <= 24) && (rel_dest >= 19) && (rel_src < 19))
		m_nHomeBoard[p]--;

	return true;
}

// Roll the dice for each player and detect doubles
void Backgammon::RollDice()
{
	m_aDice[WHITE] = (diceroll)m_rg.UniformIntRV(ROLL1,ROLL6);
	m_aDice[BLACK] = (diceroll)m_rg.UniformIntRV(ROLL1,ROLL6);
	m_bDoubles     = (m_aDice[BLACK] == m_aDice[WHITE]);
}

// Determine if this move is legal according to the move rules of Backgammon
bool Backgammon::IsLegalMove(bgplayer p, point abs_source, point abs_dest, int die)
{
	if (p != m_nTurn)
		return false;
	
	int off = AbsolutePos(p, BORE_OFF);
	int bar = AbsolutePos(p, BAR);
	int rel_dest = RelativePos(p, abs_dest);
	int rel_src  = RelativePos(p, abs_source);

	if ((rel_dest >  BORE_OFF) || (rel_dest <= BAR) ||
		(rel_src  >= BORE_OFF) || (rel_src  <  BAR))
		return false;

	// Need to check move count, source > 0, dest not blocked
	if (m_aPoint[bar].m_nMen[p] > 0)
	{
		// Must remove men from bar first
		T2(4,"   IsLegalMove::Man on bar",abs_source,abs_dest);
		if ((abs_source != bar) ||
			(m_aPoint[abs_source].m_nMen[p] == 0) ||
			(m_aPoint[abs_dest].m_nMen[GetOtherPlayer(p)] > 1))
			return false;
	}
	else if (m_nHomeBoard[p] == 15)
	{
		// Player is bearing men
		T2(4,"   IsLegalMove::Bearing men",abs_source,abs_dest);
		if ((m_aPoint[abs_source].m_nMen[p] == 0) ||
			((m_aPoint[abs_dest].m_nMen[GetOtherPlayer(p)] > 1) && (rel_dest != BORE_OFF)))
			return false;

		// See if distance matches exactly
		if (ABS(abs_source - abs_dest) == die)
			return true;

		// Make sure die is sufficent for move
		if (ABS(abs_source - abs_dest) > die)
			return false;

		// Make sure no higher points that could be moved from exist
		for (int pt=BORE_OFF - die; pt < rel_src; pt++)
			if (m_aPoint[AbsolutePos(p,pt)].m_nMen[p] > 0)
				return false;
	}
	else
	{
		// Normal play
		if (m_aPoint[abs_source].m_nMen[p] == 0)              T(4,"Fail1");
		if (rel_dest <= BAR)                                  T(4,"Fail2");
		if (rel_dest >= BORE_OFF)                             T(4,"Fail3");
		if (m_aPoint[abs_dest].m_nMen[GetOtherPlayer(p)] > 1) T(4,"Fail4");

		if ((m_aPoint[abs_source].m_nMen[p] == 0) ||
			(rel_dest <= BAR) ||
			(rel_dest >= BORE_OFF) ||
			(m_aPoint[abs_dest].m_nMen[GetOtherPlayer(p)] > 1))
		{
			T2(4,"   Failed",abs_source,abs_dest);
			return false;
		}
		else
			T2(4,"   Passed",abs_source,abs_dest);
	}

	return true;
}

// Generate all possible moves for the current player and game state
bool Backgammon::GenerateMoves(bgplayer p)
{
	if (p != m_nTurn)
		return false;

	// Generate all possible moves
	if (m_bDoubles)
		m_nValidMoves = PopulateMovesetD(p, m_aMoves, 0, m_aDice[0], 4, 0, BAR);
	else
		m_nValidMoves = PopulateMovesetND(p, m_aMoves, 0, 
										  MIN(m_aDice[0],m_aDice[1]), 
										  MAX(m_aDice[0],m_aDice[1]));

	// Find a sufficing move if no others are possible
	if (m_nValidMoves == 0)
		if (m_aDice[0] == m_aDice[1])
			for (int rolls = 3; (m_nValidMoves == 0) && rolls > 0; rolls--)
				m_nValidMoves = PopulateMovesetD(p, m_aMoves, 0, m_aDice[0], rolls, 0, BAR);
		else
			m_nValidMoves = PopulateMovesetBest(p, m_aMoves, 0, 
											    MAX(m_aDice[0],m_aDice[1]), 
											    MIN(m_aDice[0],m_aDice[1]));

	return true;
}

// Generate non-doubles moves 
int  Backgammon::PopulateMovesetND(bgplayer p, SMoveChunk mv[], int moves,
	                   int die1, int die2)
{
	int src1, dest1, src2, dest2;
	bool bump1, bump2;

	T(4,"PopulateMovesetND");

	for(int pt = BAR; pt < BORE_OFF; pt++)
	{
		// Try die 1 then die 2 and vice versa
		for (int move_att=0; move_att<=1; move_att++)
		{
			src1  = AbsolutePos(p, pt);
			dest1 = AbsolutePos(p, pt + ((move_att)?die1:die2));

			T2(4,"3-->",src1, dest1);

			if (IsLegalMove(p, src1, dest1, ((move_att)?die1:die2)))
			{
				if (WhoHasWon() == NEITHER) // Game still playing...
				{
					bump1 = MakeMove(p, src1, dest1, true);
					for (int pt2 = pt + ((move_att==1)?1:0); pt2 < BORE_OFF; pt2++)
					{
						src2  = AbsolutePos(p, pt2);
						dest2 = AbsolutePos(p, pt2 + ((move_att)?die2:die1));
						if (IsLegalMove(p, src2, dest2, ((move_att)?die2:die1)))
						{
							T2(4,"3---->",src2, dest2);

							bump2 = MakeMove(p, src2, dest2, true);
							m_aMoves[moves].m_nMoveElems = 2;
							m_aMoves[moves].m_elem[0].m_nSrc  = src1;
							m_aMoves[moves].m_elem[0].m_nDest = dest1;
							m_aMoves[moves].m_elem[1].m_nSrc  = src2;
							m_aMoves[moves].m_elem[1].m_nDest = dest2;
							moves++;

							UndoMove(p, src2, dest2, bump2, true);
						}
					}
					UndoMove(p, src1, dest1, bump1, true);
				}
				else // This move wins the game
				{
					m_aMoves[moves].m_nMoveElems = 1;
					m_aMoves[moves].m_elem[0].m_nSrc  = src1;
					m_aMoves[moves].m_elem[0].m_nDest = dest1;
					moves++;
				}
			}
		}
	}

	return moves;
}

// Generate doubles moves recursively ... please excuse the vestigial code
// from earlier iterations of the project
int  Backgammon::PopulateMovesetD(bgplayer p, SMoveChunk mv[], int moves, 
	                  int die, int rolls_left, int indiv_moves,
					  int rel_curpt)
{
	int dest, src;
	bool bump;

	T(4,"PopulateMovesetD");

	// Base case: no more rolls left
	if ((rolls_left == 0) || (WhoHasWon() != NEITHER))
	{
		m_aMoves[moves].m_nMoveElems = indiv_moves;
		moves++;

		// Populate next move set in case it is used again, otherwise any
		// moves in common with the previous move would not be set
		for (int sm = 0; sm < m_aMoves[moves-1].m_nMoveElems; sm++)
		{
			m_aMoves[moves].m_elem[sm].m_nSrc  = m_aMoves[moves-1].m_elem[sm].m_nSrc;
			m_aMoves[moves].m_elem[sm].m_nDest = m_aMoves[moves-1].m_elem[sm].m_nDest;
		}
		return moves;
	} 
	else if (rolls_left < 0) 
		{ return moves;	m_display->DisplayError(this, 4); }

	// Recursive case: rolls_left > 0
	for (int pt = rel_curpt; pt < BORE_OFF; pt++)
	{
			src  = AbsolutePos(p, pt);
			dest = AbsolutePos(p, pt + die);

			T2(4,"D-->",src, dest);

			if (IsLegalMove(p, src, dest, die))
			{
				m_aMoves[moves].m_elem[indiv_moves].m_nSrc  = src;
				m_aMoves[moves].m_elem[indiv_moves].m_nDest = dest;
				bump = MakeMove(p, src, dest, true);
				moves = PopulateMovesetD(p, mv, moves, die, rolls_left-1,
					                     indiv_moves+1, pt);
				UndoMove(p, src, dest, bump, true);
			}
	}

	return moves;
}

// Generate a sufficing move if all the die cannot be used...
int Backgammon::PopulateMovesetBest(bgplayer p, SMoveChunk mv[], int moves, 
								    int die1, int die2)
{
	if (die1 == die2)
		m_display->DisplayError(this, 1);

	int src, desta, destb;

	// Let's see if we can move just one man (we obviously can't move both)
	for(int pt = BAR; pt < BORE_OFF; pt++)
	{
		src   = AbsolutePos(p, pt);
		desta = AbsolutePos(p, pt + die1);
		destb = AbsolutePos(p, pt + die2);
		if (IsLegalMove(p, src, desta, die1))
		{
			m_aMoves[moves].m_nMoveElems = 1;
			m_aMoves[moves].m_elem[0].m_nSrc  = src;
			m_aMoves[moves].m_elem[0].m_nDest = desta;
			moves++;
		}
		else if (IsLegalMove(p, src, destb, die2))
		{
			m_aMoves[moves].m_nMoveElems = 1;
			m_aMoves[moves].m_elem[0].m_nSrc  = src;
			m_aMoves[moves].m_elem[0].m_nDest = destb;
			moves++;
		}
	}

	return moves;
}

// Allow the player to derive features for a move
void Backgammon::DeriveFeatures(bgplayer p, Player* player)
{
	// For every move, set the board state and then call the
	// player's polymorphic function with the proper move
	// and a reference to this
	for (int m=0; m<m_nValidMoves; m++)
		DeriveFeatures(p, player, m, 0);
}

// Recursively makes a move, calls DeriveFeatures() for player when
// move is fully made, and then undoes the move on recursion exit
void Backgammon::DeriveFeatures(bgplayer p, Player* player, int mv, int moves)
{
	// Base case
	if (moves == m_aMoves[mv].m_nMoveElems)
	{
		player->DeriveFeatures(this, mv);
		return;
	}

	bool bump = MakeMove(p, m_aMoves[mv].m_elem[moves].m_nSrc,
						    m_aMoves[mv].m_elem[moves].m_nDest, true);
	DeriveFeatures(p, player, mv, moves+1);
	UndoMove(p, m_aMoves[mv].m_elem[moves].m_nSrc,
		        m_aMoves[mv].m_elem[moves].m_nDest, bump, true);
}