function compare(granularity)

while (1)
   load results.txt; [games,w,b] = agdata(granularity,1,results,'First','Second',0.05, 1);
   total = size(results,1);
   black = 100.*sum(results(:,2))./total;
   white = 100-black;
   fprintf(1,'Running total: White(%2.1f%%)  Black(%2.1f%%)\n',white,black);
   pause(5);
end

