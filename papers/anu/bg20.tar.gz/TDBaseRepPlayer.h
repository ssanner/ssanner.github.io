////////////////////////////////////////////////////////
// Class:  TDBaseRepPlayer
// Author: Scott P. Sanner
//
// Description:
//
// This player uses the TD(lambda) reinforcement learning
// algorithm along with a backpropagation neural net
// to learn to play backgammon 
//
////////////////////////////////////////////////////////

#ifndef _TD_BASEREP_PLAYER_H_
#define _TD_BASEREP_PLAYER_H_

#undef NDEBUG

#include <stdlib.h>
#include <fstream.h>
#include "Backgammon.h"
#include "BaseRepPlayer.h"
#include "Feature.h"
#include "NeuralNet.h"

#define INPUT_UNITS  (46)
#define OUTPUT_UNITS  (1)
#define PT_START      (1)
#define OP_START     (25)
#define SZ_START     (40)

// Uncomment the following line to see a printout of debug info for the player
//#define TD_BASEREP_PRINT_DEBUG

class TDBaseRepPlayer: public BaseRepPlayer
{
	public:
		TDBaseRepPlayer(int filenum);
		virtual ~TDBaseRepPlayer();

		virtual void Reset();            // Indicates beginning of game
		virtual void Update(bool win, int blot_pt); // Indicates end of game and win/loss
										            // or blot_pt if not (-1)
		virtual void SetMoveUtilities(); // Sets m_aMoveValue array for each move
		virtual void SelectMove(int mv); // Indicates which move was selected

		void  SetEta(float val) { ETA = val;  }
		float GetEta()          { return ETA; }

		void  SetMomentum(float val) { MOMENTUM = val;  }
		float GetMomentum()          { return MOMENTUM; }

		void  SetHidden(int val)   { HIDDEN = val;  }
		int   GetHidden()          { return HIDDEN; }

		void  SetLambda(float val) { LAMBDA = val;  }
		float GetLambda()          { return LAMBDA; }

	protected:
		void  SetNeuralNetInputs(Feature &f);
		float GetNeuralNetOutput(Feature &f);

		FeatureSetArray m_fsaMoves; // FeatureSetArray of move features from 0 to end of game

		int  m_nFeatures;   // Number of chunked (compiled) features
		bool m_bLearningOn; // Is learning on?

		float  LAMBDA;       /* The TD(lambda) like discount rate    */
		double ETA;          /* Neural net value for eta             */
		double MOMENTUM;     /* Neural net value for momentum        */
		int    HIDDEN;       /* Number of hidden units in neural net */

		int m_nFilenum; // For running multiple TD-BaseRep instantiations at one time

		NeuralNet **m_aNNUtilities; // One neural net for each feature type to be learned

		#ifdef TD_BASEREP_PRINT_DEBUG
		TextDisplay *m_adisp;
		ofstream     m_aoutfile;
		#endif

	private:
		TDBaseRepPlayer() {} // Prevent from being called
};

#endif // _TD_BASEREP_PLAYER_H_