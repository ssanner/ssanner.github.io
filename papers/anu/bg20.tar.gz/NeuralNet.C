#include <math.h>
#include <stdlib.h>
#include "NeuralNet.h"

// ================================================================
// NeuralNet class implementation (sanner)
NeuralNet::NeuralNet()
{
	m_bpNet = NULL;
	m_nInputUnits  = -1;
	m_nHiddenUnits = -1;
	m_nOutputUnits = -1;
}

NeuralNet::NeuralNet(int input, int hidden, int output, double eta, double momentum)
{
	if ((input < 0) || (hidden < 0) || (output < 0))
	{
		m_bpNet = NULL;
		m_nInputUnits  = -1;
		m_nHiddenUnits = -1;
		m_nOutputUnits = -1;
		return;
	}

	m_bpNet = bpnn_create(input, hidden, output, m_rvGen);
	m_nInputUnits  = input;
	m_nHiddenUnits = hidden;
	m_nOutputUnits = output;
	m_dEta = eta;
	m_dMomentum = momentum;

	m_rvGen.InitRVSeed(CNEURALNET_RNDSEED);
}

NeuralNet::NeuralNet(istream &is)
{
	LoadNet(is);
}

NeuralNet::~NeuralNet()
{
	bpnn_free(m_bpNet);
	m_bpNet = NULL;
	m_nInputUnits  = -1;
	m_nHiddenUnits = -1;
	m_nOutputUnits = -1;
}

void NeuralNet::RandomizeWeights()
{
	if (m_bpNet == NULL) return;
	bpnn_randomize_weights(m_bpNet->input_weights, m_nInputUnits, m_nHiddenUnits, m_rvGen);
	bpnn_randomize_weights(m_bpNet->hidden_weights, m_nHiddenUnits, m_nOutputUnits, m_rvGen);
	bpnn_zero_weights(m_bpNet->input_prev_weights, m_nInputUnits, m_nHiddenUnits);
	bpnn_zero_weights(m_bpNet->hidden_prev_weights, m_nHiddenUnits, m_nOutputUnits);
}

void NeuralNet::ZeroWeights()
{
	if (m_bpNet == NULL) return;
	bpnn_zero_weights(m_bpNet->input_weights, m_nInputUnits, m_nHiddenUnits);
	bpnn_randomize_weights(m_bpNet->hidden_weights, m_nHiddenUnits, m_nOutputUnits, m_rvGen);
	bpnn_zero_weights(m_bpNet->input_prev_weights, m_nInputUnits, m_nHiddenUnits);
	bpnn_zero_weights(m_bpNet->hidden_prev_weights, m_nHiddenUnits, m_nOutputUnits);
}

bool NeuralNet::SetInput (int unit, double value)
{
	if ((m_bpNet == NULL) || (unit < 1) || (unit > m_nInputUnits)) 
	{ cerr << "Out of bounds input index" << endl; return false; }
	m_bpNet->input_units[unit] = value;
	return true;
}

bool NeuralNet::SetTarget(int unit, double value)
{
	if ((m_bpNet == NULL) || (unit < 1) || (unit > m_nOutputUnits)) 
	{ cerr << "Out of bounds target index" << endl; return false; }
	m_bpNet->target[unit] = value;
	return true;
}

double NeuralNet::GetOutput(int unit)
{
	if ((m_bpNet == NULL) || (unit < 1) || (unit > m_nOutputUnits)) 
		return (-1);
	return m_bpNet->output_units[unit];
}

bool NeuralNet::SetInputWeight(int in, int hid, double value)
{
	if ((m_bpNet == NULL) || (in > m_nInputUnits) 
		|| (hid > m_nHiddenUnits) || (hid < 1))
		return false;

	m_bpNet->input_weights[in][hid] = value;
	return true;
}

bool NeuralNet::SetHiddenWeight(int hid, int out, double value)
{
	if ((m_bpNet == NULL) || (hid > m_nHiddenUnits) 
		|| (out > m_nOutputUnits) || (out < 1)) 
		return false;

	m_bpNet->hidden_weights[hid][out] = value;
	return true;
}

double NeuralNet::GetInputWeight(int in, int hid)
{
	if ((m_bpNet == NULL) || (in > m_nInputUnits) 
		|| (hid > m_nHiddenUnits) || (hid < 1)) 
		return (-1.0);

	return m_bpNet->input_weights[in][hid];
}

double NeuralNet::GetHiddenWeight(int hid, int out)
{
	if ((m_bpNet == NULL) || (hid > m_nHiddenUnits) 
		|| (out > m_nOutputUnits) || (out < 1)) 
		return (-1.0);

		return m_bpNet->hidden_weights[hid][out];
}

void NeuralNet::FeedForward()
{
	if (m_bpNet == NULL) return;
	bpnn_feedforward(m_bpNet);
}

void NeuralNet::BackPropError()
{
	if (m_bpNet == NULL) return;
	bpnn_train(m_bpNet, m_dEta, m_dMomentum, &m_dOutErr, &m_dHidErr);
}


// Loads the neural net from the given input stream
bool NeuralNet::SaveNet(ostream &os)
{
	int i, j;
	double **w;

	os << "Neural-Net:" << endl << endl;
	os << "Input:    " << m_nInputUnits  << endl;
	os << "Hidden:   " << m_nHiddenUnits << endl;
	os << "Output:   " << m_nOutputUnits << endl;
	os << "Eta:      " << m_dEta << endl;
	os << "Momentum: " << m_dMomentum << endl;

	os << "In-Hidden:" << endl;
	w = m_bpNet->input_weights;
	for (i = 0; i <= m_nInputUnits; i++) 
	{
		for (j = 0; j <= m_nHiddenUnits; j++) 
		{
			os << w[i][j] << " ";
		}
		os << endl;
	}

	os << "Hidden-Out:" << endl;
	w = m_bpNet->hidden_weights;
	for (i = 0; i <= m_nHiddenUnits; i++) 
	{
		for (j = 0; j <= m_nOutputUnits; j++) 
		{
			os << w[i][j] << " ";
		}
		os << endl;
	}

	return true;
}

// Writes the neural net to the given output stream
bool NeuralNet::LoadNet(istream &is)
{
	int i, j;
	double **w;
	char text[80];

	is >> text;
	if (strcmp(text,"Neural-Net:") != 0) { m_bpNet = NULL; return false; }
	is >> text;
	if (strcmp(text,"Input:") != 0)      { m_bpNet = NULL; return false; }
	is >> m_nInputUnits;
	is >> text;
	if (strcmp(text,"Hidden:") != 0)     { m_bpNet = NULL; return false; }
	is >> m_nHiddenUnits;
	is >> text;
	if (strcmp(text,"Output:") != 0)     { m_bpNet = NULL; return false; }
	is >> m_nOutputUnits;
	is >> text;
	if (strcmp(text,"Eta:") != 0)        { m_bpNet = NULL; return false; }
	is >> m_dEta;
	is >> text;
	if (strcmp(text,"Momentum:") != 0)   { m_bpNet = NULL; return false; }
	is >> m_dMomentum;

 	m_bpNet = bpnn_create(m_nInputUnits, m_nHiddenUnits, m_nOutputUnits, m_rvGen);
	m_rvGen.InitRVSeed(CNEURALNET_RNDSEED);

	is >> text;
	if (strcmp(text,"In-Hidden:") != 0)  {bpnn_free(m_bpNet); m_bpNet = NULL; cerr << "In-Hidden unspecified" << endl; return false;}
	w = m_bpNet->input_weights;
	for (i = 0; i <= m_nInputUnits; i++) 
		for (j = 0; j <= m_nHiddenUnits; j++) 
			is >> w[i][j];

	is >> text;
	if (strcmp(text,"Hidden-Out:") != 0) {bpnn_free(m_bpNet); m_bpNet = NULL; cerr << "Hidden-Out unspecified" << endl;return false;}
	w = m_bpNet->hidden_weights;
	for (i = 0; i <= m_nHiddenUnits; i++) 
		for (j = 0; j <= m_nOutputUnits; j++) 
			is >> w[i][j];

	bpnn_zero_weights(m_bpNet->input_prev_weights,  m_nInputUnits,  m_nHiddenUnits);
	bpnn_zero_weights(m_bpNet->hidden_prev_weights, m_nHiddenUnits, m_nOutputUnits);

	return true;
}

// End of class implementation (sanner)
// ================================================================

#ifndef ABS
#define ABS(x)          (((x) > 0.0) ? (x) : (-(x)))
#endif

/*** The squashing function.  Currently, it's a sigmoid. ***/
double squash(double x)
{
  return (1.0 / (1.0 + exp(-x)));
}

/*** Allocate 1d array of doubles ***/
double *alloc_1d_dbl(int n)
{
  double *pnew;

  pnew = (double *) malloc ((unsigned) (n * sizeof (double)));
  if (pnew == NULL) {
    cout << "ALLOC_1D_DBL: Couldn't allocate array of doubles\n";
    return (NULL);
  }
  return (pnew);
}

/*** Allocate 2d array of doubles ***/
double **alloc_2d_dbl(int m, int n)
{
  int i;
  double **pnew;

  pnew = (double **) malloc ((unsigned) (m * sizeof (double *)));
  if (pnew == NULL) {
    cout << "ALLOC_2D_DBL: Couldn't allocate array of dbl ptrs\n";
    return (NULL);
  }

  for (i = 0; i < m; i++) {
    pnew[i] = alloc_1d_dbl(n);
  }

  return (pnew);
}


void bpnn_randomize_weights(double **w, int m, int n, RandomGen &rv_gen)
{
  int i, j;

  for (i = 0; i <= m; i++) {
    for (j = 0; j <= n; j++) {
      //w[i][j] = dpn1();
	  w[i][j] = (2*rv_gen.UniformRV())-1;
    }
  }
}


void bpnn_zero_weights(double **w, int m, int n)
{
  int i, j;

  for (i = 0; i <= m; i++) {
    for (j = 0; j <= n; j++) {
      w[i][j] = 0.0;
    }
  }
}

BPNN *bpnn_internal_create(int n_in, int n_hidden, int n_out)
{
  BPNN *newnet;

  newnet = (BPNN *) malloc (sizeof (BPNN));
  if (newnet == NULL) {
    cout << "BPNN_CREATE: Couldn't allocate neural network\n";
    return (NULL);
  }

  newnet->input_n = n_in;
  newnet->hidden_n = n_hidden;
  newnet->output_n = n_out;
  newnet->input_units = alloc_1d_dbl(n_in + 1);
  newnet->hidden_units = alloc_1d_dbl(n_hidden + 1);
  newnet->output_units = alloc_1d_dbl(n_out + 1);

  newnet->hidden_delta = alloc_1d_dbl(n_hidden + 1);
  newnet->output_delta = alloc_1d_dbl(n_out + 1);
  newnet->target = alloc_1d_dbl(n_out + 1);

  newnet->input_weights = alloc_2d_dbl(n_in + 1, n_hidden + 1);
  newnet->hidden_weights = alloc_2d_dbl(n_hidden + 1, n_out + 1);

  newnet->input_prev_weights = alloc_2d_dbl(n_in + 1, n_hidden + 1);
  newnet->hidden_prev_weights = alloc_2d_dbl(n_hidden + 1, n_out + 1);

  return (newnet);
}

void bpnn_free(BPNN *net)
{
  int n1, n2, i;

  n1 = net->input_n;
  n2 = net->hidden_n;

  free((char *) net->input_units);
  free((char *) net->hidden_units);
  free((char *) net->output_units);

  free((char *) net->hidden_delta);
  free((char *) net->output_delta);
  free((char *) net->target);

  for (i = 0; i <= n1; i++) {
    free((char *) net->input_weights[i]);
    free((char *) net->input_prev_weights[i]);
  }
  free((char *) net->input_weights);
  free((char *) net->input_prev_weights);

  for (i = 0; i <= n2; i++) {
    free((char *) net->hidden_weights[i]);
    free((char *) net->hidden_prev_weights[i]);
  }
  free((char *) net->hidden_weights);
  free((char *) net->hidden_prev_weights);

  free((char *) net);
}

/*** Creates a new fully-connected network from scratch,
     with the given numbers of input, hidden, and output units.
     Threshold units are automatically included.  All weights are
     randomly initialized.

     Space is also allocated for temporary storage (momentum weights,
     error computations, etc).
***/
BPNN *bpnn_create(int n_in, int n_hidden, int n_out, RandomGen &rv_gen)
{
  BPNN *newnet;

  newnet = bpnn_internal_create(n_in, n_hidden, n_out);

#ifdef INITZERO
  bpnn_zero_weights(newnet->input_weights, n_in, n_hidden);
#else
  bpnn_randomize_weights(newnet->input_weights, n_in, n_hidden, rv_gen);
#endif
  bpnn_randomize_weights(newnet->hidden_weights, n_hidden, n_out, rv_gen);
  bpnn_zero_weights(newnet->input_prev_weights, n_in, n_hidden);
  bpnn_zero_weights(newnet->hidden_prev_weights, n_hidden, n_out);

  return (newnet);
}

void bpnn_layerforward(double *l1, double *l2, double **conn, int n1, int n2)
{
  double sum;
  int j, k;

  /*** Set up thresholding unit ***/
  l1[0] = 1.0;

  /*** For each unit in second layer ***/
  for (j = 1; j <= n2; j++) {

    /*** Compute weighted sum of its inputs ***/
    sum = 0.0;
    for (k = 0; k <= n1; k++) {
      sum += conn[k][j] * l1[k];
    }
    l2[j] = squash(sum);
  }

}

void bpnn_output_error(double *delta, double *target, double *output, int nj, double *err)
{
  int j;
  double o, t, errsum;

  errsum = 0.0;
  for (j = 1; j <= nj; j++) {
    o = output[j];
    t = target[j];
    delta[j] = o * (1.0 - o) * (t - o);
    errsum += ABS(delta[j]);
  }
  *err = errsum;
}

void bpnn_hidden_error(double *delta_h, int nh, double *delta_o, 
					   int no, double **who, double *hidden, double *err)
{
  int j, k;
  double h, sum, errsum;

  errsum = 0.0;
  for (j = 1; j <= nh; j++) {
    h = hidden[j];
    sum = 0.0;
    for (k = 1; k <= no; k++) {
      sum += delta_o[k] * who[j][k];
    }
    delta_h[j] = h * (1.0 - h) * sum;
    errsum += ABS(delta_h[j]);
  }
  *err = errsum;
}

void bpnn_adjust_weights(double *delta, int ndelta, double *ly, int nly,
						 double **w, double **oldw, double eta, double momentum)
{
  double new_dw;
  int k, j;

  ly[0] = 1.0;
  for (j = 1; j <= ndelta; j++) {
    for (k = 0; k <= nly; k++) {
      new_dw = ((eta * delta[j] * ly[k]) + (momentum * oldw[k][j]));
      w[k][j] += new_dw;
      oldw[k][j] = new_dw;
    }
  }
}

void bpnn_feedforward(BPNN *net)
{
  int in, hid, out;

  in = net->input_n;
  hid = net->hidden_n;
  out = net->output_n;

  /*** Feed forward input activations. ***/
  bpnn_layerforward(net->input_units, net->hidden_units,
      net->input_weights, in, hid);
  bpnn_layerforward(net->hidden_units, net->output_units,
      net->hidden_weights, hid, out);

}

void bpnn_train(BPNN *net, double eta, double momentum, double *eo, double *eh)
{
  int in, hid, out;
  double out_err, hid_err;

  in = net->input_n;
  hid = net->hidden_n;
  out = net->output_n;

  /*** Feed forward input activations. ***/
  bpnn_layerforward(net->input_units, net->hidden_units,
      net->input_weights, in, hid);
  bpnn_layerforward(net->hidden_units, net->output_units,
      net->hidden_weights, hid, out);

  /*** Compute error on output and hidden units. ***/
  bpnn_output_error(net->output_delta, net->target, net->output_units,
      out, &out_err);
  bpnn_hidden_error(net->hidden_delta, hid, net->output_delta, out,
      net->hidden_weights, net->hidden_units, &hid_err);
  *eo = out_err;
  *eh = hid_err;

  /*** Adjust input and hidden weights. ***/
  bpnn_adjust_weights(net->output_delta, out, net->hidden_units, hid,
      net->hidden_weights, net->hidden_prev_weights, eta, momentum);
  bpnn_adjust_weights(net->hidden_delta, hid, net->input_units, in,
      net->input_weights, net->input_prev_weights, eta, momentum);

}

