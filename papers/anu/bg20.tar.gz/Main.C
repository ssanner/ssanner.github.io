////////////////////////////////////////////////////
//
// Project: Backgammon
//
// Author:  Scott P. Sanner
//          Senior Computer Science Research Project
//          Carnegie Mellon University
//
// Date:    9/15/99
//
// Note:    To add a new player or display, simply
//          derive a new class from the base virtual
//          class, provide implementations for the
//          virtual functions and update the
//          following sections of this file:
//
//          1) #include section
//          2) #define MAX_DISP_ID or MAX_PLAYER_ID
//          3) getdisplay(), closedisplay()
//             or getbgplayer() functions
//          4) usage() function
//
//          All of these file sections are marked
//          with *NEW.
//
////////////////////////////////////////////////////

// Include files for I/O and Backgammon classes
#include <ctype.h>
#include <stdlib.h>
#include <iostream.h>
#include "Backgammon.h"
#include "BackgammonDisplay.h"
#include "Player.h"
#include "TDPlayer.h"
#include "ACTRPlayer.h"
#include "TDBaseRepPlayer.h"

// Defines for main()
#define MIN_PLAYER_ID 1
#define MAX_PLAYER_ID 8 // *NEW: Update this if adding a player
#define MIN_DISP_ID   1
#define MAX_DISP_ID   3 // *NEW: Update this if adding a display
#define WHITE_PLAYER  1
#define BLACK_PLAYER  2
#define DISPLAY       3
#define GAMES         4
#define DEF_ARGS      5 
#define RESULTS_FILE  "results.txt"
#define LENGTH_FILE   "length.txt"
#define DISP_FILE     "textdisp.txt"

// Global files
ofstream g_results_file; // Results of game runs go into this file
ofstream g_length_file;  // Results of game lengths go into this file
ofstream g_disp_file;    // The destination for file display output

// Define helper functions for main()
BackgammonDisplay* getdisplay  (int id);
Player*  getbgplayer (int id);
void     closedisplay(int id);
bool     outofrange  (int lo, int hi, int num);
void     usage       ();

// Entry point for the backgammon program
int main(int argc, char** argv)
{
	BackgammonDisplay *disp;
	Player  *white, *black;
	bgplayer winner;
	int nwhite, nblack, ndisp, ngames;

	// Disallow a no-argument command line
	//if (argc == 1)
	//{
	//	// Use defaults if no args
	//	nwhite = 4; // TD Player is White
	//	nblack = 3; // Text Player is Black
	//	ndisp  = 1; // Text Display is Standard Out
	//	ngames = 1; // Play one game
	//}
	/*else*/ if ((argc != DEF_ARGS) || (argv[1][0] == 'h') ||  
		(outofrange(MIN_PLAYER_ID, MAX_PLAYER_ID, nwhite = atoi(argv[WHITE_PLAYER]))) ||
		(outofrange(MIN_PLAYER_ID, MAX_PLAYER_ID, nblack = atoi(argv[BLACK_PLAYER]))) ||
		(outofrange(MIN_DISP_ID,   MAX_DISP_ID,   ndisp  = atoi(argv[DISPLAY     ]))) ||
		((ngames = atoi(argv[GAMES])) < 1))
	{ 
		// Print out usage if incorrect arguments
		usage(); 
		exit(-1); 
	}

	// Retrieve appropriate players and display to init backgammon
	white = getbgplayer(nwhite);
	black = getbgplayer(nblack);
	disp  = getdisplay (ndisp);
	Backgammon bg(white, black, disp);

	// Play backgammon #games times and record results in 'results.txt'
	g_results_file.open(RESULTS_FILE, ios::out|ios::trunc);
	g_length_file.open (LENGTH_FILE,  ios::out|ios::trunc); 
	//g_results_file <<    "White = (ID:" << WHITE << ",Type:" << nwhite
	//               << "); Black = (ID:" << BLACK << ",Type:" << nblack
	//	             << "); Game#, Winner ID on each line" << endl;         
	for (int g=0; g<ngames; g++)
	{	
		winner = bg.StartGame();
		g_results_file << (g+1) << " " << winner << endl;
		g_length_file  << (g+1) << " " << bg.m_nTurnsPlayed << endl;
	}

	// Close up any open files remaining
	g_results_file.close();
	g_length_file.close();
	closedisplay(ndisp);
	
	delete disp;
	delete white;
	delete black;

	return 0;
}

// Return a new instance of the player given the player type ID
Player* getbgplayer(int id)
{
	switch (id)
	{
	case 1: return new RandomPlayer;
	case 2: return new StaticPlayer;
	case 3: return new TextPlayer;
	case 4: return new TDPlayer;
	case 5: return new ACTRPlayer(1);
	case 6: return new ACTRPlayer(2);
	case 7: return new TDBaseRepPlayer(1);
	case 8: return new TDBaseRepPlayer(2);
	// *NEW: Update this if adding a new player
	}

	return NULL;
}

// Return a new instance of the display given the display type ID
BackgammonDisplay* getdisplay(int id)
{
	switch (id)
	{
	case 1: return  new TextDisplay;
	case 2: {g_disp_file.open(DISP_FILE, ios::out|ios::trunc); 
		     return new TextDisplay(g_disp_file);}
	case 3: return  new NullDisplay;
	// *NEW: Update this if adding a new display
	}

	return NULL;
}

// Close the display corresponding to the given display type ID
void closedisplay(int id)
{
	switch (id)
	{
	case 1: {} break;
	case 2: { g_disp_file.close(); } break;
	case 3: {} break;
	// *NEW: Update this if adding a new display
	}
}

// Print out the command line uage parameters
void usage()
{
	cout <<   "\n   usage: " << "backgammon" 
		 << " <White Player> <Black Player> <Display> <# Games>";

	cout << "\n\n   Players:";
	cout <<   "\n   --------";
	cout <<   "\n   1: Random Player   (Randomly selects moves)";
	cout <<   "\n   2: Static Player   (Always selects first move)";
	cout <<   "\n   3: Text Player     (User interface)";
	cout <<   "\n   4: Pubeval         (Single layer neural net)";
	cout <<   "\n   5: ACT-R v.1       (Prob. Learning/PM,Config #1)";
	cout <<   "\n   6: ACT-R v.2       (Prob. Learning/PM,Config #2)";
	cout <<   "\n   7: TD-Base Rep v.1 (*In progress*,Config #1)";
	cout <<   "\n   8: TD-Base Rep v.2 (*In progress*,Config #2)";
	// *NEW: Update the command line usage here when adding a player
	
	cout << "\n\n   Displays:";
	cout <<   "\n   ---------";
	cout <<   "\n   1: Console Output (ASCII Text)";
	cout <<   "\n   2: File Output    (ASCII Text > 'textdisp.txt')";
	cout <<   "\n   3: Null Display   (No display)" << endl << endl;
	// *NEW: Update the command line usage here when adding a display
}

// Range detection
bool outofrange(int lo, int hi, int num)
{
	return ((num < lo) || (num > hi));
}