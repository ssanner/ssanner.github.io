%
predict_AFL;
data = 1
predict_UK;
data = 2
predict_Halo;
data = 3