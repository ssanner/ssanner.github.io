close all; 
clear all;

fprintf('running on AFL dataset \n'); 
Predict_AFL;

fprintf('running on UK dataset \n'); 
predict_UK;

fprintf('running on Halo dataset \n'); 
predict_Halo;

% plot results;
plotResult;

