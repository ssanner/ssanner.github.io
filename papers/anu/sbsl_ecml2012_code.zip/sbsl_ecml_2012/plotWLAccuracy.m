function plotWLAccuracy(xInd, y, error, axisLim, tit, fileName, flag)
markers = 15; 
if flag == 1
    x = [xInd; xInd; xInd; xInd; xInd]';
    figure1 = figure('PaperSize',[20.98 29.68]);
    % Create axes
    axes1 = axes('Parent',figure1,'FontSize',20,'FontName','Times New Roman');
    box(axes1,'on');
    hold(axes1,'all');
    % Create multiple error bars using matrix input to errorbar
    errorbar1 = errorbar(x, y, error);
    set(errorbar1(5),'Marker','v', 'MarkerSize', markers, 'DisplayName','Gaussian-SD', 'LineWidth',2);
    set(errorbar1(4),'Marker','^', 'MarkerSize', markers, 'DisplayName','TrueSkill',   'LineWidth',2);
    set(errorbar1(3),'Marker','<', 'MarkerSize', markers, 'DisplayName','Gaussian-S',  'LineWidth',2);
    set(errorbar1(2),'Marker','>', 'MarkerSize', markers, 'DisplayName','Logistic',   'LineWidth',2);
    set(errorbar1(1),'Marker','o', 'MarkerSize', markers, 'DisplayName','Poisson',     'LineWidth',2);
    
    title(tit,'FontSize',20,'FontName','Times New Roman');
    legend1 = legend(axes1,'show');
    set(legend1,'Location','SouthEast','FontSize',16);
    axis(axisLim);
    xlabel('Proportion of data used for training','FontSize',20,...
        'FontName','Times New Roman');
    ylabel('AUC', 'FontSize',20,...
        'FontName','Times New Roman');
    saveas(figure1, fileName, 'pdf');
elseif flag == 0
    x = [xInd; xInd; xInd; xInd]';
    fontSize = 28;
    y(:, 2) = [];
    error(:,2) = [];
    % figure1 = figure('PaperSize',[20.98 29.68]);
    figure1 = figure('PaperOrientation', 'landscape', 'PaperUnits', 'normalized', 'PaperPosition', [0 0 1 1]);
    % Create axes
    axes1 = axes('Parent',figure1,'FontSize',fontSize,'FontName','Times New Roman');
    
    box(axes1,'on');
    hold(axes1,'all');
    % Create multiple error bars using matrix input to errorbar
    errorbar1 = errorbar(x, y, error);
    set(errorbar1(4),'Marker','v', 'MarkerSize', markers, 'DisplayName','Gaussian-SD','LineWidth',3);
    set(errorbar1(3),'Marker','^', 'MarkerSize', markers, 'DisplayName','TrueSkill','LineWidth',3);
    set(errorbar1(2),'Marker','<', 'MarkerSize', markers, 'DisplayName','Gaussian-OD','LineWidth',3);
    %set(errorbar1(2),'Marker','>', 'DisplayName','Logistic');
    set(errorbar1(1),'Marker','o', 'MarkerSize', markers, 'DisplayName','Poisson-OD','LineWidth',3);
    title(tit,'FontSize',fontSize,'FontName','Times New Roman')
    legend1 = legend(axes1,'show');
    set(legend1,'Location','best','FontSize',fontSize, 'Visible', 'off');
    axis(axisLim);
    xlabel('Proportion of data used for training','FontSize',fontSize,...
        'FontName','Times New Roman');
    ylabel('AUC', 'FontSize',fontSize,...
        'FontName','Times New Roman');
    saveas(figure1, fileName, 'pdf');
end
end