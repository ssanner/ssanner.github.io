% Shengbo Guo
% Xerox Research Centre Europe
% email: shengbo.guo@xrce.xerox.com

To reproduce all the results, simply run the script -- wrapper.m. 

