a = 9;
c = 4;
if a >2
    if c >3 
        b = 1;
    end
else
    b = 2;
end
b