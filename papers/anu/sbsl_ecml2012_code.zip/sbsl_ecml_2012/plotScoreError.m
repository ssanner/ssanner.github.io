function plotScoreError(xInd, y, error, axisLim, tit, fileName)
x = [xInd; xInd; xInd]';
markers = 15; 
% figure1 = figure('PaperSize',[20.98/5 29.68/5]);
fontSize = 28;
figure1 = figure('PaperOrientation', 'landscape', 'PaperUnits', 'normalized', 'PaperPosition', [0 0 1 1]);
% Create axes
axes1 = axes('Parent',figure1,'FontSize',fontSize,'FontName','Times New Roman');
box(axes1,'on');
hold(axes1,'all');
% Create multiple error bars using matrix input to errorbar
% errorbar1 = errorbar(x, y, error);

% comment out the Gaussian-SD for predicting scores. 
x(:, 3) = [];
y(:, 3) = [];
error(:, 3) = [];
errorbar1 = errorbar(x, y, error);
% set(errorbar1(3),'Marker','v', 'MarkerSize', 5, 'DisplayName','Gaussian-SD', 'Color',[0 0.749 0.749], 'LineWidth',2);
set(errorbar1(2),'Marker','<', 'MarkerSize', markers, 'DisplayName','Gaussain-OD', 'Color',[0 0.498 0], 'LineWidth',3);
set(errorbar1(1),'Marker','o', 'MarkerSize', markers, 'DisplayName','Poisson-OD', 'LineWidth',3);

title(tit,'FontSize',fontSize,'FontName','Times New Roman')
legend1 = legend(axes1,'show');
set(legend1,'Location','Best','FontSize', fontSize, 'Visible', 'off');
xlabel('Proportion of data used for training','FontSize', fontSize,...
    'FontName','Times New Roman');
ylabel('MAE of scores','FontSize', fontSize,...
    'FontName','Times New Roman');
axis(axisLim)
saveas(figure1, fileName, 'pdf');
end