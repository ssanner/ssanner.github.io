% organize data
readXML
load pemaut
numFeatures = 8;

beliefFeature = cell( 1, numFeatures );
priorBelief = Gaussian(25, 25/3);
numChoicesFeaturewise = [8 7 28 10 3 10 13 16];
for i = 1:numFeatures
    beliefFeature{1, i}                = cell(1, numChoicesFeaturewise(i));
    for idxChoices = 1:numChoicesFeaturewise(i)
        beliefFeature{1, i}{idxChoices}= priorBelief;
    end
end
numProductAll = 120;

% Assume the all configurations of products are feasible;
numProduct = numProductAll;
trueBelief_uniform = saveUserUtlity{1, 1};
trueBelief_diag   = saveUserUtlity{1, 2};
saveResult = cell(2, 10);
%--------------------------------------------------------------------------
depth = 2;
drawProb = 10;
tailProbThreshold = 0;
numExperiment = 20;
sizeOfQuery = 2;
performanceStd = 1;
maxIter      = 20;
maximumUtilityProductID = zeros( 1, maxIter );
omega = 0;

    for beliefOption = [0]
        maxItemId = zeros (numExperiment, maxIter);
        timeUsed  = zeros (numExperiment, maxIter);
        estimatedMax = maxItemId;
        % When no knowledge about the weight is known, we should use
        % uniform weights
        weightAssignment = [1 1; 1 1; 1 1];
       
        if beliefOption == 0
            trueBelief = trueBelief_uniform;
        elseif beliefOption == 1
            trueBelief = trueBelief_diag;
        else 
            trueBelief = trueBelief_stochastic;
        end
        
        trueBeliefProduct = zeros(numProductAll, 1);
        for idxProduct = 1:numProductAll
            trueBeliefProduct(idxProduct) = 0;
            for idxFeature = 1:numFeatures
                trueBeliefProduct(idxProduct) = trueBeliefProduct(idxProduct) + trueBelief{1, idxFeature} (productIndex(idxProduct, idxFeature));
            end
        end
        max(trueBeliefProduct)
        if length( unique(trueBeliefProduct) ) ~= numProductAll
            disp('Two of products are of the same utility according to the user!')
        end
        
          
        
        d = max(trueBeliefProduct) - min(trueBeliefProduct);
        queryStrategy = [0 2 4 5 8];
        sizeOfStrategy = length( queryStrategy );
        idxStrategy = 0;

        resultExpectedLoss  = zeros( sizeOfStrategy, maxIter);
        resultStandardError = resultExpectedLoss;
        resultExpectedLossEstimated  = resultExpectedLoss;
        resultStandardErrorEstimated = resultExpectedLoss;

        resultUptoNQueryTimeExpected = resultExpectedLoss;
        resultUptoNQueryTimeStandardError = resultExpectedLoss;
        resultCounterUCP = zeros(sizeOfStrategy, numExperiment); % find best product by u-omega*sigma
        resultCounterUCP0 = zeros(sizeOfStrategy, numExperiment); % find best product by u
        resultStatCounterUCP = cell(sizeOfStrategy, 1);
        resultStatCounterUCP0 = cell(sizeOfStrategy, 1);
        for option     = queryStrategy    % random pick items for query
            option
            idxStrategy = idxStrategy + 1;
            tempResultUCP = zeros(1, numExperiment);
            tempResultUCP0 = zeros(1, numExperiment);
            tempResultStatCounterUCP = zeros(numExperiment, maxIter);
            tempResultStatCounterUCP0 = zeros(numExperiment, maxIter);
            for iterExperiment = 1:numExperiment
                iterExperiment
                % reset beliefFeature
                priorBelief = Gaussian(25, 25/3);
                for i = 1:numFeatures
                    hint = strcat('Please input the number of choices for feature No. ', num2str(i), ' : \ ');
                    %numChoicesFeaturewise(i)    = input( hint );
                    beliefFeature{1, i}                = cell(1, numChoicesFeaturewise(i));
                    for idxChoices = 1:numChoicesFeaturewise(i)
                        beliefFeature{1, i}{idxChoices}= priorBelief;
                    end
                end
                belief = cell(numProductAll, numFeatures);
                queryHistory = [];
                counterUCP = 0;
                counterUCP0 = 0;
                for iter=1:maxIter
                     % Get feature belief for each product
                    for idxProduct = 1:numProductAll
                        for idxFeature = 1:numFeatures
                            belief{idxProduct, idxFeature} = beliefFeature{1, idxFeature}{ productIndex(idxProduct, idxFeature) };
                        end
                    end
                    tic
                    % Select sizeOfQuery items for a query
                    if iter == 1
                        [itemList productBelief]= selectItems ( belief, sizeOfQuery, option, performanceStd );
                        idxUCP = 0;
                        idxUCP0 = 0;
                    else
                        [itemList productBelief idxUCP idxUCP0]= selectItemsUsePervious ( belief, sizeOfQuery, option, performanceStd, omega, queryHistory, ...
                                                                           productBeliefFinalUpdated, weightAssignment, d, ...
                                                                           productIndex, depth, drawProb, tailProbThreshold);
                    end
                    timeUsed( iterExperiment, iter) = toc;
                    queryHistory            = [queryHistory; itemList];
                    rank                    = askUser ( trueBeliefProduct, itemList);
                    belief                  = updateBelief ( belief, itemList, rank, performanceStd );
                    [tempEstimatedMax, maximumUtilityProductID, productBeliefFinalUpdated]= findMaximumUtility(belief, omega, performanceStd, ...
                                                                                               productBelief, itemList);
                    maxItemId( iterExperiment, iter ) = maximumUtilityProductID;    
                    estimatedMax ( iterExperiment, iter ) = tempEstimatedMax;
                    
                    % Counter tracker
                    counterUCP = counterUCP + idxUCP;
                    counterUCP0 = counterUCP0 + idxUCP0;
                    tempResultStatCounterUCP (iterExperiment, iter) = idxUCP;
                    tempResultStatCounterUCP0 (iterExperiment, iter) = idxUCP0;
                    
                    % Reset after each experiment
                    if iter == maxIter
                        queryHistory = [];
                        tempResultUCP(iterExperiment) = counterUCP;
                        tempResultUCP0(iterExperiment) = counterUCP0;
                        counterUCP = 0;
                        counterUCP0 = 0;
                    end                   
                    % Set feature belief for those involved in the query
                    for idxFeature = 1:numFeatures 
                        if productIndex(itemList(1), idxFeature) == productIndex(itemList(2), idxFeature)    % share features
                            belief{itemList(1), idxFeature} = belief{itemList(1), idxFeature} * belief{itemList(2), idxFeature};
                            beliefFeature{1, idxFeature}{productIndex(itemList(1), idxFeature)} = belief{itemList(1), idxFeature};
                        else                                                                                 % non-share features
                            beliefFeature{1, idxFeature}{productIndex(itemList(1), idxFeature)} = belief{itemList(1), idxFeature};
                            beliefFeature{1, idxFeature}{productIndex(itemList(2), idxFeature)} = belief{itemList(2), idxFeature};
                        end                        
                    end
                end
                
            end
            [expectedLoss standardError expectedLossEstimated standardErrorEstimated] = computeExpectedLossStandardError( trueBeliefProduct, ...
                                                                                                                maxItemId, estimatedMax );
            resultExpectedLoss(idxStrategy, :)          = expectedLoss;
            resultStandardError(idxStrategy, :)         = standardError;
            resultExpectedLossEstimated(idxStrategy, :) = expectedLossEstimated;
            resultStandardErrorEstimated(idxStrategy, :)= standardErrorEstimated;
            resultUptoNQueryTimeExpected(idxStrategy, :)= mean(timeUsed);
            resultUptoNQueryTimeStandardError(idxStrategy, :) = std(timeUsed)/sqrt(numExperiment);
            resultCounterUCP(idxStrategy, :)            = tempResultUCP;
            resultCounterUCP0(idxStrategy, :)           = tempResultUCP0;
            resultStatCounterUCP{idxStrategy}           = tempResultStatCounterUCP;
            resultStatCounterUCP0{idxStrategy}          = tempResultStatCounterUCP0;
        end
        saveResult{beliefOption+1, 1} = resultExpectedLoss;
        saveResult{beliefOption+1, 2} = resultStandardError;
        saveResult{beliefOption+1, 3} = resultExpectedLossEstimated;
        saveResult{beliefOption+1, 4} = resultStandardErrorEstimated;
        saveResult{beliefOption+1, 5} = resultUptoNQueryTimeExpected;
        saveResult{beliefOption+1, 6} = resultUptoNQueryTimeStandardError;        
        saveResult{beliefOption+1, 7} = resultCounterUCP;
        saveResult{beliefOption+1, 8} = resultCounterUCP0;
        saveResult{beliefOption+1, 9} = resultStatCounterUCP;
        saveResult{beliefOption+1, 10}= resultStatCounterUCP0;
    end
save PCUniformFinalAISTATS saveResult