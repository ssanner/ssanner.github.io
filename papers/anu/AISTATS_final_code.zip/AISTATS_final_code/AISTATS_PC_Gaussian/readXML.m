[ tree treeName ] = xml_read('database_pcdataset.xml');
numProducts = size( tree.data, 2 );
numFeatures = size( tree.data(1).attribute, 2 );
productDescription = cell( numProducts, numFeatures );
featureName = cell(1, numFeatures);

for idxFeature = 1:numFeatures
    featureName{ idxFeature } = tree.data(1).attribute(idxFeature).ATTRIBUTE.name;
end

for idxProduct = 1:numProducts 
    for idxFeature = 1:numFeatures 
        productDescription { idxProduct, idxFeature } = tree.data(idxProduct).attribute(idxFeature).ATTRIBUTE.value;        
    end
end

attributeSummary = cell( numFeatures, 1 );
for idxFeature = 1:numFeatures 
    attributeSummary{ idxFeature } = unique( [productDescription{:, idxFeature}] );
end

attributeSummary{1} = {'Apple', 'Compaq', 'Dell', 'Fujitsu', 'Gateway', 'HP', 'Sony', 'Toshiba'};
attributeSummary{2} = {'PowerPC G3', 'PowerPC G4', 'Intel Pentium', 'ADM Athlon', 'Intel Celeron', 'Crusoe', 'AMD Duron'};
attributeSummary{5} = {'Laptop', 'Desktop', 'Tower'};

% The minimum is 658 and the maximum price is 3649
priceInterval = [600:150:2800 3649];
lengthPrice = length(priceInterval);
attributeSummary{8} = priceInterval;

productIndex = zeros(numProducts, numFeatures);
for idxProduct = 1:numProducts
    for idxFeature = 1:numFeatures
        value = productDescription{idxProduct, idxFeature};
        switch idxFeature
            case {1, 2, 5}
                for kk = 1:size(attributeSummary{idxFeature}, 2)
                    if strcmp(value, attributeSummary{idxFeature}{kk})
                        productIndex(idxProduct, idxFeature) = kk;
                        break;
                    end
                end                    
            case {3, 4, 6, 7}
                productIndex(idxProduct, idxFeature) = find( value == attributeSummary{idxFeature} ); 
            case 8
                if value == attributeSummary{8}(end)
                    productIndex(idxProduct, idxFeature) = lengthPrice;
                else
                    temp = value - priceInterval;
                    pos = find(temp <= 0);
                    productIndex(idxProduct, idxFeature) = pos(1) - 1;
                end
            otherwise
                disp('wrong attribute no.!')
        end
    end     
end

    