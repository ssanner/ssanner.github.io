function [expectedLoss standardError expectedLossEstimated standardErrorEstimated] = computeExpectedLossStandardError( trueBelief, maxItemID, estimatedMax )

    [numExperiment numIter] = size(maxItemID);

    expectedLoss = zeros(1, numIter);
    standardError = zeros(1, numIter);
    expectedLossEstimated = expectedLoss;
    standardErrorEstimated = expectedLoss;
    expectedLossMatrix = zeros ( size(maxItemID) );
    maxUserUtility = max( trueBelief );
    for i = 1:numExperiment
        expectedLossMatrix( i, :) = maxUserUtility - trueBelief( maxItemID( i, : ) );  
    end
    estimatedMax = abs ( maxUserUtility - estimatedMax );
    for i = 1:numIter
        expectedLoss(i) = mean( expectedLossMatrix(:, i) );
        standardError(i) = std( expectedLossMatrix(:, i) )/sqrt(numExperiment) ;
        expectedLossEstimated(i) = mean( estimatedMax(:, i) );
        standardErrorEstimated(i) = std( estimatedMax(:, i) )/sqrt(numExperiment) ;
    end
end
