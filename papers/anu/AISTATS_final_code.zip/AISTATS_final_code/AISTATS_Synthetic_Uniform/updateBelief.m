function belief = updateBelief ( belief, itemList, rank, performanceStd)
% updateBelief	Dedicated function to update belief based on user response
%
% Inputs : 
%       - belief: n*d cell array. n -- no. of items; d -- no. of features; each cell is the belief over user's utility over the attribute of the item. 
%       - itemList: indices of two items that are used to query the user
%       - rank: 
%           -1 if the second item in the itemList is preferred
%           1  if the first item in the itemList is preferred
%           0  if the user is indifferent regarding these two items in the itemList. 
%
% Outputs :
%           - belief: n*d cell array with updated belief. 
%
% Usage Example : 
%
% Note	: 
%
% See also

% Uses :

% Change History :
% Date		Time		Prog	Note

% Shengbo Guo,
% XRCE - Xerox Research Centre Europe
% e-mail : shengbo.guo@xrce.xerox.com

numFeature = size(belief, 2);
if rank == 0
    isDraw = 'Y';
elseif rank == -1
    % Make sure the winner item is at the beginning of the list.
    isDraw = 'N';
    temp = itemList(1);
    itemList(1) = itemList(2);
    itemList(2) = temp;
else
    isDraw = 'N';
end

% drawProb  = input ('Draw probability (0 - 100): ');
drawProb = 10;
priorSkills = [ belief{ itemList(1), :} belief{ itemList(2), :} ];
%[ posteriorSkills, logZ ] = NPlayerTrueSkillUpdate (performanceStd, 1e-5*performanceStd, 1e-4, drawProb/100, priorSkills, draws);
posteriorSkills = NPlayerTrueSkillUpdateTeam (performanceStd, 1e-5*performanceStd, 1e-4, drawProb/100, priorSkills, isDraw);
belief( itemList(1), : ) = posteriorSkills(1 : numFeature);
belief( itemList(2), : ) = posteriorSkills(numFeature+1 : end);

%quality = exp (logZ) * 100.0;
end