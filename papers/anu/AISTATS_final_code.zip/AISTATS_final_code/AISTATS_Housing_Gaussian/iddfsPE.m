function queryNo = iddfsPE(belief, timeSlot)

% Find the number of the query, queryNo, by using IDDFS within the time
% limit of timeslot
tic
[numProduct, junk ] = size(belief);
d = 1;
b = nchoosek( numProduct, 2 );
while (toc < timeSlot)
    totalNode = 0;
    for i = 1:d
        totalNode = totalNode + d^i;
    end
    nodeNumList = 1:totalNode;
    depth = depth + 1;
end