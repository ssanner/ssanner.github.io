function [varBag, MessageBag] = UpdateHelperGaussianWeightedSumFactorTeamPerformance(wTeamPerformances, wTeamPerformancesSquared, ...
                                                                                                messageIdx1, messageIdxs, MessageBag, ...
                                                                                                v1, varIdxs, varBag, noPlayers)
% UpdateHelper for GaussianWeightedSumFactor
    d = cell(1, noPlayers/2);
    for i = 1:noPlayers/2
        d{i} = varBag{ varIdxs(i) } / MessageBag{ messageIdxs(i) };
    end
    msg1 = MessageBag{messageIdx1};
    mar1 = varBag{v1};
    newPrecisionInv = 0;
    for i = 1:noPlayers/2
        newPrecisionInv = newPrecisionInv + wTeamPerformancesSquared(i)*1/d{i}.Precision;
    end
    newPrecision = 1/newPrecisionInv;
    newPrecisionMeanPart = 0;
    for i = 1:noPlayers/2
        newPrecisionMeanPart = newPrecisionMeanPart + wTeamPerformances(i) * d{i}.PrecisionMean / d{i}.Precision;
    end
    newPrecisionMean = newPrecision * newPrecisionMeanPart;
    MessageBag{messageIdx1} = Gaussian ( newPrecisionMean / newPrecision, sqrt ( 1 / newPrecision ) );
    oldMarginalWithoutMsg = mar1 / msg1;
    varBag{v1} = oldMarginalWithoutMsg * MessageBag{messageIdx1};
end