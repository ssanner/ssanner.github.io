timeVector = zeros(1, 3);

tic
resultExpectedLoss  = [];
resultStandardError = [];
numProduct = 20;
sizeOfQuery = 2;
disp('option 0: Random pick two');% disp('option 1: Maximum matching quality');disp('option 2: Best two items');disp('option 3: Best and worst items');
disp('option 4: VOI');
maxIter      = 50;
maximumUtilityProductID = zeros( 1, maxIter );
numExperiment = 50;
maxItemId = zeros (numExperiment, maxIter);
% the user's hidden utility over all product, Uniform distribution (1, 100)
load trueBelief_uniform_as_a_base_for_OtherStratagies.mat;
% beliefOption: 0, uniform; 1, diagonal, 2, stochastic
beliefOption = 0;
load trueBelief_diag;
load trueBelief_stochastic;
load trueBelief_uniform;
%trueBelief_uniform = 1 + (100-1)*rand(1,numProduct);
if beliefOption == 0
    trueBelief = trueBelief_uniform;
elseif beliefOption == 1
    trueBelief = trueBelief_diag;
elseif beliefOption == 2
    trueBelief = trueBelief_stochastic;
end
u_low = min(trueBelief);
u_upper = max(trueBelief);
gridNum = 2000;
numSamples = 20000;
burnK = 10000;
epsilon = 10;
userTrueUtility = max(trueBelief);
for option     = [0 2 3 4]    % random pick items for query
    colLoss = zeros(numExperiment, maxIter);
    for iterExperiment = 1:numExperiment
        for iter=1:maxIter
            % Select sizeOfQuery items for a query
            itemList  = selectItemsUniform ( convexSet, sizeOfQuery, option, epsilon, numProduct, u_low, u_upper, gridNum, numSamples, burnK);
            rank      = askUser ( trueBelief, itemList, noisyLevel );
            % update feasible utility function space by adding a constraint
            % based on the user's response
            tempConvexSet(1:2) = itemList;
            tempConvexSet(3) = rank;
            convexSet = [convexSet; tempConvexSet];
            samples = MHsampling( numProduct, u_low, u_upper, gridNum, convexSet, numSamples, burnK, epsilon);
            [junk maximumUtilityProductID]= max (mean( samples ) );
            loss    = userTrueUtility - trueBelief( currentMaxUtilityID );
            colLoss (iterExperiment, iter) = loss;                          
        end
    end
    % Compute expected loss and standard error
    resultExpectedLoss  = [ resultExpectedLoss; mean(colLoss)];
    resultStandardError = [ resultStandardError; std(colLoss)];
end
% fclose(fid);
figure;
comp = 1:maxIter;
a = [comp; comp; comp; comp ];
% a = [comp; comp];
errorbar(a', resultExpectedLoss', resultStandardError','-o')
[val1 junk] = max ( max( resultExpectedLoss ) );
[val2 junk] = max (max( resultStandardError ) );
yMax = val1+ val2+0.5;
legend('Random Two', 'Best Two', 'Best & Worst', 'Value of Info.')
% legend('random', 'best two')
xlabel('Number of queries');
ylabel('Expected loss');
axis([0.5 maxIter 0 yMax])
title('Uniform utility, 20 items');
% title('Diagonal covariance Gaussian utility, 20 items, no noise--single update');
% title('Stochastic covariance Gaussian utility, 20 items, noisy response: 5%');
resultExpectedLossUniform1 = resultExpectedLoss;
resultStandardErrorUniform1 = resultStandardError;
timeVector(1) = toc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
tic
resultExpectedLoss  = [];
resultStandardError = [];
numProduct = 20;
sizeOfQuery = 2;
disp('option 0: Random pick two');% disp('option 1: Maximum matching quality');disp('option 2: Best two items');disp('option 3: Best and worst items');
disp('option 4: VOI');
maxIter      = 50;
maximumUtilityProductID = zeros( 1, maxIter );
numExperiment = 50;
maxItemId = zeros (numExperiment, maxIter);
% the user's hidden utility over all product, Uniform distribution (1, 100)
load trueBelief_uniform_as_a_base_for_OtherStratagies.mat;
% beliefOption: 0, uniform; 1, diagonal, 2, stochastic
beliefOption = 1;
load trueBelief_diag;
load trueBelief_stochastic;
load trueBelief_uniform;
%trueBelief_uniform = 1 + (100-1)*rand(1,numProduct);
if beliefOption == 0
    trueBelief = trueBelief_uniform;
elseif beliefOption == 1
    trueBelief = trueBelief_diag;
elseif beliefOption == 2
    trueBelief = trueBelief_stochastic;
end
u_low = min(trueBelief);
u_upper = max(trueBelief);
gridNum = 2000;
numSamples = 20000;
burnK = 10000;
epsilon = 10;
userTrueUtility = max(trueBelief);
for option     = [0 2 3 4]    % random pick items for query
    colLoss = zeros(numExperiment, maxIter);
    for iterExperiment = 1:numExperiment
        for iter=1:maxIter
            % Select sizeOfQuery items for a query
            itemList  = selectItemsUniform ( convexSet, sizeOfQuery, option, epsilon, numProduct, u_low, u_upper, gridNum, numSamples, burnK);
            rank      = askUser ( trueBelief, itemList, noisyLevel );
            % update feasible utility function space by adding a constraint
            % based on the user's response
            tempConvexSet(1:2) = itemList;
            tempConvexSet(3) = rank;
            convexSet = [convexSet; tempConvexSet];
            samples = MHsampling( numProduct, u_low, u_upper, gridNum, convexSet, numSamples, burnK, epsilon);
            [junk maximumUtilityProductID]= max (mean( samples ) );
            loss    = userTrueUtility - trueBelief( currentMaxUtilityID );
            colLoss (iterExperiment, iter) = loss;                          
        end
    end
    % Compute expected loss and standard error
    resultExpectedLoss  = [ resultExpectedLoss; mean(colLoss)];
    resultStandardError = [ resultStandardError; std(colLoss)];
end
figure;
comp = 1:maxIter;
a = [comp; comp; comp; comp ];
errorbar(a', resultExpectedLoss', resultStandardError','-o')
[val1 junk] = max ( max( resultExpectedLoss ) );
[val2 junk] = max (max( resultStandardError ) );
yMax = val1+ val2+0.5;
legend('Random Two', 'Best Two', 'Best & Worst', 'Value of Info.')
xlabel('Number of queries');
ylabel('Expected loss');
axis([0.5 maxIter 0 yMax])
title('Diagonal covariance Gaussian utility, 20 items');
resultExpectedLossDiag = resultExpectedLoss;
resultStandardErrorDiag = resultStandardError;
timeVector(2) = toc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tic
resultExpectedLoss  = [];
resultStandardError = [];
numProduct = 20;
sizeOfQuery = 2;
disp('option 0: Random pick two');% disp('option 1: Maximum matching quality');disp('option 2: Best two items');disp('option 3: Best and worst items');
disp('option 4: VOI');
maxIter      = 50;
maximumUtilityProductID = zeros( 1, maxIter );
numExperiment = 50;
maxItemId = zeros (numExperiment, maxIter);
% the user's hidden utility over all product, Uniform distribution (1, 100)
load trueBelief_uniform_as_a_base_for_OtherStratagies.mat;
% beliefOption: 0, uniform; 1, diagonal, 2, stochastic
beliefOption = 2;
load trueBelief_diag;
load trueBelief_stochastic;
load trueBelief_uniform;
%trueBelief_uniform = 1 + (100-1)*rand(1,numProduct);
if beliefOption == 0
    trueBelief = trueBelief_uniform;
elseif beliefOption == 1
    trueBelief = trueBelief_diag;
elseif beliefOption == 2
    trueBelief = trueBelief_stochastic;
end
u_low = min(trueBelief);
u_upper = max(trueBelief);
gridNum = 2000;
numSamples = 20000;
burnK = 10000;
epsilon = 10;
userTrueUtility = max(trueBelief);
for option     = [0 2 3 4]    % random pick items for query
    colLoss = zeros(numExperiment, maxIter);
    for iterExperiment = 1:numExperiment
        for iter=1:maxIter
            % Select sizeOfQuery items for a query
            itemList  = selectItemsUniform ( convexSet, sizeOfQuery, option, epsilon, numProduct, u_low, u_upper, gridNum, numSamples, burnK);
            rank      = askUser ( trueBelief, itemList, noisyLevel );
            % update feasible utility function space by adding a constraint
            % based on the user's response
            tempConvexSet(1:2) = itemList;
            tempConvexSet(3) = rank;
            convexSet = [convexSet; tempConvexSet];
            samples = MHsampling( numProduct, u_low, u_upper, gridNum, convexSet, numSamples, burnK, epsilon);
            [junk maximumUtilityProductID]= max (mean( samples ) );
            loss    = userTrueUtility - trueBelief( currentMaxUtilityID );
            colLoss (iterExperiment, iter) = loss;                          
        end
    end
    % Compute expected loss and standard error
    resultExpectedLoss  = [ resultExpectedLoss; mean(colLoss)];
    resultStandardError = [ resultStandardError; std(colLoss)];
end
% fclose(fid);
figure;
comp = 1:maxIter;
a = [comp; comp; comp; comp ];
% a = [comp; comp];
errorbar(a', resultExpectedLoss', resultStandardError','-o')
[val1 junk] = max ( max( resultExpectedLoss ) );
[val2 junk] = max (max( resultStandardError ) );
yMax = val1+ val2+0.5;
legend('Random Two', 'Best Two', 'Best & Worst', 'Value of Info.')
% legend('random', 'best two')
xlabel('Number of queries');
ylabel('Expected loss');
axis([0.5 maxIter 0 yMax])
% title('Uniform utility, 20 items');
% title('Diagonal covariance Gaussian utility, 20 items, no noise--single update');
title('Stochastic covariance Gaussian utility, 20 items');
resultExpectedLossStoch = resultExpectedLoss;
resultStandardErrorStoch = resultStandardError;
timeVector(3) = toc;