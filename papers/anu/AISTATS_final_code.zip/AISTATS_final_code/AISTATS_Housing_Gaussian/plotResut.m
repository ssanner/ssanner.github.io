function plotResut(maxIter, resultExpectedLoss, resultStandardError, sizeOfStrategy, tit, yAxis)

if nargin < 7
    yAxis = 'Expected Loss';
end
figure;
comp = 1:maxIter;
a = zeros(sizeOfStrategy, maxIter);
for i = 1:sizeOfStrategy
    a(i, :) = comp;
end

errorbar(a', resultExpectedLoss', resultStandardError','-o')
[val1 junk] = max ( max( resultExpectedLoss ) );
[val2 junk] = max ( max( resultStandardError ) );
yMax = val1+ val2+0.5;
xlabel('Number of queries');
ylabel(yAxis);
legend('Random Two', 'Best Two', 'Best & Largest Uncertainty', 'VOI', 'Informed VOI', 'Uninformed VOI');
%axis([0.5 maxIter 0 yMax])
title(tit);