function utility = generateUserUtility( numProduct, option )

    % Generate the user's utility, according to option
    % option: 
    %       0 --> uniform in [1 100]
    %       1 --> Gaussian distribution with diagonal matrix
    %       2 --> Gaussian distribution with stochastic matrix
    utilityUniform = 1 + (100 - 1)*rand(1,numProduct);
    if option == 0
        utility = utilityUniform; 
    elseif option == 1
        SigmaDiag = diag( utilityUniform' );
        utility = mvnrnd( utilityUniform', SigmaDiag, 1);
    elseif option == 2
        productByFeature = randn( length(utilityUniform), 5*length(utilityUniform) );
        SigmaStochasticVariance = productByFeature * productByFeature';
        utility = mvnrnd(utilityUniform, SigmaStochasticVariance, 1);
    end

end
