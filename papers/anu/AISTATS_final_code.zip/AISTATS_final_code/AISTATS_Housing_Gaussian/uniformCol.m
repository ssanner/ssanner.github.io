productListTemp = 20;
total = length(productListTemp);
result = cell(total, 2);
for i = 1:total
    numProduct = productListTemp(i);
    numExperiment = 50;
    maxIter = 50;
    sizeOfQuery = 2;
    disp('Query option: 0--Randomly two')
    disp('              1--Best matching quality')
    disp('              2--Best two')
    disp('              3--Best & Worst')
    disp('              4--VoI.')
    % the user's hidden utility over all product, Uniform distribution (1, 100)
    trueBelief = 1 + (100 - 1) * rand(1, numProduct);
    u_low = min(trueBelief);
    u_upper = max(trueBelief);
    gridNum = 100;
    numSamples = 50000;
    burnK = 10000;
    epsilon = 10;
    userTrueUtility = max(trueBelief);
    fourMeanUtility = zeros(4, 1);
    fourStdUtility = zeros(4, 1);
    idx = 1;
    for option     = [0 2 3 4]    
        colLoss = zeros(numExperiment, 1);
        for iterExperiment = 1:numExperiment
            convexSet = [];
            tempConvexSet = zeros(1, 3);
            for iter=1:maxIter
                itemList  = selectItemsUniform ( convexSet, sizeOfQuery, option, epsilon, numProduct, u_low, u_upper, gridNum, numSamples, burnK);
                rank      = askUser ( trueBelief, itemList );
                % update feasible utility function space by adding a constraint
                % based on the user's response
                tempConvexSet(1:2) = itemList;
                tempConvexSet(3) = rank;
                convexSet = [convexSet; tempConvexSet];
                if iter == maxIter
                    samples = MHsampling( numProduct, u_low, u_upper, gridNum, convexSet, numSamples, burnK, epsilon);
                    [junk currentMaxUtilityID]= max (mean( samples ) );
                    loss    = userTrueUtility - trueBelief( currentMaxUtilityID );
                    colLoss (iterExperiment, 1) = loss;
                end
            end
        end
        fourMeanUtility(idx) = mean( colLoss );
        fourStdUtility(idx) = std( colLoss )/sqrt(numExperiment);
        idx = idx + 1;
    end
    result{i, 1} = fourMeanUtility;
    result{i, 2} = fourStdUtility; 
end 
