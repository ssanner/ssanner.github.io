load trueBelief_uniform_as_a_base_for_OtherStratagies.mat;

% beliefOption: 0, uniform; 1, diagonal, 2, stochastic
beliefOption = 2;
load trueBelief_diag;
load trueBelief_stochastic;
load trueBelief_uniform;
%trueBelief_uniform = 1 + (100-1)*rand(1,numProduct);
if beliefOption == 0
    trueBelief = trueBelief_uniform;
elseif beliefOption == 1
    trueBelief = trueBelief_diag;
elseif beliefOption == 2
    trueBelief = trueBelief_stochastic;
end

