x = -10:0.001:15;
mu1 = 5;
sigma1 = 2;
mu2 = 0;
sigma2 = 3;
figure
plot(x, normpdf(x, mu1, sigma1), 'r', 'LineWidth', 2);
hold on;
plot(x, normpdf(x, mu2, sigma2), 'b', 'LineWidth', 2);
xlarge = 5:0.001:15;
ylarge = normpdf(xlarge, mu2, sigma2);
xlabel('u')
ylabel('\phi_{\mu,\sigma^{2}}(u)')
title('Illustration of the expected value of information')
legend('N(5, 2)', 'N(0, 3)')
area(xlarge, ylarge)
hold off;

