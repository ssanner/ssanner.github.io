load PCUniformFinalAISTATS;

numQueryStrategies = 7;
queries = 20;
col = [1:queries]';

normZ = 541.3725;
x = [];
for i = 1:numQueryStrategies
    x = [x col];
end

y = resultExpectedLoss;
e = resultStandardError;
[row col] = size(y);
if row < col
    y = y';
    e = e';
end


   
% Create figure
figure1 = figure('PaperSize',[20.98 29.68]);

% Create axes
axes1 = axes('Parent',figure1,'FontSize',24,'FontName','Arial');
% Uncomment the following line to preserve the X-limits of the axes
% xlim(axes1,[0.5 20.5]);
% Uncomment the following line to preserve the Y-limits of the axes
% ylim(axes1,[0 0.37]);
box(axes1,'on');
hold(axes1,'all');

% Create multiple error bars using matrix input to errorbar
errorbar1 = errorbar(x, y/normZ, e/normZ);
set(errorbar1(7),'MarkerSize',10,'Marker','*',...
    'DisplayName','Restr. Informed VOI');
set(errorbar1(6),'Marker','square','DisplayName','Uninformed VOI');
set(errorbar1(5),'Marker','o','DisplayName','Informed VOI');
set(errorbar1(4),'Marker','v','DisplayName','Best & Larg. Uncer.');
set(errorbar1(3),'Marker','^','DisplayName','Simplified VOI');
set(errorbar1(2),'Marker','>','DisplayName','Best Two');
set(errorbar1(1),'Marker','<','DisplayName','Random Two');

% Create xlabel
xlabel('Number of queries','FontSize',24,'FontName','Arial');

% Create ylabel
ylabel('Normalized average loss','FontSize',24,'FontName','Arial');

% Create title
title('PC Dataset - Uniform Utility Distribution','FontSize',24,...
    'FontName','Arial');

% Create legend
legend(axes1,'show');
axis([0.5 20.5 0 0.37])
