function [ posteriorSkills, logZ ] = NPlayerTrueSkillUpdate( beta, tau, initial, drawProb, skills, draws)

    % NPlayerTrueSkillUpdate: Runs a full foward-backward factor graph analysis
    % on a chess outcome dataset with a fixed draw margin

    %Get the number of players from the number of skills
    noPlayers = length(skills);
    
    numberOfMessages = 7*noPlayers - 4;
    MessageBag = cell(1, numberOfMessages);
    for i = 1:numberOfMessages
        MessageBag{i} = Gaussian( 0, inf );
    end

    % Set maxIter
    maxIter = 1e6;
    % Compute the internal parameters
    betaSquared = beta * beta;
    tauSquared  = tau * tau;
    epsilon = -sqrt( 2 * betaSquared ) * PhiInverse (  (1 - drawProb) / 2 );

    % Allocate the dictionary of all relevant variables
    numberOfVariables = 3 * noPlayers - 1;
    varBag = cell(1, numberOfVariables);
    for i = 1:numberOfVariables
        varBag{i} = Gaussian( 0, inf ) ;
    end

    % The list of player skills
    playerSkills = 1:noPlayers;

    % The list of player performances
    playerPerformances = noPlayers+1:2*noPlayers;

    % The list of player performance differences
    playerPerformanceDifferences = (2*noPlayers+1) : (2*noPlayers + noPlayers - 1);

    % At first, send the skill priors of all players to the player variable
    % nodes and then fill the performances
    for i = 1:noPlayers
        newMsg = Gaussian ( skills{ playerSkills(i) }.Mu, sqrt (skills{ playerSkills(i) }.Variance + tauSquared) );

        oldMarginal = varBag{ playerSkills(i) };
        oldMsg      = MessageBag{ playerSkills(i) };
        
        tempPrecisionMean = oldMarginal.PrecisionMean + newMsg.PrecisionMean - oldMsg.PrecisionMean;
        tempPrecision     = oldMarginal.Precision + newMsg.Precision - oldMsg.Precision;
        tempMu            = tempPrecisionMean / tempPrecision;
        tempSigma         = sqrt( 1 / tempPrecision );
        newMarginal = Gaussian ( tempMu, tempSigma );
        varBag{ playerSkills(i) } = newMarginal;
        MessageBag {playerSkills(i)} = newMsg;    
    end

    for i = 1:noPlayers
        prec    = 1 / betaSquared;
        msg1Idx = playerPerformances(i) + noPlayers;   
        msg2Idx = playerSkills(i) + noPlayers;
        var1Idx = playerPerformances(i);
        var2Idx = playerSkills(i);
        [MessageBag, varBag] = UpdateHelperGaussianLikelihoodFactor(msg1Idx, msg2Idx, MessageBag, var1Idx, var2Idx, varBag, prec, 0);
    end

    % The inner loop schedule

    w  = [1; -1];
    a1 = w(1);
    a2 = w(2);
    weight0 = [a1; a2];
    weight1 = [-a2/a1; 1/a1];
    weight2 = [-a1/a2; 1/a2];
    weight0Squared = weight0.^2;
    weight1Squared = weight1.^2;
    weight2Squared = weight2.^2;
       
    if noPlayers == 2
       % Send the performance difference
       m1 = 5 * noPlayers - 1;
       m2 = 3 * noPlayers + 1;
       m3 = 3 * noPlayers + 2;
       v1 = 2 * noPlayers + 1;
       v2 = noPlayers + 1;
       v3 = noPlayers + 2;
       b1 = varBag;
       b2 = varBag;
       b3 = varBag;
       [varBag, MessageBag, delta] = UpdateHelperGaussianWeightedSumFactor(weight0, weight0Squared, m1, m2, m3, MessageBag, ...
                                                                                              v1, b1, v2, b2, v3, b3);
       % Send the greater-than
       if length(draws)>1
           error('The length of draws error!!');
       end
       msgIdx = 7 * noPlayers - 4;
       varIdx = 3 * noPlayers - 1;
       [varBag, MessageBag, delta] = UpdateHelperGreaterThanOrWithinFactors(draws, msgIdx, MessageBag, varIdx, varBag, epsilon);       
    else
       flag = 1;
       iterCnt = 1;
       deltaRes = [];
       while (flag)
            % For more than two players, choose a forward schedule and then ...
            for i = 1 : noPlayers - 2
                m1 = 5 * noPlayers -2 + i;
                m2 = 3 * noPlayers + 2 * i -1;
                m3 = 3 * noPlayers + 2 * i;
                v1 = playerPerformanceDifferences(i);
                v2 = playerPerformances(i);
                v3 = playerPerformances(i+1);
                b1 = varBag;
                b2 = varBag;
                b3 = varBag;
                [varBag, MessageBag, delta] = UpdateHelperGaussianWeightedSumFactor(weight0, weight0Squared, m1, m2, m3, MessageBag, ...
                                                                                             v1, b1, v2, b2, v3, b3);
                deltaRes = [deltaRes delta];
            end
            for i = 1 : noPlayers - 2
                msgIdx = 6 * noPlayers -3 + i;
                varIdx = playerPerformanceDifferences(i);           
                [varBag, MessageBag, delta] = UpdateHelperGreaterThanOrWithinFactors(draws(i), msgIdx, MessageBag, varIdx, varBag, epsilon);
                deltaRes = [deltaRes delta];
            end
            for i = 1 : noPlayers - 2
                m1 = 5 * noPlayers -2 + i;
                m2 = 3 * noPlayers + 2 * i -1;
                m3 = 3 * noPlayers + 2 * i;
                v1 = playerPerformanceDifferences(i);
                v2 = playerPerformances(i);
                v3 = playerPerformances(i+1);
                b1 = varBag;
                b2 = varBag;
                b3 = varBag;
                [varBag, MessageBag, delta] = UpdateHelperGaussianWeightedSumFactor(weight2, weight2Squared, m3, m2, m1, MessageBag, ...
                                                                                             v3, b3, v2, b2, v1, b1);
                deltaRes = [deltaRes delta];
            end
       
            % ... a backwards schedule which then get put together into a ...
            for i = noPlayers - 1 : -1 : 2
                m1 = 5 * noPlayers -2 + i;
                m2 = 3 * noPlayers + 2 * i -1;
                m3 = 3 * noPlayers + 2 * i;
                v1 = playerPerformanceDifferences(i);
                v2 = playerPerformances(i);
                v3 = playerPerformances(i+1);
                b1 = varBag;
                b2 = varBag;
                b3 = varBag;
                [varBag, MessageBag, delta] = UpdateHelperGaussianWeightedSumFactor(weight0, weight0Squared, m1, m2, m3, MessageBag, ...
                                                                                             v1, b1, v2, b2, v3, b3);
                deltaRes = [deltaRes delta];
            end    
            for i = noPlayers - 1 : -1 : 2
                msgIdx = 6 * noPlayers -3 + i;
                varIdx = playerPerformanceDifferences(i);           
                [varBag, MessageBag, delta] = UpdateHelperGreaterThanOrWithinFactors(draws(i), msgIdx, MessageBag, varIdx, varBag, epsilon);
                deltaRes = [deltaRes delta];
            end
            for i = noPlayers - 1 : -1 : 2
                m1 = 5 * noPlayers -2 + i;
                m2 = 3 * noPlayers + 2 * i -1;
                m3 = 3 * noPlayers + 2 * i;
                v1 = playerPerformanceDifferences(i);
                v2 = playerPerformances(i);
                v3 = playerPerformances(i+1);
                b1 = varBag;
                b2 = varBag;
                b3 = varBag;
                [varBag, MessageBag, delta] = UpdateHelperGaussianWeightedSumFactor(weight1, weight1Squared, m2, m3, m1, MessageBag, ...
                                                                                             v2, b2, v3, b3, v1, b1);
                deltaRes = [deltaRes delta];
            end
            iterCnt = iterCnt + 1;
            if iterCnt < maxIter && max(deltaRes)>initial
                flag = 1;
            else
                flag = 0;
            end
            deltaRes = [];
       % ... chain schedule!
       end
    end
    m1 = 5 * noPlayers - 1;
    m2 = 3 * noPlayers + 1;
    m3 = 3 * noPlayers + 2;
    v1 = playerPerformanceDifferences(1);
    v2 = playerPerformances(1);
    v3 = playerPerformances(2);
    b1 = varBag;
    b2 = varBag;
    b3 = varBag;
    [varBag, MessageBag, delta] = UpdateHelperGaussianWeightedSumFactor(weight1, weight1Squared, m2, m3, m1, MessageBag, ...
                                                                                             v2, b2, v3, b3, v1, b1);
    m1 = 6 * noPlayers - 3;
    m2 = 5 * noPlayers - 3;
    m3 = 5 * noPlayers - 2;
    v1 = playerPerformanceDifferences( noPlayers - 1 );
    v2 = playerPerformances( noPlayers - 1 );
    v3 = playerPerformances( noPlayers );
    b1 = varBag;
    b2 = varBag;
    b3 = varBag;                                                                                     
    [varBag, MessageBag, delta] = UpdateHelperGaussianWeightedSumFactor(weight2, weight2Squared, m3, m2, m1, MessageBag, ...
                                                                                             v3, b3, v2, b2, v1, b1);
    % At last, send the skill performances of all players to the player skills variable 
    for i = 1:noPlayers
        prec    = 1 / betaSquared;
        msg1Idx = playerPerformances(i) + noPlayers;   
        msg2Idx = playerSkills(i) + noPlayers;
        var1Idx = playerPerformances(i);
        var2Idx = playerSkills(i);
        [MessageBag, varBag] = UpdateHelperGaussianLikelihoodFactor(msg1Idx, msg2Idx, MessageBag, var1Idx, var2Idx, varBag, prec, 1);
    end
    
    posteriorSkills = cell( 1, noPlayers );
    for i = 1:noPlayers
        posteriorSkills{i} = varBag{i};
    end
    logZ = LogNormalisation(varBag, MessageBag, noPlayers, playerPerformances, playerPerformanceDifferences, draws, epsilon);
end 