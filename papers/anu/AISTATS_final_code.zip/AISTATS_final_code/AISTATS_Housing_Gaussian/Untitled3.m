function gain = computeGain ( productBelief{currentBestId}, beliefItem1Win, beliefItem2Win, beliefDraw, itemList1, weightAssigment)
    % Compute the gain of asking a query with [item1 item2]
    
end