function [winItemNew queryHistory maxItemId]= findWinItem(winItemsOld, userUtility, queryHistory, maxItemId)
    numWinProduct = length( winItemsOld );
    if mod( numWinProduct, 2 ) == 0
        winItemNew = [];
        comb = [ winItemsOld(1:2:numWinProduct)' winItemsOld(2:2:numWinProduct)'];
    else
        comb = [ winItemsOld(1:2:numWinProduct-2)'  winItemsOld(2:2:numWinProduct)'];
        winItemNew = winItemsOld( numWinProduct );
    end    
    for i = 1:numWinProduct/2
        [queryHistory, tempWinItem] = askUserTournamentSort( userUtility, comb(i, :), queryHistory );
        winItemNew = [winItemNew tempWinItem];
        first = randperm( length(winItemNew) );
        tempMaxItemId = winItemNew ( first(1));
        maxItemId = [maxItemId tempMaxItemId];
    end
end