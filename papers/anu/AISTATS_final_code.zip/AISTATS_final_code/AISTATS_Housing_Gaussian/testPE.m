% Preference elicitation application

% Initialization 

numProduct = 20;
sizeOfQuery = 2;
belief     = cell( 1, numProduct );
noisyLevel = 0.05;
performanceStd = 0.5;

disp('option 0: Random pick two');
disp('option 1: Maximum matching quality');
disp('option 2: Best two items');
disp('option 3: Best and worst items');
disp('option 4: VOI');

omega = 3;   % parameter for variance-adjusted expect utility: \mu - \omega * sigma
for i = 1: numProduct
    belief{i} = Gaussian( 25, 25/3 );
end


% the user's hidden utility over all product, Uniform distribution (1, 100)
load trueBelief_uniform_as_a_base_for_OtherStratagies.mat;

% beliefOption: 0, uniform as original; 1, Gaussian with diagonal, 2
% Gaussian with stochastic covariance matrix
beliefOption = 0;
load trueBelief_diag;
load trueBelief_stochastic;
load trueBelief_uniform;

if beliefOption == 0
    trueBelief = trueBelief_uniform;
elseif beliefOption == 1
    trueBelief = trueBelief_diag;
elseif beliefOption == 2
    trueBelief = trueBelief_stochastic;
end

maxIter      = 100;
maximumUtilityProductID = zeros( 1, maxIter );

numExperiment = 50;
maxItemId = zeros (numExperiment, maxIter);

for iterExperiment = 1:numExperiment
    iter = 1;
    for iter=1:maxIter
        % Select sizeOfQuery items for a query
        itemList                = selectItems ( belief, sizeOfQuery, option, performanceStd, omega );
        rank                    = askUser ( trueBelief, itemList, noisyLevel );
        [belief quality]        = updateBelief ( belief, itemList, rank, performanceStd );
        maximumUtilityProductID = findMaximumUtility ( belief, omega );
        maxItemId( iterExperiment, iter ) = maximumUtilityProductID;
    end
end

% Compute expected loss and standard error
[expectedLoss standardError] = computeExpectedLossStandardError( trueBelief, maxItemId );


