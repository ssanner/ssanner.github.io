function matchQuality = evaluateMatchQuality(gauss1, gauss2, performanceStd)

    % Compute the match quality
    first = sqrt ( 2*performanceStd^2 / ( 2*performanceStd^2 + gauss1.Variance + gauss2.Variance ) );
    second = exp ( - (gauss1.Mu - gauss2.Mu)^2/(2*(2*performanceStd^2 + gauss1.Variance + gauss2.Variance)) );
    matchQuality = first * second;
end