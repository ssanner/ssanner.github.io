function itemListNew = findBestTwoItems ( belief, sizeOfQuery, omega, queryHistory)
    % Find the best sizeOfQuery items for a query
    defaultDelete = 3;
    memorySize = 5;
    numItems = length( belief );
    varianceAdjustedExpectUtility = zeros( 1, numItems );
    for i = 1:numItems 
        varianceAdjustedExpectUtility(i) = belief{i}.Mu - omega*belief{i}.Sigma;
    end
    % Find the item with maximum utility
    pos = find ( varianceAdjustedExpectUtility == max (varianceAdjustedExpectUtility) );
    if length(pos) > 1
        idx = randperm ( length(pos) );
        itemList(1) = pos ( idx(1) );
    elseif length(pos) == 1
        itemList(1) = pos;
    else
        disp('Find Best Two Not Approximate')
    end
    
    % Find the item with the second maximum utility
    varianceAdjustedExpectUtility( itemList(1) ) = -inf;
    pos = find ( varianceAdjustedExpectUtility == max (varianceAdjustedExpectUtility) );
    if length(pos) > 1
        idx = randperm ( length(pos) );
        itemList(2) = pos ( idx(1) );
    else
        itemList(2) = pos;
    end
    noQuery = size( queryHistory, 1 );
        
    repeat = 0;
    if noQuery > memorySize
        for i = noQuery : -1 : noQuery - memorySize + 1
            if queryHistory(i, 1) == itemList(1) && queryHistory(i, 2) == itemList(2)
                repeat = 1;
            end
        end        
    end
    if ~repeat
        itemListNew = itemList;
    else
        if noQuery <= memorySize
            for i = noQuery: -1 : noQuery - defaultDelete + 1
                varianceAdjustedExpectUtility ( queryHistory(i, 1) ) = -inf;
                varianceAdjustedExpectUtility ( queryHistory(i, 2) ) = -inf;
            end
        else
            for i = noQuery : -1 : noQuery - memorySize + 1
                varianceAdjustedExpectUtility ( queryHistory(i, 1) ) = -inf;
                varianceAdjustedExpectUtility ( queryHistory(i, 2) ) = -inf;
            end
        end
        pos = find ( varianceAdjustedExpectUtility == max (varianceAdjustedExpectUtility) );
        if length(pos) > 1
            idx = randperm ( length(pos) );
            itemList(1) = pos ( idx(1) );
        else
            itemList(1) = pos;
        end
        % Find the item with the second maximum utility
        varianceAdjustedExpectUtility( itemList(1) ) = -inf;
        pos = find ( varianceAdjustedExpectUtility == max (varianceAdjustedExpectUtility) );
        if length(pos) > 1
            idx = randperm ( length(pos) );
            itemList(2) = pos ( idx(1) );
        else
            itemList(2) = pos;
        end
        itemListNew = itemList;   
    end     
end




