function [itemListBestTwo itemListBestAndLargest itemVOI] = depthLimitedSearch(beliefFeature, beliefProduct, productIndex, depth, ...
                                                                                    performanceStd, omega)

    % belief: current belief state on the user's utility function. 
    % productIndex: N (number of products) * D (dimension)
    % queryStretegyOption: 
    %		2	best two
    %		5	best & largest uncertainty
    %		4       VOI
    [numProducts numFeatures] = size(productIndex);
    breadth = nchoosek(numFeatures, 2);
    updatedBelief = cell(1, depth);
    allQueryList = combntns(1:numProducts, 2);
    beliefProductFeatureWise = cell(2, numFeatures);
    for idxDepth = 1:depth
        % compute the total number of nodes in the idxDepth-layer. 
        numNodeIdxDepth = breadth^idxDepth;
        updatedBelief{idxDepth} = cell(3, numNodeIdxDepth);
        for idxNode = 1:numNodeIdxDepth
            
            % Find from which belief state this node should be updated
            if depth == 1
                idxBaseBeliefFeature = beliefFeature;
                idxBaseBeliefProduct = beliefProduct;
            else
                if mod(idxNode, breadth) == 0
                    idxBaseBeliefIdxNode = idxNode/breadth;
                else
                    idxBaseBeliefIdxNode = floor( idxNode/breadth )+1;	
                end
                idxBaseBeliefFeature = updatedBelief{depth-1}{1, idxBaseBeliefIdxNode};
                idxBaseBeliefProduct = updatedBelief{depth-1}{2, idxBaseBeliefIdxNode};
            end
        
            % Find the query no. for this Node
            queryNo = mod(idxNode, breadth);
            if queryNo == 0
                queryNo = breadth;
            end
            itemList = allQueryList( queryNo, :);
            % Based on query No. and the belief state, update the beliefFeature and beliefProduct of this node. 
            for i = 1:2
                for idxFeature = 1:numFeatures
                    tempBeliefFeature = beliefFeature{idxBeliefFeature};
                    beliefProductFeatureWise{i, idxFeature} = tempBeliefFeature{1, idxFeature}{ productIndex( itemList(i), idxFeature) };
                end
            end           
            priorSkills = [beliefProductFeatureWise{1, :} beliefProductFeatureWise{2, :}];
            
            % Compute VOI as well
            tempPrevious = zeros(1, numProducts);
            for kk = 1:numProducts
                tempPrevious(kk) = idxBaseBeliefProduct{kk}.Mu - omega * idxBaseBeliefProduct{kk}.Sigma;
            end
            [junk currentMaxId] = max(tempPrevious);
            flag = 0;
            if idxBaseBeliefProduct{itemList(1)}.Mu > idxBaseBeliefProduct{itemList(2)}.Mu
                isDraw = 'N';                
                VOI = computeVOI( idxBaseBeliefProduct{itemList(1)}, idxBaseBeliefProduct{currentMaxId});
            elseif idxBaseBeliefProduct{itemList(1)}.Mu == idxBaseBeliefProduct{itemList(2)}.Mu
                isDraw = 'Y';
                if idxBaseBeliefProduct{itemList(1)}.Sigma >= idxBaseBeliefProduct{itemList(2)}.Sigma
                    VOI = computeVOI( idxBaseBeliefProduct{itemList(1)}, idxBaseBeliefProduct{currentMaxId});
                else
                    VOI = computeVOI( idxBaseBeliefProduct{itemList(2)}, idxBaseBeliefProduct{currentMaxId});
                end
            else
                isDraw = 'N';
                priorSkills = [beliefProductFeatureWise{2, :} beliefProductFeatureWise{1, :}];
                flag = 1;
                VOI = computeVOI( idxBaseBeliefProduct{itemList(2)}, idxBaseBeliefProduct{currentMaxId});
            end 
            
            
            [bP1, bP2, bF1, bF2] = NPlayerTrueSkillUpdateTeamDepthLimitedSearch (performanceStd, 1e-5*performanceStd, ...
                                                                                       1e-4, drawProb/100, priorSkills, isDraw);
            % Set beliefFeature, beliefProduct
            idxBaseBeliefFeature{ itemList(1) } = bF1;
            idxBaseBeliefFeature{ itemList(2) } = bF2;
            idxBaseBeliefProduct{ itemList(1) } = bP1;
            idxBaseBeliefProduct{ itemList(2) } = bP2;
            if flag 
                idxBaseBeliefFeature{ itemList(1) } = bF2;
                idxBaseBeliefFeature{ itemList(2) } = bF1;
                idxBaseBeliefProduct{ itemList(1) } = bP2;
                idxBaseBeliefProduct{ itemList(2) } = bP1;
            end            
            updatedBelief{idxDepth}{1, idxNode} = idxBaseBeliefFeature;
            updatedBelief{idxDepth}{2, idxNode} = idxBaseBeliefProduct;
            if idxDepth == 1
                updatedBelief{idxDepth}{3, idxNode} = VOI;
            else
                updatedBelief{idxDepth}{3, idxNode} = VOI + updatedBelief{idxDepth-1}{3, idxBaseBeliefIdxNode};
            end
        end     
    end    
    % Find itemList using different query strategy
    baseData = updatedBelief{Depth}{2, :};
    resultVOI = cell2mat( updatedBelief{Depth}{3, :} );
    numNodeFinalLayer = breadth^depth;
    productBeliefFinalDepth = zeros(1, numNodeFinalLayer);
    productBeliefUncertaintyFinalDepth = zeros(1, numNodeFinalLayer);
    for i = 1:breadth^depth 
        productBeliefUncertaintyFinalDepth(i) = baseData{i}.Sigma;
        productBeliefFinalDepth(i) = baseData{i}.Mu - omega * productBeliefUncertaintyFinalDepth(i);               
    end
    [junk bestID] = max(productBeliefFinalDepth);
    productBeliefFinalDepth(bestID) = -inf;
    [junk secondBestID] = max(productBeliefFinalDepth);
    % Best two
    itemListBestTwo = [bestID secondBestID];
    % Best and largest uncertainty
    [junk largestUncertaintyID] = max(productBeliefUncertaintyFinalDepth);
    if bestID == largestUncertaintyID
        productBeliefUncertaintyFinalDepth(largestUncertaintyID) = -inf;
        [junk largestUncertaintyID] = max(productBeliefUncertaintyFinalDepth);
    end
    itemListBestAndLargest = [bestID largestUncertaintyID];    
    % maximum VOI
    [ junk, queryID ] = max(resultVOI);
    for idxDepth = depth:-1:1
        if mod(queryID, breadth) == 0
            idxBaseBeliefIdxNode = idxNode/breadth;
        else
            idxBaseBeliefIdxNode = floor( idxNode/breadth )+1;	
        end
    end
    itemVOI = allQueryList( idxBaseBeliefIdxNode, :);
end