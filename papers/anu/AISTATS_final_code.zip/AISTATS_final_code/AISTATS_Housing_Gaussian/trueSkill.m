function [ belief, quality ]   = updateBelief ( belief, itemList, rank )

noPlayers = size( itemList );
if rank == 0
    isDraw    = 'Y';
elseif rank == -1
    % Make sure the winner item is at the beginning of the list.
    itemList(1) = temp;
    itemList(1) = itemList(2);
    itemList(2) = temp;
end

%drawProb  = input ('Draw probability (0 - 100): ');
drawProb = 5;

priorSkills = cell(1, noPlayers);
for i = 1:noPlayers
    priorSkills{i} = belief{ itemList(i) };
end

for i = 1:noPlayers-1
    draws(i) = isDraw;
end

[ posteriorSkills, logZ ] = NPlayerTrueSkillUpdate (0.5*priorSigma, 0.01*priorSigma, 1e-4, drawProb/100, priorSkills, draws);

for i = 1:noPlayers
   belief{ itemList(i) }  = posteriorSkills{i};
end
quality = exp (logZ) * 100.0;
end