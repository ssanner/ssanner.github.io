function [ belief, quality ]   = updateBeliefCol ( belief, queryHistory, iter, performanceStd )
 
    [totalQuery, junk] = size( queryHistory );
    noPlayers = junk - 1;
    
    for i = 1:iter
        itemList = queryHistory(i, 1:2);
        rank = queryHistory(i, 3);
        if rank == 0
            isDraw = 'Y';
        elseif rank == -1
            % Make sure the winner item is at the beginning of the list.
            isDraw = 'N';
            temp = itemList(1);
            itemList(1) = itemList(2);
            itemList(2) = temp;
        else
            isDraw = 'N';
        end

        % drawProb  = input ('Draw probability (0 - 100): ');
        drawProb = 5;

        priorSkills = cell(1, noPlayers);
        for k = 1:noPlayers
            priorSkills{k} = belief{ itemList(k) };
        end

        for k = 1:noPlayers-1
            draws(k) = isDraw;
        end

        [ posteriorSkills, logZ ] = NPlayerTrueSkillUpdate (performanceStd, 0.9*performanceStd, 1e-4, drawProb/100, priorSkills, draws);
        for k = 1:noPlayers
            belief{ itemList(k) }  = posteriorSkills{k};
        end
        quality = exp (logZ) * 100.0;
    end
end