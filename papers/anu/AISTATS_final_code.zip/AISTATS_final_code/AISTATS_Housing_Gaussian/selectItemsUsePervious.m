function [itemList, productBelief, idxUCP, idxUCP0]= selectItemsUsePervious ( belief, sizeOfQuery, option, performanceStd, omega, queryHistory, ...
                                                              productBelief, weightAssignment, d, productIndex, depth, drawProb, tailProbThreshold )

    % select a number of items based on the strategy for item picking and
    % current belief.
    % option:
    %       0: random pick sizeOfQuery
    %       1: pick two items as a query that maximize the draw probability
    %       2: pick the best two items as a query
    %       3: pick the best and the worst items as a query
    %       4: value of information, a query with the current maximum one
    %       and the one with maximum VOI
    numProduct = length(productBelief);
    switch option
        case 0
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 1
            itemList = findMaximumMatchQuality ( productBelief, sizeOfQuery, performanceStd );
        case 2
            itemList = findBestTwoItems ( productBelief, sizeOfQuery, omega, queryHistory );
        case 3
            itemList = findBestAndWorstItem ( productBelief, sizeOfQuery, omega );
        case 4      % Approximation of simiplied VOI
            itemList = findItemWithMaximumVoI ( productBelief, sizeOfQuery, omega );
        case 5
            itemList = findBestAndLargestUncertainty ( productBelief, sizeOfQuery, omega );
        case 6      % Informed VOI: use the updated best product to compute the Tom Ralf VOI
            [itemList idxUCP idxUCP0] = findItemWithMaximumVoICompleteTrue( belief, productBelief, sizeOfQuery, weightAssignment, d, performanceStd, omega, drawProb);
        case 7      % Uninformed VOI: use the updated best product to compute the Tom Ralf VOI
            [itemList idxUCP idxUCP0] = findItemWithMaximumVoICompleteTrue( belief, productBelief, sizeOfQuery, weightAssignment, d, performanceStd, omega, drawProb, 1);
        case 8      % Informed VOI: use the updated best product to compute the Tom Ralf VOI--resitrcted to the search with the current best one
            [itemList idxUCP idxUCP0] = findItemWithMaximumVoICompleteTrueRes( belief, productBelief, sizeOfQuery, weightAssignment, d, performanceStd, omega, drawProb);
        case 9      % Uninformed VOI: use the updated best product to compute the Tom Ralf VOI--restricted to the search with the current best one
            [itemList idxUCP idxUCP0] = findItemWithMaximumVoICompleteTrueRes( belief, productBelief, sizeOfQuery, weightAssignment, d, performanceStd, omega, drawProb, 1);
        case 20     % Two step look ahead
            itemList = depthLimitedSearchVOIPruningME(belief, productBelief, productIndex, depth, performanceStd, omega, drawProb, ...
                                                            tailProbThreshold, d, queryHistory);
        case 21     % Simplified VOI using approximate integral: quad
            itemList = findItemWithMaximumVoI ( productBelief, sizeOfQuery, omega, 1 );
        case 22      % Old Informed VOI
            itemList = findItemWithMaximumVoIComplete( belief, productBelief, sizeOfQuery, weightAssignment, d, performanceStd, omega, drawProb);
        case 23      % Old Uninformed VOI
            itemList = findItemWithMaximumVoIComplete( belief, productBelief, sizeOfQuery, weightAssignment, d, performanceStd, omega, drawProb, 1);
        case 24      % Old Informed VOI
            itemList = findItemWithMaximumVoICompleteRes( belief, productBelief, sizeOfQuery, weightAssignment, d, performanceStd, omega, drawProb);
        case 25      % Old Uninformed VOI
            itemList = findItemWithMaximumVoICompleteRes( belief, productBelief, sizeOfQuery, weightAssignment, d, performanceStd, omega, drawProb, 1);
        otherwise
            disp('Query Strategy Unknown!')
    end
    if exist('idxUCP', 'var') == 0
        idxUCP = 0;
    end
    if exist('idxUCP0', 'var') == 0
        idxUCP0 = 0;
    end
    
end
    

