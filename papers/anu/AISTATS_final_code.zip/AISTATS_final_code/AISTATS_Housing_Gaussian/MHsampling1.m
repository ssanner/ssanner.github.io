function samples = MHsampling1( dim, u_low, u_upper, gridNum, convexSet, numSamples, burnK, epsilon)

    % dim: the number of product
    % u_low: the minimum value of utilities over product space
    % u_high: the maximum value of the uitlity over product space
    % gridNum: the number of segments in each axis when constructing grid
    % convexSet: the convex set for which we would like to sample
    % numSamples: the number of samples we hope to sample
    % burnK: before which (includsive), the samples will be omitted in the outp samples set.
    % epsilon: model noise
    samples = [];
    % Initiationation of grid for constructing cubes
    hx  = (u_upper - u_low)/gridNum;
    pos   = u_low + ( 0:gridNum )*hx;
    % Randomly initialize x0
    for numRun = 1:50
        xSeries = zeros(numSamples, dim);
        uSeries = zeros(numSamples, dim);
        % Initialize to find a grid in convexSet
        flag = 1;
        while flag
            for i = 1:dim
                % For each dim, randomly pick the number of the grid 
                temp = randperm(gridNum);
                xSeries(1, i) = temp(1); % randint (1,1,[u_low 20]);
                uSeries(1, i) = ( pos( xSeries(1, i) ) + pos( xSeries(1, i) + 1 ))/2;
            end
            inOrOut = judgeInOrOut ( uSeries(1,:), convexSet, epsilon ); % Judge whether the initial point is in convexSet or not. return 1 if in, 0 otherwise.
            if inOrOut == 1
                flag = 0;
            end
        end
        disp('pass')
        for i = 2:numSamples
            coin = rand;
            if coin < 0.2
                xSeries(i, :) = xSeries(i-1, :);
                uSeries(i, :) = ( pos(xSeries(i, :))+ pos(xSeries(i, :) + 1) )/2;
            else
                whichDim = randperm(dim);
                coin2 = rand;
                if coin2 < 0.5
                    finalDim = -1;
                else
                    finalDim = 1;
                end
                xSeries(i, :) = xSeries(i-1, :);
                % Check whether grid index is legal
                temp = xSeries(i-1, whichDim(1) ) + finalDim;
                if temp > gridNum 
                    temp = gridNum;
                elseif temp < 1
                    temp = 1;
                end
                xSeries(i, whichDim(1) ) = temp;
                uSeries(i, :) = ( pos(xSeries(i, :))+ pos(xSeries(i, :) + 1) )/2;
            end
            inOrOut = judgeInOrOut ( uSeries(2,:), convexSet, epsilon );
            if ~inOrOut
                xSeries(i, :) = xSeries(i-1, :);
                uSeries(i, :) = ( pos(xSeries(i, :))+ pos(xSeries(i, :) + 1 ))/2;
            end       
        end  
        clear xSeries;
        uSeries( 1:burnK, : ) = [];
        % resample from uSeries, put operation here
        b = 2;
        numSamplesTemp = size(uSeries, 1);
        samples = [ samples; uSeries(1:b:numSamplesTemp, :) ];
    end
end