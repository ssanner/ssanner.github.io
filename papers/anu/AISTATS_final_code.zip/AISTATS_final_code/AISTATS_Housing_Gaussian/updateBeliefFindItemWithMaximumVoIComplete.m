function gain = updateBeliefFindItemWithMaximumVoIComplete ( belief, itemList, rank, performanceStd, productBelief, omega, drawProb )
    gain = zeros(2, 1);
    if rank == 0
        isDraw = 'Y';
    elseif rank == -1
        % Make sure the winner item is at the beginning of the list.
        isDraw = 'N';
        temp = itemList(1);
        itemList(1) = itemList(2);
        itemList(2) = temp;
    else
        isDraw = 'N';
    end
    priorSkills = [ belief{ itemList(1), :} belief{ itemList(2), :} ];
    numProduct = size(productBelief, 1);
    %[ posteriorSkills, logZ ] = NPlayerTrueSkillUpdate (performanceStd, 1e-5*performanceStd, 1e-4, drawProb/100, priorSkills, draws);
    
    if isDraw == 'Y'
        [beliefProduct1, beliefProduct2] = NPlayerTrueSkillUpdateTeamFindItemWithMaximumVoIComplete (performanceStd, 1e-5*performanceStd, 1e-4, ...
                                                                                        drawProb/100, priorSkills, isDraw);
        % Update product belief
        productBelief{ itemList(1) } = beliefProduct1;
        productBelief{ itemList(2) } = beliefProduct2;
        % Find the Id of the current best belief
        tempProductUtility = zeros( numProduct, 1);
        for i = 1:numProduct
            tempProductUtility(i) = productBelief{i}.Mu-omega*productBelief{i}.Sigma;
        end
        [junk currentBestId] = max ( tempProductUtility );
        % Compute gain
        gain(1) = computeVOI(beliefProduct1, productBelief{currentBestId});
        gain(2) = computeVOI(beliefProduct2, productBelief{currentBestId});
    else
        [beliefProduct1, beliefProduct2] = NPlayerTrueSkillUpdateTeamFindItemWithMaximumVoIComplete (performanceStd, 1e-5*performanceStd, 1e-4, ...
                                                                                        drawProb/100, priorSkills, isDraw);
        
        productBelief{ itemList(1) } = beliefProduct1;
        productBelief{ itemList(2) } = beliefProduct2;                                                                            
        tempProductUtility = zeros( numProduct, 1);
        for i = 1:numProduct
            tempProductUtility(i) = productBelief{i}.Mu-omega*productBelief{i}.Sigma;
        end
        [junk currentBestId] = max ( tempProductUtility );

        gain(1) = computeVOI(beliefProduct1, productBelief{currentBestId});
        gain(2) = computeVOI(beliefProduct2, productBelief{currentBestId});
        if rank == -1
            temp = gain(1);
            gain(1) = gain(2);
            gain(2) = temp;
        end
    end
end