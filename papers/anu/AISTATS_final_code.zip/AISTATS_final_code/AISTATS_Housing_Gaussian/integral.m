uX = 2;
uY = 1;
sigmaX = 3;
sigmaY = 2;
syms x y 
double (int(int( (y-x)* ( 1/(sqrt(2*pi)*sigmaX)*exp(-(x-uX)^2/(2*sigmaX^2) )) * ( 1/(sqrt(2*pi)*sigmaY)*exp(-(y-uY)^2/(2*sigmaY^2) ) ), x, -inf, y), y, -inf, inf) )

syms x y uY sigmaY
int (y* 1/(sqrt(2*pi)*sigmaY)*exp(-(y-uY)^2/(2*sigmaY^2)), x, inf)