function [estimatedMax maximumUtilityProductID productBeliefHalfUpdated]= findMaximumUtility ( belief, omega, performanceStd, ...
                                                                                  productBeliefHalfUpdated, itemList  )
    % find the item that has the maximum variance-adjusted expected utility
    
    % find out the utility of the product from its features.
    productBeliefHalfUpdated = UpdateProductBelief(belief, itemList, performanceStd, productBeliefHalfUpdated);    
    % after getting the utility for an individual product, let's find out
    % the product with maximum performance
    
    numProduct = length( productBeliefHalfUpdated );
    temp = zeros( 1, numProduct );
    for i = 1 : numProduct
         temp(i) = productBeliefHalfUpdated{i}.Mu - omega * productBeliefHalfUpdated{i}.Sigma;
    end
    [estimatedMax maximumUtilityProductID] = max(temp);    
end