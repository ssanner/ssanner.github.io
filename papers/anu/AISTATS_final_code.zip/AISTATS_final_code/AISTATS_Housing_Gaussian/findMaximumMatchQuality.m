function itemList = findMaximumMatchQuality ( belief, sizeOfQuery, performanceStd )

    % find the sizeOfQuery items that comprise a query, which has maximum draw
    % probability

    % hard-coded sizeOfQuery = 2
    numItem = length(belief);
    numComb = nchoosek( numItem, sizeOfQuery );
    allComb = combntns( 1:numItem, sizeOfQuery );
    matchQuality = zeros( 1, numComb );
    for i = 1:numComb
        item1 = allComb(i,1);
        item2 = allComb(i,2);
        matchQuality(i) = evaluateMatchQuality(belief{item1}, belief{item2}, performanceStd);
    end
    
    [junk posMaxMatchQuality]= max ( matchQuality ) ;
    len = length( posMaxMatchQuality );
    if  len > 1
        idx = randperm ( len ); 
        itemList = allComb( posMaxMatchQuality ( idx(1) ), :);
    else
        itemList = allComb( posMaxMatchQuality, :);
    end
   
end