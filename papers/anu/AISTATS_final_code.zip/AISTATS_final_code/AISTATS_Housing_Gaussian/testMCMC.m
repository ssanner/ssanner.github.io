totalSample = 100000;
burn = 10000;
lower = 0;
upper = 10;
samples = MHsampling( 2, 0, 10, 100, [1 2 -1], totalSample, burn, 1);
figure;
plot(samples(1:burn-1, 1), samples(1:burn-1, 2), 'b+');
hold on;
plot(samples(burn:totalSample, 1), samples(burn:totalSample, 2), 'r.');
hold on;
% x = 0:0.002:10;
% y = x - 1;
% plot(x,y,'c')
axis([0 10 0 10]);
xlabel('u1')
ylabel('u2')
title('u2 > u1 - 1')
mean(samples(burn:end,:))