function itemList = findItemWithMaximumVoI ( belief, sizeOfQuery, omega, flag )

    %  Find the item with maximum VOI corresponding with the current best
    %  item
    %  flag: 0 approximation
    %        1 accurate by integral
    if nargin < 4
        flag = 0;
    end
    
    itemList = zeros(1,2);
    numItems = length( belief );
    
    % Find the best
    varianceAdjustedExpectUtility = zeros( 1, numItems );
    for i = 1:numItems 
        varianceAdjustedExpectUtility(i) = belief{i}.Mu - omega*belief{i}.Sigma;
    end
    
    maxLocation = find ( varianceAdjustedExpectUtility == max ( varianceAdjustedExpectUtility ) );
    if length( maxLocation ) > 1
        idx = randperm( length( maxLocation ) );
        itemList(1) = maxLocation ( idx(1) );
    else
        itemList(1) = maxLocation;
    end
    
    
    VOI = zeros( 1, numItems );
    if flag == 0
        % Approximated simplied VOI
        for i = 1:numItems
            VOI(i) = computeVOI( belief{i}, belief{ itemList(1) });
        end
        VOI( itemList(1) ) = -inf;
        pos = find ( VOI == max( VOI ) );
        if length(pos) > 1
            idx = randperm( length(pos) );
            itemList(2) = pos( idx(1) );
        else
            itemList(2) = pos;
        end
    else
        % Accurate simplied VOI
        % Find item with maximum VoI
        for i = 1:numItems
            VOI(i) = quad( @(x) computeVOIAccurate(x, belief{i}), belief{ itemList(1) }.Mu-5*belief{ itemList(1) }.Sigma, ...
                                                                    belief{ itemList(1) }.Mu+5*belief{ itemList(1) }.Sigma);
        end
        VOI( itemList(1) ) = -inf;
        pos = find ( VOI == max( VOI ) );
        if length(pos) > 1
            idx = randperm( length(pos) );
            itemList(2) = pos( idx(1) );
        else
            itemList(2) = pos;
        end
    end
end 