function gain      = computeGain (beliefItem1Win, bestProductBelief, performanceStd, itemList, productBeliefHalfUpdated)
    % 
    productBeliefHalfUpdated = UpdateProductBelief(beliefItem1Win, itemList, performanceStd, productBeliefHalfUpdated);  
    beliefProduct1 = productBeliefHalfUpdated{itemList(1)};
    beliefProduct2 = productBeliefHalfUpdated{itemList(2)};
    gain = zeros(2, 1);
    gain(1) = computeVOI(beliefProduct1, bestProductBelief);
    gain(2) = computeVOI(beliefProduct2, bestProductBelief);
end