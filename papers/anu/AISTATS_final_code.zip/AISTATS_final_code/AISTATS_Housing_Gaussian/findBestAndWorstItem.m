function itemList = findBestAndWorstItem ( belief, sizeOfQuery, omega)
    % Find the best and worst query
    numItems = length( belief );
    varianceAdjustedExpectUtility = zeros( 1, numItems );
    for i = 1:numItems 
        varianceAdjustedExpectUtility(i) = belief{i}.Mu - omega*belief{i}.Sigma;
    end
    
    if sizeOfQuery ~= 2
        error('Size of Query should be 2 for the worst Vs. best query');
    end
    
    itemList = zeros(1,2);
    minLocation = find ( varianceAdjustedExpectUtility == min ( varianceAdjustedExpectUtility ) );
    maxLocation = find ( varianceAdjustedExpectUtility == max ( varianceAdjustedExpectUtility ) );
    if length( minLocation ) > 1
        idx = randperm ( length(minLocation) );
        itemList(1) = minLocation( idx(1) );
    else
        itemList(1) = minLocation;
    end
    
    if length( maxLocation ) > 1
        idx = randperm ( length(maxLocation) );
        itemList(2) = maxLocation( idx(1) );
    else
        itemList(2) = maxLocation;
    end
    
    
end