function itemList = findItemWithMaximumVoIComplete( belief, productBelief, sizeOfQuery, weightAssignment, d, performanceStd, omega, drawProb, flag)
    % Find the query that maximize value of information
    % Input: productBelief -- belief state on the utility of each product
    %        weightAssignment --
    if nargin < 9
        flag = 0;
    end    
    numProduct = length( productBelief );
    numQueries = nchoosek( numProduct, sizeOfQuery );
    allQueries = combntns( 1:numProduct, 2);
    allQueries = allQueries (randperm(numQueries), :);
    gain       = zeros( numQueries, 1 );
    tempProductUtility = zeros( numProduct, 1);
    for i = 1:numProduct
        tempProductUtility(i) = productBelief{i}.Mu-omega*productBelief{i}.Sigma;
    end
    [junk currentBestId] = max ( tempProductUtility );
    if flag == 0
        for i = 1:numQueries
            item1 = allQueries( i, 1 );
            item2 = allQueries( i, 2 );
            [drawProb, winProb, loseProb] = computeDrawWinLoseProb( productBelief{item1}, productBelief{item2}, d );
            % item1 is preferred 
            rank = 1;
            gain1 = updateBeliefFindItemWithMaximumVoICompleteOld ( belief, [item1 item2], rank, performanceStd, productBelief{currentBestId});      
            % item2 is preferred 
            rank = -1;
            gain2 = updateBeliefFindItemWithMaximumVoICompleteOld ( belief, [item1 item2], rank, performanceStd, productBelief{currentBestId});
            % item1 and item2 are both preferred
            rank = 0;
            gain3 = updateBeliefFindItemWithMaximumVoICompleteOld ( belief, [item1 item2], rank, performanceStd, productBelief{currentBestId});
            tempGain = [gain1 gain2 gain3];
            gain(i) = winProb * weightAssignment(1, :)*tempGain(:, 1) + loseProb * weightAssignment(2, :)*tempGain(:, 2) + ...
                      drawProb * weightAssignment(3, :)*tempGain(:, 3);
        end
        [ junk, bestQueryId ] = max(gain);
        itemList = allQueries (bestQueryId, :);
    else
        %------------------------------------------------------------------
        % Uniformed search: winProb = 0.5, loseProb = 0.5
        for i = 1:numQueries
            item1 = allQueries( i, 1 );
            item2 = allQueries( i, 2 );
            winProb = 0.45;
            loseProb = 0.45;
            drawProbInternal = 0.1;
            % item1 is preferred 
            rank = 1;
            gain1 = updateBeliefFindItemWithMaximumVoICompleteOld ( belief, [item1 item2], rank, performanceStd, productBelief{currentBestId});      
            % item2 is preferred 
            rank = -1;
            gain2 = updateBeliefFindItemWithMaximumVoICompleteOld ( belief, [item1 item2], rank, performanceStd, productBelief{currentBestId});
            % draw 
            rank = 0;
            gain3 = updateBeliefFindItemWithMaximumVoICompleteOld ( belief, [item1 item2], rank, performanceStd, productBelief{currentBestId});
            tempGain = [gain1 gain2 gain3];
            gain(i) = winProb * weightAssignment(1, :)*tempGain(:, 1) + loseProb * weightAssignment(2, :)*tempGain(:, 2) + ...
                    drawProbInternal * weightAssignment(3, :)*tempGain(:, 3);
        end
        [ junk, bestQueryId ] = max(gain);
        itemList = allQueries (bestQueryId, :);
    end
end
