        i = 1;
        numProductAll = 20;
        trueBelief = saveUserUtlity{1, i};
        trueBeliefProduct = zeros(numProductAll, 1);
        for idxProduct = 1:numProductAll
            trueBeliefProduct(idxProduct) = 0;
            for idxFeature = 1:numFeatures
                trueBeliefProduct(idxProduct) = trueBeliefProduct(idxProduct) + trueBelief{1, idxFeature} (productIndex(idxProduct, idxFeature));
            end
        end
        sM = [];
        numIter = 25;
        for i = 1:150
            [maxItemId maxItemIdLoss] = tournamentSort(trueBeliefProduct, numIter);
            sM = [sM; maxItemIdLoss'];
        end
        
        a = 1:25;
        b = [a; a; a; a; a; a; a; a];
        m = [saveResult{1, 1}; mean(sM); saveResult_Sequential{1, 1}];
        e = [saveResult{1, 2}; std(sM)/sqrt(150-1); saveResult_Sequential{1, 2}];
        figure;
        errorbar1 = errorbar(b', m'/max(trueBeliefProduct), 1*e'/max(trueBeliefProduct));
        title('Gaussian with stochastic covariance, 20 items, True Maximum Utility - True Current Utiilty')
        legend('Random Two', 'Best Two', 'Best & Largest Uncertainty', 'VOI', 'Informed VOI', 'Unformed VOI', 'Tournament Sort', 'Sequential');
        xlabel('Number of queries');
        ylabel('Expected loss')
        set(errorbar1(8),'Marker','^','DisplayName','Sequential');
        set(errorbar1(7),'Marker','d','DisplayName','Tournament Sort');
        set(errorbar1(6),'Marker','*','DisplayName','Uninformed VOI');
        set(errorbar1(5),'Marker','+','DisplayName','Informed VOI');
        set(errorbar1(4),'Marker','.','DisplayName','VOI');
        set(errorbar1(3),'Marker','x','DisplayName','Best & Largest Uncertainty');
        set(errorbar1(2),'Marker','square','DisplayName','Best Two');
        set(errorbar1(1),'Marker','o','DisplayName','Random Two');
 