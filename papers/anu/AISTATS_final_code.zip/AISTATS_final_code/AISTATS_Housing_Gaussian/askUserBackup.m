function rank = askUser( trueUtility, itemList, queryHistory )

    % askUser: ask the user to rank a number of items in itemList based on her
    %           utility function.

    % result:
    %       1: tureUtility( itemList(1) ) > tureUtility( itemList(2) );
    %       0: tureUtility( itemList(1) ) = tureUtility( itemList(2) );
    %      -1: tureUtility( itemList(1) ) < tureUtility( itemList(2) );

    label = [1 0 -1];

    % no noisy in the user's reponse
    dist = trueUtility( itemList(1) ) - trueUtility( itemList(2) );
    if dist > 0
        resIdx = 1;
    elseif dist == 0
        resIdx = 2;
    else
        resIdx = 3;
    end
    rank = label (resIdx);
    
    if length( find( queryHistory == itemList(1) ) ) >=1 || length( find( queryHistory == itemList(2) ) ) >= 1
        rank = label (resIdx);
    else
        disp('noise');
        % no noisy for the best item according to the user's true utility
        %[junk pos] = max( trueUtility );
        % the user states her preference with noise at level noisyLevel
        % noisyLevel = normpdf( dist, 0, 0.8);
        % adapt the current noise model to Bradley-Terry model 
        noisyLevel = 1 / ( 1 + exp( - abs(dist)  ) );
        if noisyLevel ~= 0
            accuracy = 1 - noisyLevel;
            randNum = rand(1);
            if 0 < randNum && randNum < accuracy
                rank = label(resIdx);
            else
                pos = find( label ~= rank );
                randCoin = rand(1);
                if randCoin > 0.5
                    rank = label ( pos(1) );
                else
                rank = label ( pos(2) );
                end
            end    
        end
    end
end

