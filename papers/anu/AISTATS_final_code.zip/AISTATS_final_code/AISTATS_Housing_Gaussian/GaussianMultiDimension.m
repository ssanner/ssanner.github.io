classdef GaussianMultiDimension
    %GAUSSIAN: A Gaussian Distribution based on float numbers in
    %exponential parameterisation
    
    properties
        PrecisionMean;                       % Precision times the mean of the Gaussian
        Precision;                           % Precision of the Gaussian
        Mu;                                  % Mean of the Gaussian: Mu = PrecisionMean / Precision;
        Mean;                                % Mean of the Gaussian: Mean = Mu;
        Covariance;                          % Variance of the Gaussian: Variance = 1.0 / Precision;
    end
    
    methods
        function obj = Gaussian(mu, covariance)                % Create a Gaussian in (mean, standard-deviation) coordinates
            if nargin > 0 
                obj.PrecisionMean = inv(covariance)*mu; %#ok<MINV>
                obj.Precision     = inv(covariance);
                obj.Mu = mu;                             % Mean of the Gaussian: Mu = PrecisionMean / Precision;
                obj.Mean = mu;                           % Mean of the Gaussian: Mean = Mu;
                obj.Covariance = covariance;             % Variance of the Gaussian: Variance = 1.0 / Precision;
            end
        end        
        function obj = mtimes(obj1, obj2)                % Multiplies two Gaussians: Overloading operator (*) 
            precisionMean = obj1.PrecisionMean + obj2.PrecisionMean;
            precision     = obj1.Precision     + obj2.Precision;
            covariance    = inv(precision);                 % Variance of the Gaussian
            mu            = precision * precisionMean  ; % Mean of the Gaussian
            obj           = GaussianMultiDimension(mu, covariance);
        end        
        function obj = mrdivide(obj1, obj2)               % Divide two Gaussians: Overloading operator (/)
            precisionMean = obj1.PrecisionMean - obj2.PrecisionMean;
            precision = obj1.Precision - obj2.Precision;
            if det(precision) < 0 
                disp('Warning: Negative Variance by Dividing Two Gaussian!');
            end
            covariance = inv ( precision);                % May cause Precision < 0
            mu = precision * precisionMean ;   % Mean of the Gaussian
            obj = GaussianMultiDimension(mu, covariance);
        end 
    end    
end

