function [maxItemId maxItemIdLoss] = tournamentSort(userUtility, maxIter)
    % Use Tournament Sort to Find out the Expected loss at each step
    numProduct = length( userUtility );
    roundTotal = round( log2( numProduct ) )+1;
    init = randperm( numProduct );
    queryHistory = [];
    maxItemId = [];
    iter = length(maxItemId);
    while iter <= maxIter 
        for roundIdx = 1:roundTotal
            if roundIdx == 1 
                [winItem queryHistory maxItemId] = findWinItemFirst(numProduct, userUtility, queryHistory, init, maxItemId);
            else
                [winItem queryHistory maxItemId] = findWinItem(winItem, userUtility, queryHistory, maxItemId);
            end
        end
        iter = length(maxItemId);
    end
    if length(maxItemId) > maxIter
        maxItemId( maxIter+1:end ) = [];
    end
    maxItemIdLoss = max(userUtility) - userUtility(maxItemId);
end