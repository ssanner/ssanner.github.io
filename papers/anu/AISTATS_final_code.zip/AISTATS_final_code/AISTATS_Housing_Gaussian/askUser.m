function rank = askUser( trueUtility, itemList )

    % askUser: ask the user to rank a number of items in itemList based on her
    %           utility function.

    % result:
    %       1: tureUtility( itemList(1) ) > tureUtility( itemList(2) );
    %       0: tureUtility( itemList(1) ) = tureUtility( itemList(2) );
    %      -1: tureUtility( itemList(1) ) < tureUtility( itemList(2) );

%     label = [1 0 -1];
% 
%     % no noisy in the user's reponse
     dist = trueUtility( itemList(1) ) - trueUtility( itemList(2) );
%     if dist > 0
%         resIdx = 1;
%     elseif dist == 0
%         resIdx = 2;
%     else
%         resIdx = 3;
%     end
%     rank = label (resIdx);
%     
    noisyLevel = exp(-abs(dist));
    winProb = exp(dist ) / ( 1+exp(dist) );
    loseProb = exp(-dist ) / ( 1+exp(-dist) );
    interval = [noisyLevel noisyLevel+winProb noisyLevel+winProb+loseProb];
    
    randNum = interval(3) * rand(1,1);
    
    if randNum < interval(1)
        rank = 0;
    elseif randNum > interval(1) && randNum < interval(2)
        rank = 1;
    else
        rank = -1;
    end
end

