% [ tree treeName ] = xml_read('database_pcdataset.xml');
% numProducts = size( tree.data, 2 );
% numFeatures = size( tree.data(1).attribute, 2 );
% productDescription = cell( numProducts, numFeatures );
% featureName = cell(1, numFeatures);
% 
% for idxFeature = 1:numFeatures
%     featureName{ idxFeature } = tree.data(1).attribute(idxFeature).ATTRIBUTE.name;
% end
% 
% for idxProduct = 1:numProducts 
%     for idxFeature = 1:numFeatures 
%         productDescription { idxProduct, idxFeature } = tree.data(idxProduct).attribute(idxFeature).ATTRIBUTE.value;        
%     end
% end
% 

load houseMatlab;
[ numProducts, numFeatures ] = size(housing);
productDescription = housing;

attributeSummary = cell( numFeatures, 1 );
for idxFeature = [4 9]
    attributeSummary{ idxFeature } = unique( [productDescription(:, idxFeature)] );
end

interval = 10;
for idxFeature = [1 2 3 5 6 7 8 10 11 12 13 14]
    lower = min( productDescription(:, idxFeature) );
    upper = max( productDescription(:, idxFeature) );
    attributeSummary{idxFeature} = lower - (upper-lower)*1/interval : (upper-lower)/interval : upper + (upper-lower)*1/interval;    
end

productIndex = zeros(numProducts, numFeatures);
for idxProduct = 1:numProducts
    for idxFeature = 1:numFeatures
        value = productDescription(idxProduct, idxFeature);
        switch idxFeature
            case {4, 9}
                productIndex(idxProduct, idxFeature) = find( value == attributeSummary{idxFeature} ); 
            case {1, 2, 3, 5, 6, 7, 8, 10, 11, 12, 13, 14}
                temp = value - attributeSummary{idxFeature};
                pos = find(temp <= 0);
                productIndex(idxProduct, idxFeature) = pos(1) - 1;
            otherwise
                disp('wrong attribute no.!')
        end
    end     
end

    