numProduct = 200;
sizeOfQuery = 2;
belief     = cell( 1, numProduct );
noisyLevel = 0.05;
performanceStd = 0.5;
disp('option 0: Random pick two'); disp('option 1: Maximum matching quality'); disp('option 2: Best two items');disp('option 3: Best and worst items');
disp('option 4: VOI');
option = input('Query strategy: ');
omega = 3;   % parameter for variance-adjusted expect utility: \mu - \omega * sigma
for i = 1: numProduct
    belief{i} = Gaussian( 25, 25/3 );
end
load trueBelief_uniform_as_a_base_for_OtherStratagies.mat;
beliefOption = 0;
load trueBelief_diag;
load trueBelief_stochastic;
load trueBelief_uniform;
trueBelief_uniform = 1 + 99 * rand(1,numProduct);
if beliefOption == 0
    trueBelief = trueBelief_uniform;
elseif beliefOption == 1
    trueBelief = trueBelief_diag;
elseif beliefOption == 2
    trueBelief = trueBelief_stochastic;
end
maxIter                 = 500;
maximumUtilityProductID = zeros( 1, maxIter );
fid = fopen('log.txt','wt');
for iter=1:maxIter
    % Select sizeOfQuery items for a query
    iter
    itemList                = selectItems ( belief, sizeOfQuery, option, performanceStd, omega )
    before1                 = belief{itemList(1)};
    before2                 = belief{itemList(2)};
    rank                    = askUser ( trueBelief, itemList, noisyLevel );
    [belief quality]        = updateBelief ( belief, itemList, rank, performanceStd );
    maximumUtilityProductID = findMaximumUtility ( belief, omega );
    fprintf( fid,'%d  VS.  %d %d\t%f -> %f \t %f -> %f \t %f -> %f \t %f -> %f \n',...
              itemList(1), itemList(2), rank, before1.Mu, belief{itemList(1)}.Mu, before2.Mu, belief{itemList(2)}.Mu, ...
              before1.Sigma, belief{itemList(1)}.Sigma, before2.Sigma, belief{itemList(2)}.Sigma ) ;
end
fclose(fid);
% Compute expected loss and standard error
% [expectedLoss standardError] = computeExpectedLossStandardError( trueBelief, maxItemId );


