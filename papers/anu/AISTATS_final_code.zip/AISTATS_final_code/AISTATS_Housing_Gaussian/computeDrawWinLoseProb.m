function [drawProb winProb loseProb] = computeDrawWinLoseProb( player1Skill, player2Skill, d )

    % Compute the Draw, win, and lose prob referring to the first item,
    % item1, given p
    Mu = player1Skill.Mu - player2Skill.Mu;
    Variance = player1Skill.Variance + player2Skill.Variance;
    Sigma = sqrt( Variance );
    drawValue  = 0.05 * d;
    winProb = 1 - normcdf(Mu + drawValue, Mu, Sigma);
    loseProb = winProb;
    drawProb = 1 - winProb - loseProb;
end
