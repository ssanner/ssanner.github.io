function itemVOI = depthLimitedSearchVOIPruningME(beliefFeature, beliefProduct, productIndex, depth, ...
                                                  performanceStd, omega, drawProb, tailProbThreshold, d, queryHistory)

    % belief: current belief state on the user's utility function. 
    % productIndex: N (number of products) * D (dimension)
    % queryStretegyOption: 
    %		2	best two
    %		5	best & largest uncertainty
    %		4       VOI
    sizeOfQuery = 2;
    [numProducts numFeatures] = size(productIndex);
    breadth = nchoosek(numProducts, 2);
    queryResultNo = 3;
    updatedBelief = cell(1, depth);
    allQueryList = combntns(1:numProducts, 2);
    % random permuate the query
    randpermIdx = randperm( size(allQueryList, 1) );
    allQueryList(1:size(allQueryList, 1), :) = allQueryList(randpermIdx, :); 
    for idxDepth = 1:depth
        % compute the total number of nodes in the idxDepth-layer. 
        numNodeIdxDepth = (breadth^idxDepth) * queryResultNo^(idxDepth-1);
        updatedBelief{idxDepth} = cell(6, numNodeIdxDepth);  % 1, beliefFeature for Win {1, 1}, beliefProduct for Win {1, 2}; 
                                                             % 2, beliefFeature for Draw {2, 1}, beliefProduct for Draw {2, 2};
                                                             % 3, beliefFeature for Lose {3, 1}, beliefProduct for Lose {3, 2};
                                                             % 4, VOI; 
                                                             % 5, Pruning or not:1 keep and 0 prune
                                                             % 6, winP, drawP loseP, 
        for idxNode = 1:numNodeIdxDepth
            % Find from which belief state this node should be updated
            if idxDepth == 1
                idxBaseBeliefFeature = beliefFeature;
                idxBaseBeliefProduct = beliefProduct;            
            else
                if mod(idxNode, (breadth*queryResultNo) ) == 0
                    idxBaseBeliefIdxNode = idxNode/(breadth*queryResultNo);
                else
                    idxBaseBeliefIdxNode = floor( idxNode/(breadth*queryResultNo) )+1;	
                end
                if updatedBelief{idxDepth-1}{5, idxBaseBeliefIdxNode} == 0
                    indicatorPruning = 0;
                    updatedBelief{idxDepth}{1, idxNode} = [];
                    updatedBelief{idxDepth}{2, idxNode} = [];
                    updatedBelief{idxDepth}{3, idxNode} = [];
                    updatedBelief{idxDepth}{4, idxNode} = 0;
                    updatedBelief{idxDepth}{5, idxNode} = indicatorPruning;
                    updatedBelief{idxDepth}{6, idxNode} = [];
                    continue;
                else
                    if mod(idxNode, queryResultNo) == 0
                        idxQueryResult = queryResultNo;
                    else
                        idxQueryResult = mod(idxNode, queryResultNo);
                    end
                    idxBaseBeliefFeature = updatedBelief{idxDepth-1}{idxQueryResult, idxBaseBeliefIdxNode}{1};
                    idxBaseBeliefProduct = updatedBelief{idxDepth-1}{idxQueryResult, idxBaseBeliefIdxNode}{2};
                end                
            end
            % Find the query no. for this Node
            queryNo = mod(idxNode, breadth);
            if queryNo == 0
                queryNo = breadth;
            end
            itemList = allQueryList( queryNo, :);
            %Compute VOI as well
            tempPrevious = zeros(1, numProducts);
            for kk = 1:numProducts
                tempPrevious(kk) = idxBaseBeliefProduct{kk}.Mu - omega * idxBaseBeliefProduct{kk}.Sigma;
            end
            %tempPrevious = idxBaseBeliefProduct{:}.Mu - omega * idxBaseBeliefProduct{kk}.Sigma;
            [junk currentMaxId] = max(tempPrevious);
            % prune if the current itemList does not have the current best
            % one
            if length ( find ( itemList == currentMaxId ) ) == 0
                indicatorPruning = 0;
                updatedBelief{idxDepth}{1, idxNode} = [];
                updatedBelief{idxDepth}{2, idxNode} = [];
                updatedBelief{idxDepth}{3, idxNode} = [];
                if idxDepth == 1
                    updatedBelief{idxDepth}{4, idxNode} = zeros(1, 4);
                    updatedBelief{idxDepth}{6, idxNode} = zeros(1, 3);
                else
                    updatedBelief{idxDepth}{4, idxNode} = 0;
                    updatedBelief{idxDepth}{6, idxNode} = [];
                end
                updatedBelief{idxDepth}{5, idxNode} = indicatorPruning;
                continue;
            end
            if itemList(1) == currentMaxId
                tailProb = 1 - normcdf(idxBaseBeliefProduct{currentMaxId}.Mu, idxBaseBeliefProduct{itemList(2)}.Mu, ...
                                                       idxBaseBeliefProduct{itemList(2)}.Sigma );
            else
                tailProb = 1 - normcdf(idxBaseBeliefProduct{currentMaxId}.Mu, idxBaseBeliefProduct{itemList(1)}.Mu, ...
                                                       idxBaseBeliefProduct{itemList(1)}.Sigma );
            end
            if tailProb < tailProbThreshold
                indicatorPruning = 0;
                updatedBelief{idxDepth}{1, idxNode} = [];
                updatedBelief{idxDepth}{2, idxNode} = [];
                updatedBelief{idxDepth}{3, idxNode} = [];
                updatedBelief{idxDepth}{4, idxNode} = [];
                if idxDepth == 1
                    updatedBelief{idxDepth}{4, idxNode} = zeros(1, 4);
                    updatedBelief{idxDepth}{6, idxNode} = zeros(1, 3);
                else
                    updatedBelief{idxDepth}{4, idxNode} = 0;
                    updatedBelief{idxDepth}{6, idxNode} = [];
                end
                updatedBelief{idxDepth}{5, idxNode} = indicatorPruning;                
                continue;                
            end
            % Item1 wins Item2
            priorSkills = [idxBaseBeliefFeature{itemList(1), :} idxBaseBeliefFeature{itemList(2), :}];
            [bP1, bP2, bF1, bF2] = NPlayerTrueSkillUpdateTeamDepthLimitedSearch (performanceStd, 1e-5*performanceStd, ...
                                                                                       1e-4, drawProb/100, priorSkills, 'N');
            idxBaseBeliefFeature( itemList(1), : ) = bF1;
            idxBaseBeliefFeature( itemList(2), : ) = bF2;
            idxBaseBeliefProduct{ itemList(1) } = bP1;
            idxBaseBeliefProduct{ itemList(2) } = bP2;
            updatedBelief{idxDepth}{1, idxNode}{1} = idxBaseBeliefFeature;
            updatedBelief{idxDepth}{1, idxNode}{2} = idxBaseBeliefProduct;
            
            % Item1 draws Item2
            [bP1, bP2, bF1, bF2] = NPlayerTrueSkillUpdateTeamDepthLimitedSearch (performanceStd, 1e-5*performanceStd, ...
                                                                                       1e-4, drawProb/100, priorSkills, 'Y');
            idxBaseBeliefFeature( itemList(1), : ) = bF1;
            idxBaseBeliefFeature( itemList(2), : ) = bF2;
            idxBaseBeliefProduct{ itemList(1) } = bP1;
            idxBaseBeliefProduct{ itemList(2) } = bP2;
            updatedBelief{idxDepth}{2, idxNode}{1} = idxBaseBeliefFeature;
            updatedBelief{idxDepth}{2, idxNode}{2} = idxBaseBeliefProduct;
            
            % Item2 wins Items1
            priorSkills = [idxBaseBeliefFeature{itemList(2), :} idxBaseBeliefFeature{itemList(1), :}];
            [bP1, bP2, bF1, bF2] = NPlayerTrueSkillUpdateTeamDepthLimitedSearch (performanceStd, 1e-5*performanceStd, ...
                                                                                       1e-4, drawProb/100, priorSkills, 'N');
            idxBaseBeliefFeature( itemList(1), : ) = bF2;
            idxBaseBeliefFeature( itemList(2), : ) = bF1;
            idxBaseBeliefProduct{ itemList(1) } = bP2;
            idxBaseBeliefProduct{ itemList(2) } = bP1;
            updatedBelief{idxDepth}{3, idxNode}{1} = idxBaseBeliefFeature;
            updatedBelief{idxDepth}{3, idxNode}{2} = idxBaseBeliefProduct;
            
            if idxDepth == 1
                updatedBelief{idxDepth}{4, idxNode} = zeros(1, 4);
            else
                [drawP winP loseP] = computeDrawWinLoseProb( idxBaseBeliefProduct{itemList(1)}, idxBaseBeliefProduct{itemList(2)}, d );
                % Find the best productId for win node giventhe current node
                tempPrevious = zeros(1, numProducts);
                for kk = 1:numProducts
                    tempPrevious(kk) = idxBaseBeliefProduct{kk}.Mu - omega * idxBaseBeliefProduct{kk}.Sigma;
                end
                %tempPrevious = idxBaseBeliefProduct{:}.Mu - omega * idxBaseBeliefProduct{kk}.Sigma;
                [junk currentMaxId] = max(tempPrevious);
                if itemList(1) == currentMaxId
                    VOIWin = computeVOI( idxBaseBeliefProduct{itemList(2)}, idxBaseBeliefProduct{currentMaxId});
                else
                    VOIWin = computeVOI( idxBaseBeliefProduct{itemList(1)}, idxBaseBeliefProduct{currentMaxId});
                end
                
                % Find the best productId for lose node giventhe current node
                tempPrevious = zeros(1, numProducts);
                for kk = 1:numProducts
                    tempPrevious(kk) = idxBaseBeliefProduct{kk}.Mu - omega * idxBaseBeliefProduct{kk}.Sigma;
                end
                %tempPrevious = idxBaseBeliefProduct{:}.Mu - omega * idxBaseBeliefProduct{kk}.Sigma;
                [junk currentMaxId] = max(tempPrevious);
                if itemList(1) == currentMaxId
                    VOILose = computeVOI( idxBaseBeliefProduct{itemList(2)}, idxBaseBeliefProduct{currentMaxId});
                else
                    VOILose = computeVOI( idxBaseBeliefProduct{itemList(1)}, idxBaseBeliefProduct{currentMaxId});
                end
                
                % Find the best productId for lose node giventhe current node
                tempPrevious = zeros(1, numProducts);
                for kk = 1:numProducts
                    tempPrevious(kk) = idxBaseBeliefProduct{kk}.Mu - omega * idxBaseBeliefProduct{kk}.Sigma;
                end
                %tempPrevious = idxBaseBeliefProduct{:}.Mu - omega * idxBaseBeliefProduct{kk}.Sigma;
                [junk currentMaxId] = max(tempPrevious);
                if itemList(1) == currentMaxId
                    VOIDraw = computeVOI( idxBaseBeliefProduct{itemList(2)}, idxBaseBeliefProduct{currentMaxId});
                else
                    VOIDraw = computeVOI( idxBaseBeliefProduct{itemList(1)}, idxBaseBeliefProduct{currentMaxId});
                end                               
                updatedBelief{idxDepth}{4, idxNode} = winP * VOIWin + loseP * VOILose + drawP * VOIDraw;
            end
            updatedBelief{idxDepth}{5, idxNode} = 1;
            if idxDepth == 1
                [drawP winP loseP] = computeDrawWinLoseProb( idxBaseBeliefProduct{itemList(1)}, idxBaseBeliefProduct{itemList(2)}, d );
                updatedBelief{idxDepth}{6, idxNode} = [winP drawP loseP];
            else
                updatedBelief{idxDepth}{6, idxNode} = [];
            end 
        end
    end
    idxDepth = 1;
    for idxNode = 1:breadth^idxDepth
        % ignore the pruned branch
        if updatedBelief{1}{5, idxNode} == 0
            continue;
        end
        % compute the max
        for idxCell = 1:3
            idxNodeCellDepth1 = (idxNode - 1) * queryResultNo + idxCell;
            idxNodeCellDepth2 = (idxNodeCellDepth1 - 1) * breadth + 1 : idxNodeCellDepth1 * breadth;
            updatedBelief{idxDepth}{4, idxNode}(idxCell) = max( cell2mat(updatedBelief{idxDepth+1}(4,  idxNodeCellDepth2) ));
        end
        % compute the expectation
        updatedBelief{idxDepth}{4, idxNode}(4) = updatedBelief{idxDepth}{6, idxNode}* (updatedBelief{idxDepth}{4, idxNode}(1:3))';
    end
    % compute the max
    mBase = zeros(1, breadth);
    for iii = 1:breadth
        mBase(iii) = updatedBelief{1}{4, iii}(4);
    end
    
    % find which query leads to the max and avoid the repeated query
    [junk pos] = sort ( mBase, 'descend');
    
    % Generate all queries according to the priority
    numQueries = nchoosek( breadth, sizeOfQuery );
    numQueriesHistory = size( queryHistory, 1 );
    for idxCurrentQuery = 1:numQueries
        flag = 0;
        % Check whether this query is in the queryHistory
        for idxQueryHistory = 1:numQueriesHistory
            if  length ( find ( allQueryList( pos(idxCurrentQuery), 1) == queryHistory( idxQueryHistory, :) ) ) == 1 && ...
                    length (find ( allQueryList( pos(idxCurrentQuery), 2) == queryHistory(idxQueryHistory, :) ) ) == 1
                flag = 1;
                break;
            end
        end
        if flag == 0
            itemVOI = allQueryList( pos(idxCurrentQuery), :);
            break;
        end
    end        
end