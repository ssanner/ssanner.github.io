function gain = updateBeliefFindItemWithMaximumVoICompleteOld ( belief, itemList, rank, performanceStd, bestProductBelief )
    gain = zeros(2, 1);
    if rank == 0
        isDraw = 'Y';
    elseif rank == -1
        % Make sure the winner item is at the beginning of the list.
        isDraw = 'N';
        temp = itemList(1);
        itemList(1) = itemList(2);
        itemList(2) = temp;
    else
        isDraw = 'N';
    end
    
    % drawProb  = input ('Draw probability (0 - 100): ');
    drawProb = 10;
    priorSkills = [ belief{ itemList(1), :} belief{ itemList(2), :} ];
    %[ posteriorSkills, logZ ] = NPlayerTrueSkillUpdate (performanceStd, 1e-5*performanceStd, 1e-4, drawProb/100, priorSkills, draws);
    
    if isDraw == 'Y'
        [beliefProduct1, beliefProduct2] = NPlayerTrueSkillUpdateTeamFindItemWithMaximumVoIComplete (performanceStd, 1e-5*performanceStd, 1e-4, ...
                                                                                        drawProb/100, priorSkills, isDraw);
        gain(1) = computeVOI(beliefProduct1, bestProductBelief);
        gain(2) = computeVOI(beliefProduct2, bestProductBelief);
    else
        [beliefProduct1, beliefProduct2] = NPlayerTrueSkillUpdateTeamFindItemWithMaximumVoIComplete (performanceStd, 1e-5*performanceStd, 1e-4, ...
                                                                                        drawProb/100, priorSkills, isDraw);
        gain(1) = computeVOI(beliefProduct1, bestProductBelief);
        gain(2) = computeVOI(beliefProduct2, bestProductBelief);
        if rank == -1
            temp = gain(1);
            gain(1) = gain(2);
            gain(2) = temp;
        end
    end
end