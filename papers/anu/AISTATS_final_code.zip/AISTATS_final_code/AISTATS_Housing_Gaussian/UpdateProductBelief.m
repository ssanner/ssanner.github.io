function productBeliefHalfUpdated = UpdateProductBelief(belief, itemList, performanceStd, productBeliefHalfUpdated)
    % find out the utility of the product from its features. 

    [ numProduct, numFeature ]= size( belief );
    performanceBelief = cell( length(itemList), numFeature );
    % Estimate the performance of each players: from utility of feature to
    % the utility of performance
    for i = [itemList(1) itemList(2)]
        for j = 1:numFeature
            performanceBelief{i, j} = UpdatePerformanceForQuery( belief{i, j}, performanceStd);             
        end
    end    
    % Estimate the product utility by combining all of its features    
    % Simply use uniform weight
    wFeature = ones(numFeature, 1);
    wFeatureSquared = wFeature.^2;
    for i = [itemList(1) itemList(2)]
        tempPrecision = 0;
        tempPrecisionMean = 0;
        for j = 1:numFeature
            tempPrecision = tempPrecision + wFeatureSquared(j) * 1/performanceBelief{i, j}.Precision;
            tempPrecisionMean = tempPrecisionMean + wFeature(j) * performanceBelief{i, j}.PrecisionMean / performanceBelief{i, j}.Precision;
        end
        precision = 1 / tempPrecision;
        precisionMean = precision * tempPrecisionMean;
        sigma = tempPrecision;
        mu = precisionMean/precision;
        productBeliefHalfUpdated{i} = Gaussian(mu, sqrt(sigma) );
    end
    
end