function samples = MHsampling( dim, u_low, u_upper, gridNum, convexSet, numSamples, burnK, epsilon)
    % dim: the number of product
    % u_low: the minimum value of utilities over product space
    % u_high: the maximum value of the uitlity over product space
    % gridNum: the number of segments in each axis when constructing grid
    % convexSet: the convex set for which we would like to sample
    % numSamples: the number of samples we hope to sample
    % burnK: before which (includsive), the samples will be omitted in the outp samples set.
    % epsilon: model noise
    noTotalRun = 10;
    distance = numSamples - burnK;
    samples = zeros( distance * noTotalRun, dim );
    % Initiationation of grid for constructing cubes
    hx  = (u_upper - u_low)/gridNum;
    pos   = u_low + ( 0:gridNum )*hx;
    % Randomly initialize x0
    for numRun = 1:noTotalRun
        xSeries = zeros(numSamples, dim);
        uSeries = zeros(numSamples, dim);
        % Initialize to find a grid in convexSet using linear programming
        noConstraints = size( convexSet, 1);
        if noConstraints < 1
            x = u_low + ( u_upper - u_low ) * rand(dim, 1);
        else
            f = -5 + 10 * rand(dim, 1);
            lb = ones(dim, 1)*u_low;
            ub = ones(dim, 1)*u_upper;
            zeroVector = zeros(1, dim);
            A = [];
            b = [];
            for i = 1:noConstraints
                if convexSet(i, 3) == 1
                    zeroVector( convexSet(i, 1) ) = -1;
                    zeroVector( convexSet(i, 2) ) = 1;
                    A = [A; zeroVector];
                    b = [b; epsilon];
                elseif convexSet(i, 3) == -1
                    zeroVector( convexSet(i, 1) ) = 1;
                    zeroVector( convexSet(i, 2) ) = -1;
                    A = [A; zeroVector];
                    b = [b; epsilon];     
                elseif convexSet(i, 3) == 0
                    zeroVector( convexSet(i, 1) ) = 1;
                    zeroVector( convexSet(i, 2) ) = -1;
                    A = [A; zeroVector];
                    b = [b; epsilon]; 
                    zeroVector( convexSet(i, 1) ) = -1;
                    zeroVector( convexSet(i, 2) ) = 1;
                    A = [A; zeroVector];
                    b = [b; epsilon];
                else
                    error('Constraint is not appropriate!!')
                end
            end
            x = linprog(f, A, b, [], [], lb, ub);
        end
        for i = 1:dim
            a = find( pos > x(i) );
            if length(a) >1
                xSeries(1, i) = a(1);
            else
                xSeries(1, i) = 1;
            end
        end
        uSeries(1, :) = x';
        for i = 2:numSamples
            coin = rand;
            if coin < 1/(2*dim+1)
                xSeries(i, :) = xSeries(i-1, :);
                % uSeries(i, :) = ( pos(xSeries(i, :))+ pos(xSeries(i, :) + 1) )/2;
                uSeries(i, :) = pos( xSeries(i, :) );
            else
                whichDim = randperm(dim);
                coin2 = rand;
                if coin2 < 0.5
                    finalDim = -1;
                else
                    finalDim = 1;
                end
                xSeries(i, :) = xSeries(i-1, :);
                % Check whether grid index is legal
                temp = xSeries(i-1, whichDim(1) ) + finalDim;
                if temp > gridNum 
                    temp = gridNum;
                elseif temp < 1
                    temp = 1;
                end
                xSeries(i, whichDim(1) ) = temp;
%                 uSeries(i, :) = ( pos(xSeries(i, :))+ pos(xSeries(i, :) + 1) )/2;
                uSeries(i, :) = pos( xSeries(i, :) );
            end
            inOrOut = judgeInOrOut ( uSeries(i,:), convexSet, epsilon );
            if ~inOrOut
                xSeries(i, :) = xSeries(i-1, :);
%                 uSeries(i, :) = ( pos(xSeries(i, :))+ pos(xSeries(i, :) + 1 ))/2;
                uSeries(i, :) = pos( xSeries(i, :) );
            end       
        end  
        samples( (numRun-1)*distance+1: numRun*distance, : ) = uSeries( burnK+1:end, :);
    end
end