function [itemList, productBelief ]= selectItems ( belief, sizeOfQuery, option, performanceStd)

    % select a number of items based on the strategy for item picking and
    % current belief.
    % option:
    %       0: random pick sizeOfQuery
    %       1: pick two items as a query that maximize the draw probability
    %       2: pick the best two items as a query
    %       3: pick the best and the worst items as a query
    %       4: value of information, a query with the current maximum one
    %       and the one with maximum VOI
    [ numProduct, numFeature ]= size( belief );
    performanceBelief = cell( numProduct, numFeature );
    % Estimate the performance of each players: from utility of feature to
    % the utility of performance
    for i = 1:numProduct
        for j = 1:numFeature
            performanceBelief{i, j} = UpdatePerformanceForQuery( belief{i, j}, performanceStd);             
        end
    end    
    % Estimate the product utility by combining all of its features    
    productBelief = cell( 1, numProduct );
    itemList = zeros( 1, sizeOfQuery );
    % Simply use uniform weight
    wFeature = ones(numFeature, 1);
    wFeatureSquared = wFeature.^2;
    for i = 1:numProduct
        tempPrecision = 0;
        tempPrecisionMean = 0;
        for j = 1:numFeature
            tempPrecision = tempPrecision + wFeatureSquared(j) * 1/performanceBelief{i, j}.Precision;
            tempPrecisionMean = tempPrecisionMean + wFeature(j) * performanceBelief{i, j}.PrecisionMean / performanceBelief{i, j}.Precision;
        end
        precision = 1 / tempPrecision;
        precisionMean = precision * tempPrecisionMean;
        sigma = tempPrecision;
        mu = precisionMean/precision;
        productBelief{i} = Gaussian(mu, sqrt(sigma) );
    end   
    switch option
        case 0
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 1
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 2
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 3
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 4      % Approximation of simiplied VOI
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 5
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 6      % Informed VOI: use the updated best product to compute the Tom Ralf VOI
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 7      % Uninformed VOI: use the updated best product to compute the Tom Ralf VOI
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 8      % Informed VOI: use the updated best product to compute the Tom Ralf VOI--resitrcted to the search with the current best one
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 9      % Uninformed VOI: use the updated best product to compute the Tom Ralf VOI--restricted to the search with the current best one
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 20     % Two step look ahead
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 21     % Simplified VOI using approximate integral: quad
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 22      % Old Informed VOI
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 23      % Old Uninformed VOI
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 24      % Old Informed VOI
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        case 25      % Old Uninformed VOI
            temp = randperm( numProduct );
            itemList = temp ( 1 : sizeOfQuery );
        otherwise
            disp('Query Strategy Unknown!')
    end
end