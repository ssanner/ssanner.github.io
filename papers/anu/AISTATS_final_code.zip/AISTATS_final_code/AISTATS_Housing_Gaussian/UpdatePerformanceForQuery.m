function performance = UpdatePerformanceForQuery(mar2, performanceStd)
% Get performance from player's skill
        mar1    = Gaussian(0, inf);
        msg1    = Gaussian(0, inf);
        msg2    = Gaussian(0, inf);
        prec    = 1/performanceStd;
        a       = prec / (prec + mar2.Precision - msg2.Precision);
        tempPrecisionMean = a * (mar2.PrecisionMean - msg2.PrecisionMean);
        tempPrecision     = a * (mar2.Precision - msg2.Precision);
        tempMu            = tempPrecisionMean / tempPrecision;
        tempSigma         = sqrt ( 1 / tempPrecision );
        newMsg  = Gaussian ( tempMu, tempSigma );
        oldMarginalWithoutMsg = mar1 / msg1;
        performance = oldMarginalWithoutMsg * newMsg;    
end