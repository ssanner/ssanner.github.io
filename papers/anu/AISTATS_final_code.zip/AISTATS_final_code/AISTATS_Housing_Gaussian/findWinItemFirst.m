function [winItem, queryHistory, maxItemId]= findWinItemFirst(numProduct, userUtility, queryHistory, init, maxItemId)
    if mod( numProduct, 2 ) == 0
        comb = [ init(1:2:numProduct)' init(2:2:numProduct)'];
        winItem = [];
    else
        comb = [ init(1:2:numProduct-2)' init(2:2:numProduct)'];
        winItem = init( numProduct );
    end
    
    for i = 1:numProduct/2
        [queryHistory, tempWinItem] = askUserTournamentSort( userUtility, comb(i, :), queryHistory );
        winItem = [winItem tempWinItem];
        first = randperm( length(winItem) );
        tempMaxItemId = winItem ( first(1) );
        maxItemId = [maxItemId tempMaxItemId];
    end
end