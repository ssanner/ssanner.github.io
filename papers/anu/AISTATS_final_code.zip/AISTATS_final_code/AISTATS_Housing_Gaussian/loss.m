function z = loss(y, muY, sigmaY, muX, sigmaX)
    z = y .* normpdf(y, muY, sigmaY) .* normcdf(y, muX, sigmaX);
end