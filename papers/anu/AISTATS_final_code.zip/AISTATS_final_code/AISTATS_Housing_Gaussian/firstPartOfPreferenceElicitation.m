%numFeatures = input('Please input the number of features: \ ');
load pemaut
numFeatures = 3;
numChoicesFeaturewise = zeros(1, numFeatures);
% trueBelief_uniform = cell(1, numFeatures );
% trueBelief_diag = cell(1, numFeatures );
% trueBelief_stochastic = cell(1, numFeatures );
beliefFeature = cell( 1, numFeatures );
priorBelief = Gaussian(25, 25/3);
numChoicesFeaturewise = [2 2 5];
for i = 1:numFeatures
    hint = strcat('Please input the number of choices for feature No. ', num2str(i), ' : \ ');
    %numChoicesFeaturewise(i)    = input( hint );
%     trueBelief_uniform{1, i}    = generateUserUtility( numChoicesFeaturewise(i), 0 );
%     trueBelief_diag{1, i}       = generateUserUtility( numChoicesFeaturewise(i), 1 );
%     trueBelief_stochastic{1, i} = generateUserUtility( numChoicesFeaturewise(i), 2 );
    beliefFeature{1, i}                = cell(1, numChoicesFeaturewise(i));
    for idxChoices = 1:numChoicesFeaturewise(i)
        beliefFeature{1, i}{idxChoices}= priorBelief;
    end
end
numProductAll = prod( numChoicesFeaturewise );
productIndex = zeros(numProductAll, numFeatures);
counterProduct = 1;
for i = 1:numChoicesFeaturewise(1)
    for j = 1:numChoicesFeaturewise(2)
        for k = 1:numChoicesFeaturewise(3)
            productIndex( counterProduct, : ) = [i j k];
            counterProduct = counterProduct + 1;
        end
    end
end
% Assume the all configurations of products are feasible;
numProduct = numProductAll;
stringUtilityOption = {'Uniform', 'Gaussian with diagonal covariance', 'Gaussian with stochastic covariance'};

% Save the generated user's utility
% saveUserUtlity = cell(1, 3);
% saveUserUtlity{1, 1}  = trueBelief_uniform;
% saveUserUtlity{1, 2}  = trueBelief_diag;
% saveUserUtlity{1, 3}  = trueBelief_stochastic;
trueBelief_uniform = saveUserUtlity{1, 1};
trueBelief_diag   = saveUserUtlity{1, 2};
saveResult = cell(2, 6);