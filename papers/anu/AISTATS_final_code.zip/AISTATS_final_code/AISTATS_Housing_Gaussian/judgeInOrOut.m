function inOrOut = judgeInOrOut ( u, convexSet, epsilon )

    % To verify whether a utility vector satisfy all the constraints in
    % convexSet
    
    % convexSet(i,1:3): convexSet(i,1) the no. of the first item;
    %                   convexSet(i,2) the no. of the second item;
    %                   convexSet(i,3) the constraint on utilities over
    %                                  these two items
    %                                  1: u(i) > u(j) - \epsilon
    %                                  0: |u(i) - u(j)| <= \epsilon
    %                                 -1: u(j) > u(i) - \epsilon
    numConstraints = size( convexSet, 1);
    if numConstraints < 1
        inOrOut = 1;
        %disp('There is no constraint currently');
    else
        for i = 1:numConstraints
            item1 = convexSet(i, 1);
            item2 = convexSet(i, 2);
            switch convexSet(i, 3)
                case 1
                    if u(item1)  > u(item2) - epsilon 
                        inOrOut = 1;
                    else
                        inOrOut = 0;
                    end
                case 0
                    if abs ( u(item1) - u(item2) ) <= epsilon
                        inOrOut = 1;
                    else
                        inOrOut = 0;
                    end                
                case -1
                    if u(item2) > u(item1) - epsilon
                        inOrOut = 1;
                    else
                        inOrOut = 0;
                    end
                otherwise
                    error('Cannot verify whether the current utility vector is in convex set!!!')
            end
            if inOrOut == 0 
                break;
            end
        end    
    end
end