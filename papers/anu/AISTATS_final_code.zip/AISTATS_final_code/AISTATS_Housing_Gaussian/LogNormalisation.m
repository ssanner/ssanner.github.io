function logZRes = LogNormalisation(varBag, MessageBag, noPlayers, playerPerformances, playerPerformanceDifferences, draws, epsilon)
% Output the normalisation constant
    for id = 1 : 3*noPlayers - 1
        varBag{id} = Gaussian( 0, inf );
    end
    sumLogZ = 0;
    % Prior factors (NumberOfMessenges = 1)
    for id = 1 : noPlayers
        [logZ, varBag] = SendMessageHelper(id, MessageBag, id, varBag);
        sumLogZ = sumLogZ + logZ;
    end
    % Likelihood factors (NumberOfMessenges = 2)
    for id = 1 : noPlayers
        [logZ, varBag] = SendMessageHelper( 2 * noPlayers + id, MessageBag, noPlayers + id, varBag);
        sumLogZ = sumLogZ + logZ;
        [logZ, varBag] = SendMessageHelper( noPlayers + id, MessageBag, id, varBag);
        sumLogZ = sumLogZ + logZ;
    end
    % Performance difference factors (NumberOfMessenges = 3)
    for id = 1 : noPlayers - 1
        [logZ, varBag] = SendMessageHelper( 5 * noPlayers + id - 2, MessageBag, playerPerformanceDifferences(id), varBag);
        sumLogZ = sumLogZ + logZ;
        [logZ, varBag] = SendMessageHelper( 3 * noPlayers + 2 * id -1, MessageBag, playerPerformances(id), varBag);
        sumLogZ = sumLogZ + logZ;
        [logZ, varBag] = SendMessageHelper( 3 * noPlayers + 2 * id, MessageBag, playerPerformances(id)+1, varBag);
        sumLogZ = sumLogZ + logZ;            
    end
    % Greater than or within factors (NumberOfMessenges = 1)
    for id = 1 : noPlayers - 1
        [logZ, varBag] = SendMessageHelper( 6 * noPlayers - 3 + id, MessageBag, playerPerformanceDifferences(id), varBag);
        sumLogZ = sumLogZ + logZ;
    end
        
    sumLogS = 0;
    % Prior factors
    for id = 1 : noPlayers
        sumLogS = sumLogS + 0;
    end
    % Likelihood factors
    for id = 1 : noPlayers
        sumLogS = sumLogS + LogRatioNormalisation( varBag{id}, MessageBag{ noPlayers + id } );
    end
    % Performance difference factors 
    for id = 1 : noPlayers - 1
        sumLogS = sumLogS + LogRatioNormalisation( varBag{playerPerformances(id)}, MessageBag{ 3*noPlayers + 2*id -1} ) + ...
                               LogRatioNormalisation( varBag{playerPerformances(id)+1}, MessageBag{ 3*noPlayers + 2*id } );
    end
    % Greater than or within factors 
    for id = 1 : noPlayers - 1
        if draws(id)=='N'
            marginal = varBag{ playerPerformanceDifferences(id) };
            msg      = MessageBag{ 6*noPlayers - 3 + id };
            msgFromVar = marginal / msg;
            sumLogS = sumLogS - LogProductNormalisation (msgFromVar, msg) + ...
                     log(normcdfO ((msgFromVar.Mean - epsilon)/msgFromVar.StandardDeviation)) ;
        else
            marginal = varBag{ playerPerformanceDifferences(id) };
            msg      = MessageBag{ 6*noPlayers - 3 + id };
            msgFromVar = marginal / msg;
            meanF = msgFromVar.Mean;
            stdF = msgFromVar.StandardDeviation;
            Z = normcdfO ((epsilon - meanF)/stdF) - normcdfO ((-epsilon-meanF)/stdF);
            sumLogS = sumLogS - LogProductNormalisation (msgFromVar, msg) + log(Z);  
        end
    end
    logZRes = sumLogS + sumLogZ;
end