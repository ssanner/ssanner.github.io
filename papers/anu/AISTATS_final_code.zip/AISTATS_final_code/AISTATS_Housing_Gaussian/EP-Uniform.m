tic
resultExpectedLoss  = [];
resultStandardError = [];
numProduct = 20;
sizeOfQuery = 2;
noisyLevel = 0.05;
%performanceStd = 0.1;
performanceStd = 1;
disp('option 0: Random pick two');
% disp('option 1: Maximum matching quality');
disp('option 2: Best two items');
disp('option 3: Best and worst items');
disp('option 4: VOI');
omega = 3;   % parameter for variance-adjusted expect utility: \mu - \omega * sigma
maxIter      = 50;
maximumUtilityProductID = zeros( 1, maxIter );
numExperiment = 50;
maxItemId = zeros (numExperiment, maxIter);
% fid = fopen('log.txt','wt');

% the user's hidden utility over all product, Uniform distribution (1, 100)
load trueBelief_uniform_as_a_base_for_OtherStratagies.mat;

% beliefOption: 0, uniform; 1, diagonal, 2, stochastic
beliefOption = 2;
load trueBelief_diag;
load trueBelief_stochastic;
load trueBelief_uniform;
%trueBelief_uniform = 1 + (100-1)*rand(1,numProduct);
if beliefOption == 0
    trueBelief = trueBelief_uniform;
elseif beliefOption == 1
    trueBelief = trueBelief_diag;
elseif beliefOption == 2
    trueBelief = trueBelief_stochastic;
end
for option     = [0 2 3 4]    % random pick items for query
    for iterExperiment = 1:numExperiment
        belief     = cell( 1, numProduct );
%         fprintf(fid, 'Experiment No. %d\n', iterExperiment);
        for i = 1: numProduct
            belief{i} = Gaussian( 25, 25/3 );
        end
        queryHistory = [];
        for iter=1:maxIter
            % Select sizeOfQuery items for a query
            itemList                = selectItems ( belief, sizeOfQuery, option, performanceStd, omega, queryHistory );
            queryHistory            = [queryHistory; itemList];
            before1                 = belief{ itemList(1) };
            before2                 = belief{ itemList(2) };
            rank                    = askUser ( trueBelief, itemList, noisyLevel );
            [belief quality]        = updateBelief ( belief, itemList, rank, performanceStd );
            maximumUtilityProductID = findMaximumUtility ( belief, omega );
            maxItemId( iterExperiment, iter ) = maximumUtilityProductID;                            
%             fprintf( fid,'%d %d  VS.  %d %d\t%f -> %f \t %f -> %f \t %f -> %f \t %f -> %f \n',...
%                     iter, itemList(1), itemList(2), rank, before1.Mu, belief{itemList(1)}.Mu, before2.Mu, belief{itemList(2)}.Mu, ...
%                     before1.Sigma, belief{itemList(1)}.Sigma, before2.Sigma, belief{ itemList(2) }.Sigma ) ;
        end
    end
    % Compute expected loss and standard error
    [expectedLoss standardError] = computeExpectedLossStandardError( trueBelief, maxItemId );
    %errorbar(1:maxIter, expectedLoss, -standardError, + standardError, '-xm')
    resultExpectedLoss  = [ resultExpectedLoss; expectedLoss];
    resultStandardError = [ resultStandardError; standardError ];
end
% fclose(fid);
figure;
comp = 1:maxIter;
a = [comp; comp; comp; comp ];
% a = [comp; comp];
errorbar(a', resultExpectedLoss', resultStandardError','-o')
[val1 junk] = max ( max( resultExpectedLoss ) );
[val2 junk] = max (max( resultStandardError ) );
yMax = val1+ val2+0.5;
legend('Random Two', 'Best Two', 'Best & Worst', 'Value of Info.')
% legend('random', 'best two')
xlabel('Number of queries');
ylabel('Expected loss');
axis([0.5 maxIter 0 yMax])
% title('Uniform utility, 20 items, no noise, single update');
% title('Diagonal covariance Gaussian utility, 20 items, no noise--single update');
title('Stochastic covariance Gaussian utility, 20 items, noisy response: 5%');
toc
 
