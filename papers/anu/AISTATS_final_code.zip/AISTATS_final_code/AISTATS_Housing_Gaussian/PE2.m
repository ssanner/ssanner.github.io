% Initialization 
resultExpectedLoss  = [];
resultStandardError = [];
fractionMaxIterTotalProduct = 0.5;
omega = 3;   % parameter for variance-adjusted expect utility: \mu - \omega * sigma
noisyLevel = 0.05;
performanceStd = 0.5;
sizeOfQuery = 2;
totalProductList = [2 4 16 32 64 128];
ExpectedLossPerItem = cell (1, length( totalProductList ) );
StandardErrorPerItem = cell ( 1, length( totalProductList ) );
numExperiment = 50;

for k = 1:length(totalProductList)
    counterProduct = totalProductList(k); 
    trueBelief = generateUserUtility( counterProduct, 2 );
    maxIter      = floor(fractionMaxIterTotalProduct * counterProduct);
    maximumUtilityProductID = zeros( 1, maxIter );
    maxItemId = zeros (numExperiment, maxIter);
    resultExpectedLoss = zeros ( 1, 5 );
    resultStandardError = zeros (1, 5 );
    for option     = 2:4 
        numProduct = counterProduct;
        belief     = cell( 1, numProduct );
        for i = 1: numProduct
            belief{i} = Gaussian( 25, 25/3 );
        end
        for iterExperiment = 1:numExperiment
            for iter=1:maxIter
                % Select sizeOfQuery items for a query
                itemList                = selectItems ( belief, sizeOfQuery, option, performanceStd, omega );
                rank                    = askUser ( trueBelief, itemList, noisyLevel );
                [belief quality]        = updateBelief ( belief, itemList, rank, performanceStd );
                maximumUtilityProductID = findMaximumUtility ( belief, omega );
                maxItemId( iterExperiment, iter ) = maximumUtilityProductID;
            end
        end
        % Compute expected loss and standard error
        [expectedLoss standardError] = computeExpectedLossStandardError( trueBelief, maxItemId );
        resultExpectedLoss ( option+1 )  = expectedLoss(end);
        resultStandardError ( option+1 ) = standardError(end);
    end
    ExpectedLossPerItem{k} = resultExpectedLoss;
    StandardErrorPerItem{k} = resultStandardError;
end

comp = 1:length(totalProductList);
a = [comp; comp; comp ];
errorbar(a', resultExpectedLoss', resultStandardError','-o')
[val1 junk] = max ( max( resultExpectedLoss ) );
[val2 junk] = max (max( resultStandardError ) );
yMax = val1+ val2+0.5;
legend('Best Two', 'Best & Worst', 'Value of Info.')
xlabel('Number of queries');
ylabel('Expected loss');
axis([0.5 maxIter 0 yMax])
%title('Uniform utiltity, 20 items');
% title('Gaussian distribution with diagonal covariance utility');
 title('Gaussian distribution with stochastic covariance utility');




