        i = 3;
        trueBelief = saveUserUtlity{i};
        numProductAll = 20;
        numFeatures = 3;
        trueBeliefProduct = zeros(numProductAll, 1);
        for idxProduct = 1:numProductAll
            trueBeliefProduct(idxProduct) = 0;
            for idxFeature = 1:numFeatures
                trueBeliefProduct(idxProduct) = trueBeliefProduct(idxProduct) + trueBelief{1, idxFeature} (productIndex(idxProduct, idxFeature));
            end
        end
        stringUtilityOption = {'Uniform', 'Gaussian with diagonal covariance', 'Gaussian with stochastic covariance'};
        
        tit = strcat( stringUtilityOption{i},' 20 items, True Maximum Utility', num2str(max(trueBeliefProduct)), ' - True Current Utiilty, x: time!');
        figure;
        temp = saveResult{i, 5};
        temp(:, 1) = mean( temp(:, 2:end), 2 );
        errorbar1 = errorbar(cumsum(temp, 2)', saveResult{i, 1}', saveResult{i, 2}','-o');
        set(errorbar1(6),'Marker','*','DisplayName','Uninformed VOI');
        set(errorbar1(5),'Marker','+','DisplayName','Informed VOI');
        set(errorbar1(4),'Marker','.','DisplayName','VOI');
        set(errorbar1(3),'Marker','x','DisplayName','Best & Largest Uncertainty');
        set(errorbar1(2),'Marker','square','DisplayName','Best Two');
        set(errorbar1(1),'Marker','o','DisplayName','Random Two');
        xlabel('Cummulated time used (s)');
        ylabel('Expected loss');
        legend('Random Two', 'Best Two', 'Best & Largest Uncertainty', 'VOI', 'Informed VOI', 'Uninformed VOI');
        %axis([0.5 maxIter 0 yMax])
        title(tit);