function VOI = computeVOIAccurate(x, beliefAny)
    % Compute the VOI of beliefAny with regard to the current best belief:
    % Accurate, calculate double integral
    VOI = beliefAny.Sigma/sqrt(2*pi) * exp( - ( x - beliefAny.Mu).^2 / (2*beliefAny.Variance) ) + ...
                (beliefAny.Mu - x) .* (1 - normcdf(x, beliefAny.Mu, beliefAny.Sigma) );
end


