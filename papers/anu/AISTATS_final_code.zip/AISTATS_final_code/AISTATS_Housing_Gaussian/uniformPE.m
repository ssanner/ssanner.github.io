numProduct = 20;
numExperiment = 1;
noisyLevel = 0.01;
maxIter = 50;
sizeOfQuery = 2;
disp('Query option: 0--Randomly two')
disp('              1--Best matching quality')
disp('              2--Best two')
disp('              3--Best & Worst')
disp('              4--VoI.')
% the user's hidden utility over all product, Uniform distribution (1, 100)
loadData;
u_low = 0;
u_upper = 100;
gridNum = 2000;
numSamples = 500;
burnK = 100;
epsilon = 10;
userTrueUtility = max(max(trueBelief));
fourMeanUtility = zeros(4, maxIter);
fourStdUtility = zeros(4, maxIter);
idx = 1;
for option     = [0 2 3 4]    
    colLoss = zeros(numExperiment, maxIter);
    for iterExperiment = 1:numExperiment
        convexSet = [];
        tempLoss  = zeros( 1, maxIter);
        tempConvexSet = zeros(1, 3);
        for iter=1:maxIter
            itemList  = selectItemsUniform ( convexSet, sizeOfQuery, option, epsilon, numProduct, u_low, u_upper, gridNum, numSamples, burnK)
            rank      = askUser ( trueBelief, itemList, noisyLevel );
            % update feasible utility function space by adding a constraint
            % based on the user's response
            tempConvexSet(1:2) = itemList;
            tempConvexSet(3) = rank;
            convexSet = [convexSet; tempConvexSet];
            samples = MHsampling( numProduct, u_low, u_upper, gridNum, convexSet, numSamples, burnK, epsilon);
            [junk currentMaxUtilityID]= max (mean( samples ) );
            loss    = userTrueUtility - trueBelief( currentMaxUtilityID );
            tempLoss( iter ) = loss;
        end
        colLoss (iterExperiment, :) = tempLoss;
    end
    fourMeanUtility(idx, :) = mean(colLoss);
    fourStdUtility(idx, :) = std(colLoss);
    idx = idx + 1;
end 
figure;
comp = 1:maxIter;
a = [comp; comp; comp; comp ];
% a = [comp; comp];
errorbar(a', fourMeanUtility', fourStdUtility','-o')
[val1 junk] = max ( max( fourMeanUtility ) );
[val2 junk] = max ( max( fourStdUtility ) );
yMax = val1+ val2+0.5;
legend('Random Two', 'Best Two', 'Best & Worst', 'Value of Info.')
xlabel('Number of queries');
ylabel('Expected loss');
axis([0.5 maxIter 0 yMax])
% title('Uniform utility, 20 items, no noise, single update');
% title('Diagonal covariance Gaussian utility, 20 items, no noise--single update');
% title('Stochastic covariance Gaussian utility, 20 items, noisy response: 5%');
