function VOI = computeVOI(beliefAny, beliefBest)
    % Compute the VOI of beliefAny with regard to the current best belief:
    % beliefBest
    VOI = beliefAny.Sigma/sqrt(2*pi) * exp( - ( beliefBest.Mu - beliefAny.Mu)^2 / (2*beliefAny.Variance) ) + ...
                (beliefAny.Mu - beliefBest.Mu) * (1 - normcdf(beliefBest.Mu, beliefAny.Mu, beliefAny.Sigma) );
end