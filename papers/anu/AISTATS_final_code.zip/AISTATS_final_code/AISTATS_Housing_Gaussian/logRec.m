fid = fopen('log2.txt', 'wt');
for i = 1:14
    fprintf( fid,'%s %d %f %f\n', 'MessageBag', i, MessageBag{i}.Mu, MessageBag{i}.Sigma); 
end
for i = 1:7
    fprintf( fid,'%s %d %f %f\n', 'VariableBag', i, varBag{i}.Mu, varBag{i}.Sigma);
end
fclose(fid);