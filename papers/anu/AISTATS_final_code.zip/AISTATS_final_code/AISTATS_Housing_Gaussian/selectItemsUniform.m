function itemList  = selectItemsUniform ( convexSet, sizeOfQuery, option, epsilon, numProduct, u_low, u_upper, gridNum, numSamples, burnK)

    % To select query according to the current convexSet and query strategy
%     disp('Query option: 0--Randomly two')
%     disp('              1--Best matching quality')
%     disp('              2--Best two')
%     disp('              3--Best & Worst')
%     disp('              4--VoI.')
    
    itemList = zeros(1, sizeOfQuery);
    if option == 0 
        temp = randperm( numProduct );
        itemList = temp(1:2);
    else
        samples = MHsampling( numProduct, u_low, u_upper, gridNum, convexSet, numSamples, burnK, epsilon);
        [sampleSize junk] = size(samples);
        m = mean(samples);
        [junk pos] = sort(m);
        if option == 2
            itemList = pos( end-1: end);
        elseif option == 3
            itemList(1) = pos(1);
            itemList(2) = pos(end);
        elseif option == 4
            % find the current best item;
            itemList(1) = pos(end);
            counterDim = zeros(1, numProduct);
            for i = 1:sampleSize
                for j = 1:numProduct
                    if samples(i, j) > samples(i, itemList(1) )
                        counterDim(j) = counterDim(j) + 1;
                    end
                end
            end
            [junk itemList(2) ] = max ( counterDim );
        end
    end
end