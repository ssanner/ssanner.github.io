% legend('Appro. Simpi. VOI-4', 'New Informed VOI-6', 'New Uninformed VOI-7', 'Rest. New Informed VOI-8', 'Rest. New Uninformed VOI-9', ...
%     'Simpi. VOI Integral-21', 'Old Informed VOI-22', 'Old Uninformed VOI-23', 'Rest. Old Informed VOI-24', 'Rest. Old Uninformed VOI-25');
maxUtility = [126.5620 238.6559 203.1265];
%numStrategy = 10;
numStrategy = 6;
beliefOption = 1; % Uniformed utility function
idxEL = 1;
idxSE = 2;

expectedLoss = zeros(numStrategy, 25);
standardError = zeros(numStrategy, 25);
% ExpectedLoss
expectedLoss(1, :) = saveResult46{beliefOption, idxEL}(1, :);    % 4
expectedLoss(2, :) = saveResult46{beliefOption, idxEL}(2, :);    % 6  
expectedLoss(3, :) = saveResult789{beliefOption, idxEL}(1, :);   % 7
expectedLoss(4, :) = saveResult789{beliefOption, idxEL}(2, :);   % 8
expectedLoss(5, :) = saveResult789{beliefOption, idxEL}(3, :);   % 9
expectedLoss(6, :) = saveResult21{beliefOption, idxEL}(1, :);    % 21 
% expectedLoss(7, :) = saveResultOldPEMAUT{beliefOption, idxEL}(5, :);      % 22 old informed voi 
% expectedLoss(8, :) = saveResult23_24_25{beliefOption, idxEL}(1, :);       % 23 old uninformed voi
% expectedLoss(9, :) = saveResult23_24_25{beliefOption, idxEL}(2, :);       % 24 
% expectedLoss(10, :)= saveResult23_24_25{beliefOption, idxEL}(3, :);       % 25 

% StandardError
standardError(1, :) = saveResult46{beliefOption, idxSE}(1, :);    % 4
standardError(2, :) = saveResult46{beliefOption, idxSE}(2, :);    % 6  
standardError(3, :) = saveResult789{beliefOption, idxSE}(1, :);   % 7
standardError(4, :) = saveResult789{beliefOption, idxSE}(2, :);   % 8
standardError(5, :) = saveResult789{beliefOption, idxSE}(3, :);   % 9
standardError(6, :) = saveResult21{beliefOption, idxSE}(1, :);    % 21 
% standardError(7, :) = saveResultOldPEMAUT{beliefOption, idxSE}(5, :);      % 22 old informed voi 
% standardError(8, :) = saveResult23_24_25{beliefOption, idxSE}(1, :);       % 23 old uninformed voi
% standardError(9, :) = saveResult23_24_25{beliefOption, idxSE}(2, :);       % 24 
% standardError(10, :)= saveResult23_24_25{beliefOption, idxSE}(3, :);       % 25 

% x axis
x = 1:25;
xx = zeros(numStrategy, 25);
for i = 1:numStrategy 
    xx(i, :) = x;
end
createfigureLossVSQueriesPartial(xx', expectedLoss'/maxUtility(1), 0*standardError'/maxUtility(1), 0*standardError'/maxUtility(1)) 

% plot(xx', expectedLoss')
% legend('Appro. Simpi. VOI-4', 'New Informed VOI-6', 'New Uninformed VOI-7', 'Rest. New Informed VOI-8', 'Rest. New Uninformed VOI-9', ...
%      'Simpi. VOI Integral-21', 'Old Informed VOI-22', 'Old Uninformed VOI-23', 'Rest. Old Informed VOI-24', 'Rest. Old Uninformed VOI-25');
% plot(xx', expectedLoss')
legend('Appro. Simpi. VOI-4', 'New Informed VOI-6', 'New Uninformed VOI-7', 'Rest. New Informed VOI-8', 'Rest. New Uninformed VOI-9', ...
     'Simpi. VOI Integral-21');
%--------------------------------------------------------------------------
maxUtility = [126.5620 238.6559 203.1265];
numStrategy = 10;
beliefOption = 2; % Uniformed utility function
idxEL = 1;
idxSE = 2;

expectedLoss = zeros(numStrategy, 25);
standardError = zeros(numStrategy, 25);
% ExpectedLoss
expectedLoss(1, :) = saveResult46{beliefOption, idxEL}(1, :);    % 4
expectedLoss(2, :) = saveResult46{beliefOption, idxEL}(2, :);    % 6  
expectedLoss(3, :) = saveResult789{beliefOption, idxEL}(1, :);   % 7
expectedLoss(4, :) = saveResult789{beliefOption, idxEL}(2, :);   % 8
expectedLoss(5, :) = saveResult789{beliefOption, idxEL}(3, :);   % 9
expectedLoss(6, :) = saveResult21{beliefOption, idxEL}(1, :);    % 21 
expectedLoss(7, :) = saveResultOldPEMAUT{beliefOption, idxEL}(5, :);      % 22 old informed voi 
expectedLoss(8, :) = saveResult23_24_25{beliefOption, idxEL}(1, :);       % 23 old uninformed voi
expectedLoss(9, :) = saveResult23_24_25{beliefOption, idxEL}(2, :);       % 24 
expectedLoss(10, :)= saveResult23_24_25{beliefOption, idxEL}(3, :);       % 25 

% StandardError
standardError(1, :) = saveResult46{beliefOption, idxSE}(1, :);    % 4
standardError(2, :) = saveResult46{beliefOption, idxSE}(2, :);    % 6  
standardError(3, :) = saveResult789{beliefOption, idxSE}(1, :);   % 7
standardError(4, :) = saveResult789{beliefOption, idxSE}(2, :);   % 8
standardError(5, :) = saveResult789{beliefOption, idxSE}(3, :);   % 9
standardError(6, :) = saveResult21{beliefOption, idxSE}(1, :);    % 21 
standardError(7, :) = saveResultOldPEMAUT{beliefOption, idxSE}(5, :);      % 22 old informed voi 
standardError(8, :) = saveResult23_24_25{beliefOption, idxSE}(1, :);       % 23 old uninformed voi
standardError(9, :) = saveResult23_24_25{beliefOption, idxSE}(2, :);       % 24 
standardError(10, :)= saveResult23_24_25{beliefOption, idxSE}(3, :);       % 25 

% x axis
x = 1:25;
xx = zeros(10, 25);
for i = 1:numStrategy 
    xx(i, :) = x;
end
createfigureLossVSQueriesPartial(xx', expectedLoss'/maxUtility(2), standardError'/maxUtility(2), standardError'/maxUtility(2)) 