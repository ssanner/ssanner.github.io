function [ logZ, varBag ] = SendMessageHelper(msgIdx, MessageBag, varIdx, varBag)

    mar = varBag{varIdx};
    msg = MessageBag{msgIdx};
    logZ = LogProductNormalisation(mar, msg);
    varBag{varIdx} = mar * msg;
end