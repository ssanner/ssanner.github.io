////////////////////////////////////////////////////////
// Class:  Trace
// Author: Scott P. Sanner
//
// Description: This class serves as a trace utility.
//              SetTraceLevel(int) is used to set the
//              trace level and then the MACRO T is used
//              to print out messages which are below
//              the level threshold.
//
////////////////////////////////////////////////////////

#include <iostream>

#ifndef _TRACE_H_
#define _TRACE_H_

using namespace std;
//#define NDEBUG

#ifndef NDEBUG
	// Any class that uses Trace should declare a member m_tm
	#define T(level,msg) m_tm->TraceMessage(level,msg)
	#define T2(level,msg,i1,i2) m_tm->TraceMessage2(level,msg,i1,i2)
#else
	#define T(level,msg)    
	#define T2(level,msg,i1,i2)       
#endif

class Trace
{
	private:
		ostream &m_osOut;
		int      m_nTraceLevel;

	public:
		Trace():m_osOut(cout),m_nTraceLevel(0) {}
		Trace(ostream &os, int tl):m_osOut(os),m_nTraceLevel(tl) {}

		void TraceMessage(int level, char msg[])
		{
			if (level <= m_nTraceLevel) 
				m_osOut << msg << endl;
		}

		void TraceMessage2(int level, char msg[], int i1, int i2)
		{
			if (level <= m_nTraceLevel) 
				m_osOut << msg << ":" << i1 << ":" << i2 << endl;
		}
};

#endif /* _TRACE_H_ */
