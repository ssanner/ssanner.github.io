////////////////////////////////////////////////////////
// Class:  BackgammonDisplay
// Author: Scott P. Sanner
//
// Description:
//
////////////////////////////////////////////////////////

#ifndef _BACKGAMMON_DISPLAY_H_
#define _BACKGAMMON_DISPLAY_H_

#include <iostream>
#include "Backgammon.h"

using namespace std;

class BackgammonDisplay
{
	public:
		virtual void DisplayStartInfo(Backgammon *pgame) = 0;
		virtual void DisplayGameInfo (Backgammon *pgame) = 0;
		virtual void DisplayWinInfo  (Backgammon *pgame) = 0;
		virtual void DisplayTurn     (Backgammon *pgame, bgplayer p, int m) = 0;
		virtual void DisplayMoveSet  (Backgammon *pgame, bgplayer p) = 0;
		virtual void DisplayError    (Backgammon *pgame, int msg) = 0;
};

class NullDisplay:public BackgammonDisplay
{
	public:
		NullDisplay() { games = 0; }

		virtual void DisplayStartInfo(Backgammon *pgame) {}
		virtual void DisplayGameInfo (Backgammon *pgame) {}
		virtual void DisplayTurn     (Backgammon *pgame, bgplayer p, int m) {}
		virtual void DisplayMoveSet  (Backgammon *pgame, bgplayer p) {}
		virtual void DisplayError    (Backgammon *pgame, int msg) {}
		virtual void DisplayWinInfo  (Backgammon *pgame) 
		{ cout << "Game " << ++games << ": " 
		       << pgame->GetPlayerName(pgame->WhoHasWon()) << " won" << endl; }

	private:
		int games;
};

class TextDisplay:public BackgammonDisplay
{
	public:
		TextDisplay();
		TextDisplay(ostream &os);

		virtual void DisplayStartInfo(Backgammon *pgame);
		virtual void DisplayGameInfo (Backgammon *pgame);
		virtual void DisplayWinInfo  (Backgammon *pgame);
		virtual void DisplayTurn     (Backgammon *pgame, bgplayer p, int m);
		virtual void DisplayMoveSet  (Backgammon *pgame, bgplayer p);
		virtual void DisplayError    (Backgammon *pgame, int msg);

	private:
		ostream &out;
};

#endif // _BACKGAMMON_DISPLAY_H_
