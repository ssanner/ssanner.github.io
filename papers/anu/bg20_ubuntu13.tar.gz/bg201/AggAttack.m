function [x,y,p,c] = AggAttack(data)

x = 1:1:24;
x1 = 1:.1:24;
y = zeros(24,1);
count = zeros(24,1);
[r,c] = size(data);

for i=1:1:24
   for r1 = 1:1:r
      if (data(r1,1) == i)
         %i
         %r1
         %y
         y(i) = y(i) + data(r1,2);
         count(i) = count(i) + 1;
      end
   end
end

newx = [];
newy = [];

for i=1:24
   if (count(i) ~= 0)
      newx = [newx, x(i)];
      newy = [newy, y(i)./count(i)];
   end
end

y1 = spline(newx,newy,x1);
x = x1;
y = y1;
p = [newx', newy'];
c = count;