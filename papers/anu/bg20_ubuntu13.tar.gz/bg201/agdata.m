% Make sure the results file has the first line removed and then load
% it into Matlab using the load <filename>.txt command.  Once it is loaded
% simply pass it to this function giving it the results matrix, the number
% of points to average by, the figure id for the plot, and player types
% or labels for the white player and the black player enclosed in single
% quotes.
%
% g is the game matrix - winner in col2 0/1, n is the number to average by
% b is percentage wins of black, w is percentage wins of white
function [games,w,b] = agdata(n,fig_id, filename, p1, p2, sval, nfiles)

%for q=1:nfiles
%   str = ['load ',filename,'.txt'];
%   eval(str);
%   if (q ~= 1)
%      str = ['g = g + ',filename,';'];
%   else
%      str = ['g = ',filename,';'];
%   end
%   eval(str);
%end
%g = g./nfiles;
g = filename;

s = size(g,1); % num rows
games = [];
w = [];
b = [];
for i=1:n:s
   if ((i+n)>s)
      e = s;
   else
      e = i+n;
   end
   %[i, e, s]
   
   b = [b;[sum(g(i:e,2))./(e-i)]];
   w = [w;[1-(sum(g(i:e,2))./(e-i))]];
end
%size([1:n:s])
%size(w)
figure(fig_id);
games = [0; [1:n:s]'+ n];
games_interp = [0; [1:n./10:s]'+ n];
w = [sval;w];
b = [(1-sval);b];
cw = polyfit(games,w,3);
%interp_w = polyval(cw,games_interp);
interp_w = spline(games,w,games_interp);
cb = polyfit(games,b,3);
%interp_b = polyval(cb,games_interp);
interp_b = spline(games,b,games_interp);
plot(games,w,'or');
hold on;
plot(games_interp,interp_w,'-r');
title(['Percentage wins of White(O)/', p1,' and Black(X)/', p2]);
xlabel('Number of games');
ylabel('Percentage of games won');
plot(games,b,'xb');
plot(games_interp,interp_b,'-b');
axis([1,s,0,1]);
hold off;