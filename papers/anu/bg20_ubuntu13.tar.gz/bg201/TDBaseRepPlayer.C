#include "TDBaseRepPlayer.h"

// Constructor - read in file parameters
TDBaseRepPlayer::TDBaseRepPlayer(int filenum)
{
	ifstream is;
	float conflict_res_temp;
	float lambda;
	float min_penalty;
	float max_penalty;
	double eta;
	double momentum;
	int   hidden;
	char  text[80];
	char  filename[80] = "td-baserep-config-v";

	m_nFilenum = filenum;

	strcat(filename, ((m_nFilenum==1)?"1":"2"));
	strcat(filename, ".txt");

	is.open(filename, ios::in);
	cout << "TD-BaseRep Player v." << filenum << ": Reading Configuration File" << endl;

	is >> text;
	if (strcmp(text,"CONFLICT_RES_TEMP") != 0)
	{ cerr << "CONFLICT_RES_TEMP unspecified" << endl; exit(-1); }
	is >> conflict_res_temp;
	SetConflictResTemp(conflict_res_temp);
	cout << "CONFLICT_RES_TEMP: " << GetConflictResTemp() << endl;

	is >> text;
	if (strcmp(text,"LAMBDA") != 0)
	{ cerr << "LAMBDA unspecified" << endl; exit(-1); }
	is >> lambda;
	SetLambda(lambda);
	cout << "LAMBDA:            " << GetLambda() << endl;

	is >> text;
	if (strcmp(text,"ETA") != 0)
	{ cerr << "ETA unspecified" << endl; exit(-1); }
	is >> eta;
	SetEta(eta);
	cout << "ETA:               " << GetEta() << endl;

	is >> text;
	if (strcmp(text,"MOMENTUM") != 0)
	{ cerr << "MOMENTUM unspecified" << endl; exit(-1); }
	is >> momentum;
	SetMomentum(momentum);
	cout << "MOMENTUM:          " << GetMomentum() << endl;

	is >> text;
	if (strcmp(text,"HIDDEN") != 0)
	{ cerr << "HIDDEN unspecified" << endl; exit(-1); }
	is >> hidden;
	SetHidden(hidden);
	cout << "HIDDEN:            " << GetHidden() << endl;

	is >> text;
	if (strcmp(text,"MIN_BLOT_PENALTY") != 0)
	{ cerr << "MIN_BLOT_PENALTY unspecified" << endl; exit(-1); }
	is >> min_penalty;
	SetMinBlotPenalty(min_penalty);
	cout << "MIN_BLOT_PENALTY:  " << GetMinBlotPenalty() << endl;

	is >> text;
	if (strcmp(text,"MAX_BLOT_PENALTY") != 0)
	{ cerr << "MAX_BLOT_PENALTY unspecified" << endl; exit(-1); }
	is >> max_penalty;
	SetMaxBlotPenalty(max_penalty);
	cout << "MAX_BLOT_PENALTY:  " << GetMaxBlotPenalty() << endl;

	is >> text;
	if (strcmp(text,"LEARNING") != 0)
	{ cerr << "LEARNING unspecified" << endl; exit(-1); }
	is >> text;
	m_bLearningOn = (strcmp(text,"ON") == 0);
	cout << "LEARNING:          " << ((m_bLearningOn)?"ON ":"OFF") << endl;

	// Read Neural Net
	m_aNNUtilities = new NeuralNet*[Feature::m_nDefined];

	for (int i=0; i<Feature::m_nDefined; i++)
	{
		m_aNNUtilities[i] = new NeuralNet(is);

		if (m_aNNUtilities[i]->m_bpNet == NULL)
		{
			m_aNNUtilities[i] = new NeuralNet(INPUT_UNITS, HIDDEN, OUTPUT_UNITS, ETA, MOMENTUM);
			m_aNNUtilities[i]->RandomizeWeights();
			cout << "Created neural net #" << i << endl;
		}
		else
		{
			if ((m_aNNUtilities[i]->m_nInputUnits  != INPUT_UNITS) ||
				(m_aNNUtilities[i]->m_nHiddenUnits != HIDDEN) ||
				(m_aNNUtilities[i]->m_nOutputUnits != OUTPUT_UNITS))
			{
				cerr << "Incorrect neural net dimension specifications" << endl;
				exit(-1);
			}
			cout << "Read neural net #" << i << endl;
		}

		m_aNNUtilities[i]->m_dEta      = ETA;
		m_aNNUtilities[i]->m_dMomentum = MOMENTUM;

	}

	is.close();

	#ifdef TD_BASEREP_PRINT_DEBUG
	m_aoutfile.open("td-baserep-debug.txt", ios::out|ios::trunc);
	m_adisp = new TextDisplay(m_aoutfile);
	#endif
}

// Destructor
TDBaseRepPlayer::~TDBaseRepPlayer()
{
	ofstream os;
	char  filename[80] = "td-baserep-output-v";

	if (m_bLearningOn)
	{
		strcat(filename, ((m_nFilenum==1)?"1":"2"));
		strcat(filename, ".txt");

		os.open(filename, ios::out|ios::trunc);
		
		os << "CONFLICT_RES_TEMP " << GetConflictResTemp() << endl;
		os << "LAMBDA            " << GetLambda() << endl;
		os << "ETA               " << GetEta() << endl;
		os << "MOMENTUM          " << GetMomentum() << endl;
		os << "HIDDEN            " << GetHidden() << endl;
		os << "MIN_BLOT_PENALTY  " << GetMinBlotPenalty() << endl;
		os << "MAX_BLOT_PENALTY  " << GetMaxBlotPenalty() << endl;
		os << "LEARNING          " << ((m_bLearningOn)?"ON ":"OFF") << endl << endl;

		// Write Neural Net
		for (int i=0; i<Feature::m_nDefined; i++)
			m_aNNUtilities[i]->SaveNet(os);

		os.close();
	}

	#ifdef TD_BASEREP_PRINT_DEBUG
	m_aoutfile.close();
	#endif

}

// Reset player
void TDBaseRepPlayer::Reset()
{
	BaseRepPlayer::Reset();
	m_fsaMoves.Reset();
}

// Update the player at the end of the game, blot_pt is relative
void TDBaseRepPlayer::Update(bool win, int blot_pt)
{
	// If a win, propagate a success, if loss propagate failure
	Feature  *feature;
	FeatureSet *fs;
	float     discount = LAMBDA;
	float     cur_disc = 1.0;
	bool      blot = (blot_pt != (-1));
	int       t, f;

	BaseRepPlayer::Update(win, blot_pt); // Call parent method

	if (blot && m_bLearningOn)
	{
		// A win/loss will have a factor of 1.0, but we only
		// want to make a blot a fraction of this since it
		// is not as important as a win/loss
		float factor = EXPOSE_BLOT_MIN_PENALTY + 
			         ((EXPOSE_BLOT_MAX_PENALTY - EXPOSE_BLOT_MIN_PENALTY)*
					  (((float)blot_pt)/((float)POINTS)))*(0.8);
		bool found = false;

		// Simply go back through all features and reinforce the neural net on this 
		// blot_pt for any matching exposes to the value of -penalty 

		// For each move, get the features involved
		for (t=m_fsaMoves.GetNumFeatureSets()-1; t>=0; t--)
		{
			fs = m_fsaMoves.GetFeatureSet(t);
			// For each feature set, iterate through each feature
			for (f=fs->GetNumFeats()-1; f>=0; f--)
			{
				feature = fs->GetFeatRef(f);

				if ((feature->m_nType       == m_nEXPOSE) &&
					(feature->m_aSFeats[PT] == blot_pt))
				{
					//SetNeuralNetInputs(*feature);
					//m_aNNUtilities[feature->m_nType]->SetTarget(1, EXPOSE_BLOT_MAX_PENALTY-(cur_disc*factor));
					//m_aNNUtilities[feature->m_nType]->BackPropError();

					//#ifdef TD_BASEREP_PRINT_DEBUG
					//m_aoutfile << "Blot update(" << t << "," << f << "): " << feature->m_nType << ":" << EXPOSE_BLOT_MAX_PENALTY-(cur_disc*factor) << endl;
					//#endif
				}
			}
			cur_disc *= discount; // Discount for every move back...
		}

	}
	else if (m_bLearningOn)
	{
		float update_val = ((win)?(0.9):(0.1));

		// For each move, get the features involved
		for (t=m_fsaMoves.GetNumFeatureSets()-1; t>=0; t--)
		{
			fs = m_fsaMoves.GetFeatureSet(t);
			// For each feature set, iterate through each feature
			for (f=fs->GetNumFeats()-1; f>=0; f--)
			{
				feature = fs->GetFeatRef(f);

				SetNeuralNetInputs(*feature);
				m_aNNUtilities[feature->m_nType]->SetTarget(1, update_val);
				m_aNNUtilities[feature->m_nType]->BackPropError();

				#ifdef TD_BASEREP_PRINT_DEBUG
				m_aoutfile << "End update (" << t << "," << f << ") Feat: " << feature->m_nType << " Target:" << update_val << endl;
				#endif

			}
			cur_disc *= discount; // Discount for every move back...
		}

	// If debug turned on, print matchset of moves and player cached moves
	#ifdef TD_BASEREP_PRINT_DEBUG
	m_aoutfile << "\nFeatureset for each move\n----------------------" << endl;
	m_fsaMoves.PrintFeatureSetArray(m_aoutfile);
	m_aoutfile << "========================================================" << endl;
	#endif
	
	}
}

// Sets m_aMoveValue[] array for each move
void TDBaseRepPlayer::SetMoveUtilities() 
{
	// We have all of the move features for each move, we need to 
	// partial match each feature of each move to the move set and 
	// derive a score for the move
	Feature  *move_feature;
	int m, f, num_features;
	float accum, move_val;

	if (m_bRace) // Race condition, make optimal move
	{
		int best_move = 0;
		int highest = CalcRaceCondHeuristic(0);

		// Find the move that moves the most pieces off of the board
		// at the highest possible points (minimizing remaining moves)
		for (m=1; m<m_nMoves; m++)
		{
			if (highest < CalcRaceCondHeuristic(m))
			{ 
				best_move = m;
				highest = CalcRaceCondHeuristic(m);
			}
		}
		
		// Set the best move value
		for (m=0; m<m_nMoves; m++)
		{
			m_aMoveValue[m] = ((m==best_move) ? 100.0 : 0.001);
		}
	}
	else // Normal play 
	{
		for (m=0; m<m_nMoves; m++)
		{
			// For each move, get the feature, feed it forward through the neural net
			// and get it's output, normalize the output (+1,/2) and multiply current
			// odds by newly calculated odds (v/(1-v))
			accum = 1.0; // For odds
			num_features = m_aMoveFeatureSet[m].GetNumFeats();

			#ifdef TD_BASEREP_PRINT_DEBUG
			m_aoutfile << "Move: " << m;
			#endif

			for (f=0; f<num_features; f++)
			{
				// Get feature and value
				move_feature = m_aMoveFeatureSet[m].GetFeatRef(f);
				move_val = GetNeuralNetOutput(*move_feature); // Should be [0,1]

				#ifdef TD_BASEREP_PRINT_DEBUG
				m_aoutfile << " " << move_feature->m_nType << ":" << move_val;
				#endif

				// Using odds calculation
				accum *=   ((move_val)/(1.0/*(float)m_nTotalWins*/))/
					     ((1-move_val)/(1.0/*(float)m_nTotalLosses*/));
				
				//cout << "Best match:  Index-" << match->index << "  Pen-" << match->pm_penalty
				//	   << "  Win Prob-" << m_faPrevMoves.GetFeatRef(match->index)->GetWinProbability() << endl;

			}

			// Since the BaseRep move evaluation uses higher values to indicate better
			// moves, win prob can be directly assigned to move value
			m_aMoveValue[m] = accum;

			#ifdef TD_BASEREP_PRINT_DEBUG
			m_aoutfile << " -> " << accum << endl;
			#endif
			//cout << "\nAccum: " << accum << "  Move Value: " << m_aMoveValue[m] << endl;
		}
	}
}

// Indicates which move was selected, used for tracking moves
void TDBaseRepPlayer::SelectMove(int mv)
{
	// Copy the selected move's MatchSet to the class's move array
	#ifndef NDEBUG
	if ((mv < 0) || (mv >= m_nMoves)) { cerr << "Illegal move\n"; exit(-1); }
	#endif

	// For each feature in the move set, add it to the feature array for 
	// this move
	m_fsaMoves.AddFeatureSet(&m_aMoveFeatureSet[mv]);
}

float TDBaseRepPlayer::GetNeuralNetOutput(Feature &f)
{
	int i;

	if (Feature::m_aUsed[f.m_nType][PT])
		for (i=PT_START; i<=OP_START; i++)
			m_aNNUtilities[f.m_nType]->SetInput(i, ((f.m_aSFeats[PT]==i)?(1.0):(0.0)));
	else
		for (i=PT_START; i<=OP_START; i++)
			m_aNNUtilities[f.m_nType]->SetInput(i, 0.0);

	if (Feature::m_aUsed[f.m_nType][OP])
		for (i=OP_START; i<=SZ_START; i++)
			m_aNNUtilities[f.m_nType]->SetInput(i, ((f.m_aSFeats[OP]>=(i-OP_START))?(1.0):(0.0)));
	else
		for (i=OP_START; i<=SZ_START; i++)
			m_aNNUtilities[f.m_nType]->SetInput(i, 0.0);

	if (Feature::m_aUsed[f.m_nType][SZ])
		for (i=SZ_START; i<=INPUT_UNITS; i++)
			m_aNNUtilities[f.m_nType]->SetInput(i, ((f.m_aSFeats[SZ]>=(i-SZ_START))?(1.0):(0.0)));
	else
		for (i=SZ_START; i<=INPUT_UNITS; i++)
			m_aNNUtilities[f.m_nType]->SetInput(i, 0.0);

	m_aNNUtilities[f.m_nType]->FeedForward();

	return m_aNNUtilities[f.m_nType]->GetOutput(1);
}

void TDBaseRepPlayer::SetNeuralNetInputs(Feature &f)
{
	int i;

	if (Feature::m_aUsed[f.m_nType][PT])
		for (i=PT_START; i<=OP_START; i++)
			m_aNNUtilities[f.m_nType]->SetInput(i, ((f.m_aSFeats[PT]==i)?(1.0):(0.0)));
	else
		for (i=PT_START; i<=OP_START; i++)
			m_aNNUtilities[f.m_nType]->SetInput(i, 0.0);

	if (Feature::m_aUsed[f.m_nType][OP])
		for (i=OP_START; i<=SZ_START; i++)
			m_aNNUtilities[f.m_nType]->SetInput(i, ((f.m_aSFeats[OP]>=(i-OP_START))?(1.0):(0.0)));
	else
		for (i=OP_START; i<=SZ_START; i++)
			m_aNNUtilities[f.m_nType]->SetInput(i, 0.0);

	if (Feature::m_aUsed[f.m_nType][SZ])
		for (i=SZ_START; i<=INPUT_UNITS; i++)
			m_aNNUtilities[f.m_nType]->SetInput(i, ((f.m_aSFeats[SZ]>=(i-SZ_START))?(1.0):(0.0)));
	else
		for (i=SZ_START; i<=INPUT_UNITS; i++)
			m_aNNUtilities[f.m_nType]->SetInput(i, 0.0);

	#ifdef TD_BASEREP_PRINT_DEBUG
	m_aoutfile << "Input: ";
	for (i=PT_START; i<=INPUT_UNITS; i++)
		m_aoutfile << m_aNNUtilities[f.m_nType]->m_bpNet->input_units[i];
	m_aoutfile << endl;
	#endif

}

