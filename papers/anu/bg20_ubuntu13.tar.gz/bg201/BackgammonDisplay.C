#include "BackgammonDisplay.h"

TextDisplay::TextDisplay() : out(cout) { }

TextDisplay::TextDisplay(ostream &os) : out(os) { }

void TextDisplay::DisplayStartInfo(Backgammon *pgame)
{
	out << endl;
	out << "              *" << ((pgame->m_nTurn == WHITE) ? "White(O)" : "Black(X)") << "* won dice roll" << endl;
}

void TextDisplay::DisplayTurn(Backgammon *pgame, bgplayer p, int m)
{
    int src, dest;

	out << endl;
	out << "        Turn #" << pgame->m_nTurnsPlayed << ": *";
	out << ((pgame->m_nTurn == WHITE) ? "White(O)" : "Black(X)");
        out << "* (" << m+1 << ")";
	for (int sm = 0; sm < pgame->m_aMoves[m].m_nMoveElems; sm++)
	  {
	    out << " ";
	    src  = pgame->m_aMoves[m].m_elem[sm].m_nSrc;
	    if (pgame->RelativePos(p,src) == BAR)
	      out << "BAR";
	    else
	      out << src;
	    out << "-";
	    dest = pgame->m_aMoves[m].m_elem[sm].m_nDest;
	    if (pgame->RelativePos(p,dest) == BORE_OFF)
	      out << "OFF";
	    else
	      out << dest;
	  }
  	out << endl;
		
}

void TextDisplay::DisplayGameInfo(Backgammon *pgame)
{
	int p, c;

	out  << endl;
	out << "  " << "     X Outer Table         X Home Table ";
	if (pgame->m_nHomeBoard[BLACK] == 15) 
		out << "[R" << 15-pgame->m_aPoint[pgame->AbsolutePos(BLACK, BORE_OFF)].m_nMen[BLACK] << "]"; 
	else 
		out << "[" << pgame->m_nHomeBoard[BLACK] << "]";
	out << endl;
	out << "  " << "+-------------------+---+-------------------+" << endl;
	out << "  " << "| 13 14 15 16 17 18 |   | 19 20 21 22 23 24 |" << endl;
	for (c=1; c<=5; c++) 
	{
		out << "  " << "|";
		for (p=13; p<=18; p++)
		{
			if (((pgame->m_aPoint[p].m_nMen[WHITE] >= 6) || 
				 (pgame->m_aPoint[p].m_nMen[BLACK] >= 6)) &&
				 (c == 5))
				out << "  " << MAX((pgame->m_aPoint[p].m_nMen[WHITE]),
				                   (pgame->m_aPoint[p].m_nMen[BLACK]));
			else if (pgame->m_aPoint[p].m_nMen[WHITE] >= c)
				out << "  O";
			else if (pgame->m_aPoint[p].m_nMen[BLACK] >= c)
				out << "  X";
			else
				out << "  |";
		}
		out << " | " << ((pgame->m_aPoint[pgame->AbsolutePos(WHITE, BAR)].m_nMen[WHITE] >= c) 
			             ? "O" : " ") << " |";
		for (p=19; p<=24; p++)
		{
			if (((pgame->m_aPoint[p].m_nMen[WHITE] >= 6) || 
				 (pgame->m_aPoint[p].m_nMen[BLACK] >= 6)) &&
				 (c == 5))
				out << "  " << MAX((pgame->m_aPoint[p].m_nMen[WHITE]),
				                   (pgame->m_aPoint[p].m_nMen[BLACK]));
			else if (pgame->m_aPoint[p].m_nMen[WHITE] >= c)
				out << "  O";
			else if (pgame->m_aPoint[p].m_nMen[BLACK] >= c)
				out << "  X";
			else
				out << "  |";
		}
		out << " |" << endl;
	}
	out << "  " << "|                   |   |                   |" << endl;
	out << "  " << "+-------------------+   +-------------------+" << endl;
	out << "  " << "|                   |   |                   |" << endl;
	for (c=5; c>=1; c--) 
	{
		out << "  " << "|";
		for (p=12; p>=7; p--)
		{
			if (((pgame->m_aPoint[p].m_nMen[WHITE] >= 6) || 
				 (pgame->m_aPoint[p].m_nMen[BLACK] >= 6)) &&
				 (c == 5))
				out << "  " << MAX((pgame->m_aPoint[p].m_nMen[WHITE]),
				                   (pgame->m_aPoint[p].m_nMen[BLACK]));
			else if (pgame->m_aPoint[p].m_nMen[WHITE] >= c)
				out << "  O";
			else if (pgame->m_aPoint[p].m_nMen[BLACK] >= c)
				out << "  X";
			else
				out << "  |";
		}
		out << " | " << ((pgame->m_aPoint[pgame->AbsolutePos(BLACK,BAR)].m_nMen[BLACK] >= c) 
			             ? "X" : " ") << " |";
		for (p=6; p>=1; p--)
		{
			if (((pgame->m_aPoint[p].m_nMen[WHITE] >= 6) || 
				 (pgame->m_aPoint[p].m_nMen[BLACK] >= 6)) &&
				 (c == 5))
				out << "  " << MAX((pgame->m_aPoint[p].m_nMen[WHITE]),
				                   (pgame->m_aPoint[p].m_nMen[BLACK]));
			else if (pgame->m_aPoint[p].m_nMen[WHITE] >= c)
				out << "  O";
			else if (pgame->m_aPoint[p].m_nMen[BLACK] >= c)
				out << "  X";
			else
				out << "  |";
		}
		out << " |" << endl;
	}
	out << "  " << "| 12 11 10 09 08 07 |   | 06 05 04 03 02 01 |" << endl;
	out << "  " << "+-------------------+---+-------------------+" << endl;
	out << "  " << "     O Outer Table         O Home Table ";
	if (pgame->m_nHomeBoard[WHITE] == 15) 
		out << "[R" << 15-pgame->m_aPoint[pgame->AbsolutePos(WHITE, BORE_OFF)].m_nMen[WHITE] << "]"; 
	else 
		out << "[" << pgame->m_nHomeBoard[WHITE] << "]";
	out << endl;
	out << endl;
	out << "        Turn #" << pgame->m_nTurnsPlayed << ": *" 
		<< ((pgame->m_nTurn == WHITE) ? "White(O)" : "Black(X)");
	out << "*  Dice: *" << pgame->m_aDice[0] << "* *" << pgame->m_aDice[1] << "* ";
	out << ((pgame->m_bDoubles) ? "D" : " ") << endl;
}

void TextDisplay::DisplayWinInfo(Backgammon *pgame)
{
	out << endl;
	out << "        *** ";
	out << (BLACK == (pgame->WhoHasWon()) ? "BLACK(X)" : "WHITE(O)")
		<< " has won the game! ***" << endl;
	out << endl;
}

void TextDisplay::DisplayError(Backgammon *pgame, int msg)
{
	out << endl;
	out << "Game Error, msg ID: " << msg << endl;
	out << endl;
}

void TextDisplay::DisplayMoveSet(Backgammon *pgame, bgplayer p)
{
	int src, dest;

	out << endl;
	if (pgame->m_nValidMoves == 0)
		out << "No valid moves possible for this turn" << endl;
	for (int m = 0; m < pgame->m_nValidMoves; m++)
	{
		out << "(" << m+1 << ")";
		for (int sm = 0; sm < pgame->m_aMoves[m].m_nMoveElems; sm++)
		{
			out << " ";
			src  = pgame->m_aMoves[m].m_elem[sm].m_nSrc;
			if (pgame->RelativePos(p,src) == BAR)
				out << "BAR";
			else
				out << src;
			out << "-";
			dest = pgame->m_aMoves[m].m_elem[sm].m_nDest;
			if (pgame->RelativePos(p,dest) == BORE_OFF)
				out << "OFF";
			else
				out << dest;
		}
		out << endl;
	}
	out << endl;
}
