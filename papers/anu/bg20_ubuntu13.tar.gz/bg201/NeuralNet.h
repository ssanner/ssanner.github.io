//////////////////////////////////////////////////////////////
//
// Class:   NeuralNet
//
// Author:  Jeff Shufelt, Scott P. Sanner
// Date:    10/15/94, 04/19/99, 11/22/99
//
// Description:
// ------------
//
// The NeuralNet class encapsulates a backpropagation multi-
// layer neural net.  The neural net dimensions are handled
// in the constructor and accessor methods allow access to
// the input and output units.  A method call allows the
// neural net to be trained and other methods allow weights
// to be loaded into and saved from the neural net.
//
// This class encapsulates the original C backprop neural net
// code written by Jeff Shufelt.
// 
// History:
// --------
//
// 10/15/94 - Jeff Shufelt (js), Carnegie Mellon University
//      Prepared for 15-681, Fall 1994.
//
// 04/19/99 - Scott Sanner (sanner), Carnegie Mellon University
//      Encapsulated in C++ class
//
// 11/22/99 - Scott Sanner (sanner), Carnegie Mellon University
//      Updated class for Neural Net learning portion of
//      Backgammon project, added read/write features
//
//////////////////////////////////////////////////////////////

#ifndef _BACKPROP_H_
#define _BACKPROP_H_

#include <iostream>
#include <string.h>
#include "Random.h"

using namespace std;

#define CNEURALNET_BIAS    0
#define CNEURALNET_RNDSEED 57786696
#define CNEURALNET_BIGRND  0x7fffffff

/*** The neural network data structure.  The network is assumed to
     be a fully-connected feedforward three-layer network.
     Unit 0 in each layer of units is the threshold unit; this means
     that the remaining units are indexed from 1 to n, inclusive.
 ***/

struct BPNN {
  int input_n;                  /* number of input units */
  int hidden_n;                 /* number of hidden units */
  int output_n;                 /* number of output units */

  double *input_units;          /* the input units */
  double *hidden_units;         /* the hidden units */
  double *output_units;         /* the output units */

  double *hidden_delta;         /* storage for hidden unit error */
  double *output_delta;         /* storage for output unit error */

  double *target;               /* storage for target vector */

  double **input_weights;       /* weights from input to hidden layer */
  double **hidden_weights;      /* weights from hidden to output layer */

                                /*** The next two are for momentum ***/
  double **input_prev_weights;  /* previous change on input to hidden wgt */
  double **hidden_prev_weights; /* previous change on hidden to output wgt */
};

/*** User-level functions ***/

void bpnn_initialize(int seed);

BPNN *bpnn_create(int n_in, int n_hidden, int n_out, RandomGen &rv_gen);
void bpnn_free(BPNN *net);

void bpnn_zero_weights(double **w, int m, int n);
void bpnn_randomize_weights(double **w, int m, int n, RandomGen &rv_gen);
void bpnn_initialize(int seed);

void bpnn_train(BPNN *net, double eta, double momentum, double *eo, double *eh);
void bpnn_feedforward(BPNN *net);

void bpnn_save(BPNN *net, char *filename);
BPNN *bpnn_read(char *filename);

// ================================================================
// Define a neural net class to encapsulate BPNN and to perform
// parameter validation (sanner)
class NeuralNet {

public:
	// Constructors and Destructor
	NeuralNet();
	NeuralNet(istream &is);
	NeuralNet(int input, int hidden, int output, double eta, double momentum);
	~NeuralNet();

	// Weight Initialization methods
	void   RandomizeWeights();
	void   ZeroWeights();

	// Unit activation access methods
	bool   SetInput (int unit, double value);
	bool   SetTarget(int unit, double value);
	double GetOutput(int unit);

	// Weight access methods
	bool   SetInputWeight(int in, int hid, double value);
	bool   SetHiddenWeight(int hid, int out, double value);
	double GetInputWeight(int in, int hid);
	double GetHiddenWeight(int hid, int out);

	// Training and Verification methods
	void   FeedForward();
	void   BackPropError();

	// Saving and Loading a neural net
	bool LoadNet(istream &is);
	bool SaveNet(ostream &os);

public:
	BPNN     *m_bpNet;
	int       m_nInputUnits;
	int       m_nHiddenUnits;
	int       m_nOutputUnits;
	double    m_dEta; 
	double    m_dMomentum; 
	double    m_dOutErr;
	double    m_dHidErr;
	RandomGen m_rvGen;
};
// End of class definition (sanner)
// ================================================================

#endif
