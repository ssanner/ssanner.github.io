////////////////////////////////////////////////////////
// Class:  Player
// Author: Scott P. Sanner
//
// Description:
//
// A Backgammon player that uses Tesauro's single layer
// neural network to choose the most optimal move.
//
////////////////////////////////////////////////////////

#ifndef _TDPLAYER_H_
#define _TDPLAYER_H_

#include "Backgammon.h"
#include "Player.h"

#define BOARD_ENC_LENGTH 122
#define POSITION_LENGTH   28

class TDPlayer: public Player
{
	public:
		TDPlayer();
		virtual ~TDPlayer();
		virtual void DeriveFeatures(Backgammon *p, int mv);
		virtual bool PlayTurn(Backgammon* p);

	private:
		float EvalBoard(int race, int *pos);
		void  SetX     (int *pos);
		void  ReadWeights();

	protected:
		float m_aX [BOARD_ENC_LENGTH];
		float m_aWR[BOARD_ENC_LENGTH];
		float m_aWC[BOARD_ENC_LENGTH];
		float m_aMoveValue[MAX_POSSIBLE_MOVES];
};

#endif // _TDPLAYER_H_