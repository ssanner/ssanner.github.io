////////////////////////////////////////////////////////
// Class:  Player
// Author: Scott P. Sanner
//
// Description:
//
////////////////////////////////////////////////////////

#ifndef _PLAYER_H_
#define _PLAYER_H_

#include "Backgammon.h"
#include "Random.h"

// Base class for the Backgammon player, all players must
// derive from this class
class Player
{
	public:
		Player() {}
		virtual ~Player() {}
			
		virtual void Reset         () {}
		virtual void Update        (bool win, int blot_pt) {}
		virtual void SetPlayer     (bgplayer p);
		virtual void DeriveFeatures(Backgammon *p, int mv);
		virtual bool PlayTurn      (Backgammon* p) = 0;

	protected:
		bgplayer me;
};

class RandomPlayer: public Player
{
	public:
		RandomPlayer();
		virtual bool PlayTurn(Backgammon* p);

	protected:
		RandomGen rg;
};

class StaticPlayer: public Player
{
	public:
		StaticPlayer();
		virtual bool PlayTurn(Backgammon* p);
};

class TextPlayer: public Player
{
	public:
		TextPlayer();
		virtual ~TextPlayer();
		virtual bool PlayTurn(Backgammon* p);
};

#endif // _PLAYER_H_