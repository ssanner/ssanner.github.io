#include <stdio.h>
#include "TDPlayer.h"

TDPlayer::TDPlayer()
{
	// Load in weight arrays
	ReadWeights();
}

TDPlayer::~TDPlayer()
{

}

void TDPlayer::DeriveFeatures(Backgammon *p, int mv)
{
	// mv indicates the move that was made, p contains the game board,
	// store value of mv in m_nMoveValue, mv is zero-indexed
	bgplayer op = p->GetOtherPlayer(me);
	bgplayer bearing = p->WhoIsBearing();
	int race = ((bearing == BOTH) || (bearing == me));
	int pos[POSITION_LENGTH], rev_pos;

	// Since relative position considers 1 to be start and 24 to be
	// destination need and pos matrix requires the opposite
	// encoding, need to keep this in mind in the following code:
	for(int r=1; r<=24; r++)
	{
		rev_pos = 24-r+1;
		if ((pos[rev_pos] = p->m_aPoint[p->AbsolutePos(me,r)].m_nMen[me]) == 0)
			pos[rev_pos] = -p->m_aPoint[p->AbsolutePos(me,r)].m_nMen[op];
	}
	pos[0]  = -p->m_aPoint[p->AbsolutePos(me,BAR)].m_nMen[op];      // Opponent's men on bar
	pos[25] =  p->m_aPoint[p->AbsolutePos(me,BAR)].m_nMen[me];      // Computer's men on bar (me)
	pos[26] =  p->m_aPoint[p->AbsolutePos(me,BORE_OFF)].m_nMen[me]; // Computer's men off the board (me)
	pos[27] = -p->m_aPoint[p->AbsolutePos(me,BORE_OFF)].m_nMen[op]; // Opponent's men off the board

	m_aMoveValue[mv] = EvalBoard(race, pos);
}  

bool TDPlayer::PlayTurn(Backgammon* p)
{
	float max_so_far;
	int   max_index;
	bool  any_moves = (p->m_nValidMoves > 0);

	if (any_moves)
	{
		// Generate each possible next state using DeriveFeatures
		p->DeriveFeatures(me, this);

		// Find the move which generated the highest value
		max_so_far = m_aMoveValue[0];
		max_index  = 0;
		for (int i=1; i<p->m_nValidMoves; i++)
			if (m_aMoveValue[i] > max_so_far)
			{
				max_so_far = m_aMoveValue[i];
				max_index  = i;
			}

		// Select that move if any move is possible
		p->MakeMove(me, max_index);
	}

	return true;
}

// The following code was written by Gerry Tesauro (with a few modifications
// by Scott Sanner to work with this Backgammon playing architecture)
float TDPlayer::EvalBoard(int race, int *pos)
{
  /* Backgammon move-selection evaluation function for benchmark comparisons.
   * Computes a linear evaluation function:  Score = W * X, where X is an
   * input vector encoding the board state (using a raw encoding of the number
   * of men at each location), and W is a weight vector.  Separate weight
   * vectors are used for racing positions and contact positions. Makes lots
   * of obvious mistakes, but provides a decent level of play for benchmarking
   * purposes. */

  /* Provided as a public service to the backgammon programming community by
   * Gerry Tesauro, IBM Research. (e-mail: tesauro@watson.ibm.com)    */

  /* The following inputs are needed for this routine: 
   *
   * race   is an integer variable which should be set based on the INITIAL
   * position BEFORE the move. Set race=1 if the position is a race (i.e. no
   * contact) and 0 if the position is a contact position. 
   *
   * pos[]  is an integer array of dimension 28 which should represent a legal
   * final board state after the move. Elements 1-24 correspond to board
   * locations 1-24 from computer's point of view, i.e. computer's men move in
   * the negative direction from 24 to 1, and opponent's men move in the
   * positive direction from 1 to 24. Computer's men are represented by
   * positive integers, and opponent's men are represented by negative
   * integers. Element 25 represents computer's men on the bar (positive
   * integer), and element 0 represents opponent's men on the bar (negative
   * integer). Element 26 represents computer's men off the board (positive
   * integer), and element 27 represents opponent's men off the board
   * (negative integer).      */

  /* Also, be sure to call rdwts() at the start of your program to read in the
   * weight values. Happy hacking] */

  int                 i;
  float               score;

  if (pos[26] == 15)
    return ((float)99999999.);
  /* all men off, best possible move */

  SetX(pos);   /* sets input array x[] */
  score = 0.0;
  if (race) {   /* use race weights */
    for (i = 0; i < BOARD_ENC_LENGTH; ++i)
      score += m_aWR[i] * m_aX[i];
  } else {   /* use contact weights */
    for (i = 0; i < BOARD_ENC_LENGTH; ++i)
      score += m_aWC[i] * m_aX[i];
  }
  return (score);
}

void TDPlayer::SetX(int *pos)
{
  /* sets input vector m_aX[] given board position pos[] */
  int                 j, jm1, n;

  /* initialize */
  for (j = 0; j < BOARD_ENC_LENGTH; ++j)
    m_aX[j] = 0.0;

  /* first encode board locations 24-1 */
  for (j = 1; j <= 24; ++j) {
    jm1 = j - 1;
    n = pos[25 - j];
    if (n != 0) {
      if (n == -1)
		m_aX[5 * jm1 + 0] = 1.0;
      if (n == 1)
		m_aX[5 * jm1 + 1] = 1.0;
      if (n >= 2)
		m_aX[5 * jm1 + 2] = 1.0;
      if (n == 3)
		m_aX[5 * jm1 + 3] = 1.0;
      if (n >= 4)
		m_aX[5 * jm1 + 4] = (float) (n - 3) / 2.0;
    }
  }
  /* encode opponent barmen */
  m_aX[120] = -(float) (pos[0]) / 2.0;
  /* encode computer's menoff */
  m_aX[121] = (float) (pos[26]) / 15.0;
}

void TDPlayer::ReadWeights()
{
  // read weight files into arrays m_aWR[], m_aWC[]
  int                 i;
  FILE               *fp, *fq;

  fp = fopen("td1-config-race.txt", "r");
  fq = fopen("td1-config-cntc.txt", "r");
  for (i = 0; i < BOARD_ENC_LENGTH; ++i) {
    fscanf(fp, "%f", m_aWR + i);
    fscanf(fq, "%f", m_aWC + i);
  }
  fclose(fp);
  fclose(fq);
}

