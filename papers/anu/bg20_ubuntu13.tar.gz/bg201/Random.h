//////////////////////////////////////////////////////////////
// Defines the function for a uniform probability generator.
//////////////////////////////////////////////////////////////

#include <sys/types.h>
#include <time.h>
#include <math.h>

#ifndef _RANDOM_H_
#define _RANDOM_H_

#define A   147453245
#define C   226908347
#define M   1073741824

class RandomGen {

// Public methods
public:
	RandomGen() { InitRVSeed(); }

	// Initialize the random number generator with default value
	void InitRVSeed()
	{
	  INC = 57786696 + ((long)time(NULL)%100000000);	  
	  INC += INC;
	  LAST_X = INC;
	}

	// Initialize the random number generator
	void InitRVSeed(int seed)
	{
	  INC = 57786696 + ((long)time(NULL)%100000000);
	  INC += INC;
	  LAST_X = seed + INC;
	}

	// Returns a floating point, uniformly distributed value
	double UniformRV(void)
	{
	  LAST_X = ((A * LAST_X) + C) % M;
	  if (LAST_X < 0)
		LAST_X = -LAST_X;

	  return (((double)LAST_X) / ((double) M));
	}

	// Returns an integer value in the range of [imin, imax]
	int UniformIntRV(int imin, int imax)
	{
	  double u;
	  int m;

	  u = UniformRV();
	  m = (int)(imin + floor((double)(imax + 1 - imin) * u));

	  return m;
	}

	int LAST_X;
	int INC;

};

#endif // _RANDOM_H_